import React, { useState, useEffect, useRef, useMemo, useCallback } from "react";
import {
  Home, FileSearch, ClipboardList, FileText, ShieldCheck, GitBranch,
  GaugeCircle, MessageSquare, Settings2, Plus, Upload, Check, AlertTriangle,
  Circle, CircleCheck, Loader2, Download, Sparkles, ChevronRight, ArrowRight,
  Trash2, RefreshCw, FileDown, Send, Building2, Target, Layers, ListChecks,
  BookOpen, Wand2, Copy, Edit3, Save, Menu, X, HelpCircle, Rocket, CloudUpload,
  KeyRound, Plug, Cog, CheckCircle2, XCircle, ChevronDown, MoreHorizontal, Paperclip, Info, CreditCard, Tag
} from "lucide-react";
import * as XLSX from "xlsx";

/* Persistence: real browser storage when running outside the Claude artifact sandbox */
if (typeof window !== "undefined" && !window.storage) {
  window.storage = {
    async get(k){ try { const v = localStorage.getItem(k); return v==null?null:{key:k,value:v}; } catch { return null; } },
    async set(k,v){ try { localStorage.setItem(k,String(v)); } catch(e){} return {key:k,value:String(v)}; },
    async delete(k){ try { localStorage.removeItem(k); } catch(e){} return {key:k,deleted:true}; },
    async list(prefix=""){ let keys=[]; try { keys=Object.keys(localStorage).filter(x=>x.startsWith(prefix)); } catch(e){} return {keys}; },
  };
}

/* ============================================================================
   ISO/IEC 20000-1:2018 reference data
   ========================================================================== */
const CLAUSES = [
  { id: "4", name: "Context of the organization", plain: "Who you are, who you serve, and what your system covers", sub: [
    ["4.1", "Understanding the organization and its context"],
    ["4.2", "Understanding the needs and expectations of interested parties"],
    ["4.3", "Determining the scope of the SMS"],
    ["4.4", "Service management system"],
  ]},
  { id: "5", name: "Leadership", plain: "Management commitment, your policy, and who's responsible", sub: [
    ["5.1", "Leadership and commitment"],
    ["5.2", "Policy"],
    ["5.3", "Organizational roles, responsibilities and authorities"],
  ]},
  { id: "6", name: "Planning", plain: "Risks, opportunities, and the goals you're aiming for", sub: [
    ["6.1", "Actions to address risks and opportunities"],
    ["6.2", "Service management objectives and planning to achieve them"],
    ["6.3", "Plan the service management system"],
  ]},
  { id: "7", name: "Support", plain: "People, skills, communication, and your documents", sub: [
    ["7.1", "Resources"], ["7.2", "Competence"], ["7.3", "Awareness"],
    ["7.4", "Communication"], ["7.5", "Documented information"], ["7.6", "Knowledge"],
  ]},
  { id: "8", name: "Operation", plain: "The day-to-day IT service work — this is where most processes live", sub: [
    ["8.1", "Operational planning and control"], ["8.2", "Service portfolio"],
    ["8.3", "Relationship and agreement"], ["8.4", "Supply and demand"],
    ["8.5", "Service design, build and transition"], ["8.6", "Resolution and fulfilment"],
    ["8.7", "Service assurance"],
  ]},
  { id: "9", name: "Performance evaluation", plain: "Measuring, reporting, auditing, and management review", sub: [
    ["9.1", "Monitoring, measurement, analysis and evaluation"], ["9.2", "Internal audit"],
    ["9.3", "Management review"], ["9.4", "Service reporting"],
  ]},
  { id: "10", name: "Improvement", plain: "Fixing what goes wrong and getting better over time", sub: [
    ["10.1", "Nonconformity and corrective action"], ["10.2", "Continual improvement"],
  ]},
];

const PROCESSES = [
  { key: "incident", name: "Incident Management", clause: "8.6.1", plain: "Getting broken things working again fast" },
  { key: "request", name: "Service Request Management", clause: "8.6.2", plain: "Handling routine requests (access, hardware, etc.)" },
  { key: "problem", name: "Problem Management", clause: "8.6.3", plain: "Finding and fixing root causes" },
  { key: "change", name: "Change Enablement", clause: "8.5.1", plain: "Making changes safely" },
  { key: "config", name: "Configuration Management", clause: "8.2.6", plain: "Tracking what makes up your services" },
  { key: "asset", name: "Asset Management", clause: "8.2.5", plain: "Managing hardware, software and licenses" },
  { key: "knowledge", name: "Knowledge Management", clause: "7.6", plain: "Capturing and sharing know-how" },
  { key: "capacity", name: "Capacity Management", clause: "8.4.3", plain: "Making sure you have enough resources" },
  { key: "availability", name: "Availability Management", clause: "8.7.1", plain: "Keeping services up when they're needed" },
  { key: "continuity", name: "Service Continuity Management", clause: "8.7.2", plain: "Recovering after major disruptions" },
  { key: "slm", name: "Service Level Management", clause: "8.3.3", plain: "Meeting your SLAs and targets" },
  { key: "supplier", name: "Supplier Management", clause: "8.3.4", plain: "Managing vendors and subcontractors" },
  { key: "release", name: "Release & Deployment Management", clause: "8.5.3", plain: "Rolling out changes to production" },
  { key: "monitoring", name: "Monitoring & Reporting", clause: "9.1 / 9.4", plain: "Watching performance and reporting on it" },
  { key: "improvement", name: "Continual Improvement", clause: "10.2", plain: "A repeatable way to keep getting better" },
];

const CORE_DOCS = [
  { key: "smpolicy", name: "Service Management Policy", clause: "5.2" },
  { key: "scope", name: "Scope Statement", clause: "4.3" },
  { key: "context", name: "Context of the Organization", clause: "4.1" },
  { key: "parties", name: "Interested Parties Register", clause: "4.2" },
  { key: "leadership", name: "Leadership Responsibilities", clause: "5.1 / 5.3" },
  { key: "objectives", name: "Service Management Objectives", clause: "6.2" },
  { key: "riskreg", name: "Risk Register", clause: "6.1" },
  { key: "oppreg", name: "Opportunity Register", clause: "6.1" },
  { key: "commplan", name: "Communication Plan", clause: "7.4" },
  { key: "competency", name: "Competency Matrix", clause: "7.2" },
  { key: "training", name: "Training Plan", clause: "7.2 / 7.3" },
  { key: "doccontrol", name: "Document Control Procedure", clause: "7.5" },
  { key: "records", name: "Records Management Procedure", clause: "7.5" },
];

const PROCESS_SECTIONS = [
  "Policy", "Procedure", "Workflow (step-by-step)", "RACI Matrix",
  "Roles & Responsibilities", "Inputs & Outputs", "KPIs & Targets",
  "Risks & Controls", "Required Records & Forms", "Templates & Work Instructions",
];

const AUDIT_ARTIFACTS = [
  "Audit Plan", "Audit Schedule", "Audit Checklist", "Interview Questions",
  "Objective Evidence Requirements", "Sampling Plan", "Expected Records",
  "Audit Findings Template", "Nonconformity Report", "Corrective Action Report",
  "Follow-up Audit Report",
];

const DEFAULT_ROADMAP = () => ([
  { id: 1, phase: "Phase 1 — Get set up", owner: "Program Manager", weeks: "Weeks 1–3", tasks: [
    { t: "Decide what your system covers (scope)", done: false },
    { t: "List who cares about your service (interested parties)", done: false },
    { t: "Pull obligations out of your contract / SOW / PWS", done: false },
    { t: "Do a first gap check", done: false } ]},
  { id: 2, phase: "Phase 2 — Leadership & goals", owner: "Service Delivery Manager", weeks: "Weeks 3–6", tasks: [
    { t: "Get your Service Management Policy approved", done: false },
    { t: "Assign roles and responsibilities", done: false },
    { t: "Set your objectives and KPIs", done: false },
    { t: "Build your risk & opportunity registers", done: false } ]},
  { id: 3, phase: "Phase 3 — People & documents", owner: "Quality Lead", weeks: "Weeks 5–9", tasks: [
    { t: "Set up document & records control", done: false },
    { t: "Create a competency matrix & training plan", done: false },
    { t: "Write your communication plan", done: false },
    { t: "Stand up knowledge management", done: false } ]},
  { id: 4, phase: "Phase 4 — Build the processes", owner: "Process Owners", weeks: "Weeks 8–16", tasks: [
    { t: "Incident, request & problem management", done: false },
    { t: "Change, release, config & asset management", done: false },
    { t: "Service level & supplier management", done: false },
    { t: "Capacity, availability & continuity", done: false } ]},
  { id: 5, phase: "Phase 5 — Check & audit", owner: "Internal Auditor", weeks: "Weeks 15–20", tasks: [
    { t: "Get service reporting running", done: false },
    { t: "Run your internal audit", done: false },
    { t: "Hold a management review", done: false },
    { t: "Log & fix nonconformities", done: false } ]},
  { id: 6, phase: "Phase 6 — Certification ready", owner: "Program Manager", weeks: "Weeks 19–24", tasks: [
    { t: "Do a Stage 1 readiness review", done: false },
    { t: "Close any outstanding findings", done: false },
    { t: "Assemble your evidence pack", done: false },
    { t: "Pass the Stage 2 certification audit", done: false } ]},
]);

const STATUS = {
  missing:    { label: "Not started",  color: "#e11d48", chip: "bg-rose-50 text-rose-700 border-rose-200", w: 0 },
  partial:    { label: "In progress",  color: "#f59e0b", chip: "bg-amber-50 text-amber-700 border-amber-200", w: 0.5 },
  implemented:{ label: "Done",         color: "#059669", chip: "bg-emerald-50 text-emerald-700 border-emerald-200", w: 1 },
  na:         { label: "Not needed",   color: "#64748b", chip: "bg-slate-100 text-slate-600 border-slate-200", w: null },
};
const STATUS_ORDER = ["missing", "partial", "implemented", "na"];

const DOC_TYPES = ["SOW", "PWS", "Proposal", "Existing Policy", "Existing Procedure",
  "Work Instruction", "Audit Report", "Org Chart", "Service Catalog", "Network Diagram", "Other"];

/* ============================================================================
   Persistence
   ========================================================================== */
const KEY = "iso20k:project:v2";
const store = {
  async load() { try { const r = await window.storage.get(KEY); return r ? JSON.parse(r.value) : null; } catch { return null; } },
  async save(d) { try { await window.storage.set(KEY, JSON.stringify(d)); } catch (e) {} },
};
const emptyProject = () => ({
  created: Date.now(),
  meta: { companyName: "", contractName: "", customerName: "", itsmPlatform: "", numUsers: "",
    numTechs: "", helpDeskHours: "", numSites: "", techStack: "", cloudProviders: "", vendors: "" },
  docs: [], analysis: null,
  gaps: Object.fromEntries(PROCESSES.map(p => [p.key, "missing"])),
  generated: {}, audit: {}, findings: [], tasks: {}, actions: [], roadmap: DEFAULT_ROADMAP(), chat: [],
});

/* ============================================================================
   DEMO PROJECT — a realistic, fully-populated sample so every screen works
   instantly without uploading anything or calling the AI. Fictional data.
   ========================================================================== */
const DEMO_PWS_TEXT = `PERFORMANCE WORK STATEMENT (PWS)
Enterprise IT Service Desk & End-User Support Services (EITSD)
Issuing Agency: U.S. Department of Commerce — Office of the CIO (OCIO)
Solicitation No.: 1333BJ-25-R-0142 (FICTIONAL — DEMO ONLY)
Awarded Contractor: Meridian Federal Solutions, LLC
Contract Type: Firm-Fixed-Price with Performance-Based Service Levels
Period of Performance: 12-month base + four 12-month options
Place of Performance: Washington, DC HQ + 13 CONUS field sites

1.0 BACKGROUND. The Government requires enterprise IT service desk and end-user support for ~9,200 users across 14 sites. The Contractor shall establish and operate a service management system aligned to ISO/IEC 20000-1:2018 and achieve certification by the end of Option Period 1.

2.0 SCOPE. Tier 1 and Tier 2 support, incident and service request handling, problem management, change support, IT asset/configuration support, knowledge management, service monitoring, and continual service improvement — delivered within the Government's ServiceNow ITSM platform.

4.0 ENVIRONMENT. ~9,200 users; 14 sites; ~7,500 endpoints; ~48 FTE. Tier 1 24x7x365; Tier 2 0600-2000 ET Mon-Fri. Cloud: Microsoft 365 GCC High, AWS GovCloud, Azure Government.

6.0 SERVICE LEVELS. Average Speed to Answer <= 30s (80% of calls); First Contact Resolution >= 70%; P1 response <= 15 min and resolution <= 4 hours; P2 resolution <= 8 business hours; P3 <= 3 business days; Service Request Fulfillment >= 90%; CSAT >= 90%; Self-Service Portal availability >= 99.5%.

7.0 COMPLIANCE. FISMA; NIST SP 800-53 Rev. 5; FedRAMP Moderate (cloud); Section 508; FITARA; HSPD-12/PIV; Privacy Act/PII; ISO/IEC 20000-1:2018 (certification required).

8.0 DELIVERABLES. Transition-In Plan (10 days); Quality Control Plan (30 days); SOPs (45 days); Staffing/Contingency Plan (30 days); Monthly Status Report; Monthly SLA Performance Report; Knowledge Base Health Report; quarterly Continual Service Improvement Report; annual Customer Satisfaction Survey.

9.0 KEY PERSONNEL. Program Manager (PMP); Service Delivery Manager (ITIL 4 MP); ITSM/Quality Manager (ISO/IEC 20000-1 experience); Information Systems Security Officer (CISSP).`;

const DEMO_SLA_CSV = `Service Level Metric,Priority,Performance Target,Acceptable Quality Level,Clause
Average Speed to Answer,All,<= 30 seconds,>= 80% of calls,8.3.3
First Contact Resolution,All,>= 70%,Monthly,8.6.1
Critical Incident Resolution,P1,<= 4 hours,>= 95%,8.6.1
Service Request Fulfillment,All,>= 90% within SLA,Monthly,8.6.2
Customer Satisfaction (CSAT),All,>= 90%,Monthly survey,8.3.3
Self-Service Portal Availability,All,>= 99.5%,Monthly uptime,8.7.1`;

const DEMO_SOP_TEXT = `Incident Response SOP — DRAFT v0.9 (NOT APPROVED)
Purpose: how the service desk logs and responds to incidents in ServiceNow.
Priority matrix: P1 15min/4h; P2 30min/8h; P3 1d/3d; P4 1d/5d.
Basic steps: log, categorize, attempt first-contact resolution, escalate to Tier 2, keep user informed, close.
KNOWN GAPS (incomplete): no RACI/roles, no P1 bridge procedure, no link to Problem Management, no KPIs/reporting, no records/retention, no document control.`;

const DEMO_ANALYSIS = {
  deliverables: ["Transition-In (Phase-In) Plan — 10 days after award","Quality Control Plan (QCP) — 30 days","Standard Operating Procedures (SOPs) — 45 days","Staffing & Contingency Plan — 30 days","Monthly Status Report — 5th business day","Monthly SLA Performance Report — 5th business day","Knowledge Base Health Report — monthly","Continual Service Improvement Report — quarterly","Annual Customer Satisfaction Survey"],
  processes: ["Incident Management","Service Request Management","Problem Management","Change Enablement","Configuration Management","Asset Management","Knowledge Management","Service Level Management","Availability Management","Monitoring & Reporting","Continual Improvement"],
  slas: [{metric:"Average Speed to Answer",target:"<= 30s (80% of calls)",clause:"8.3.3"},{metric:"First Contact Resolution",target:">= 70%",clause:"8.6.1"},{metric:"P1 Resolution",target:"<= 4 hours (>=95%)",clause:"8.6.1"},{metric:"Service Request Fulfillment",target:">= 90% within SLA",clause:"8.6.2"},{metric:"Customer Satisfaction (CSAT)",target:">= 90%",clause:"8.3.3"},{metric:"Self-Service Portal Availability",target:">= 99.5%",clause:"8.7.1"}],
  reporting: ["Monthly Status Report (5th business day)","Monthly SLA performance & trend analysis","Quarterly Continual Service Improvement report","Monthly knowledge base health metrics","Annual customer satisfaction survey results"],
  roles: [{role:"Program Manager",responsibility:"Overall delivery; PMP; primary Government interface"},{role:"Service Delivery Manager",responsibility:"Day-to-day service desk operations & SLA performance"},{role:"ITSM / Quality Manager",responsibility:"Owns the ISO/IEC 20000-1 SMS and internal audits"},{role:"ISSO",responsibility:"Security compliance (FISMA, NIST 800-53)"}],
  risks: [{risk:"ISO/IEC 20000-1 certification required by end of Option Year 1",impact:"High"},{risk:"24x7 P1 response <= 15 min requires resilient staffing",impact:"High"},{risk:"CSAT >= 90% depends on knowledge base maturity",impact:"Medium"},{risk:"Asset/CMDB accuracy dependent on Government tooling",impact:"Medium"}],
  expectations: ["Single point of contact for ~9,200 users across 14 sites","Consistent, measurable, auditable service","Reduced recurring incidents via root-cause analysis","Year-over-year improvement in FCR and self-service adoption"],
  compliance: ["FISMA","NIST SP 800-53 Rev. 5","FedRAMP Moderate (cloud)","Section 508","FITARA","HSPD-12 / PIV","Privacy Act / PII","ISO/IEC 20000-1:2018 (certification required)"],
  clauseMap: [{clause:"4.3",requirement:"Define SMS scope covering the enterprise help desk for DoC"},{clause:"5.2",requirement:"Service management policy required by the SMS mandate"},{clause:"6.2",requirement:"Service objectives tied to contract SLAs"},{clause:"8.6.1",requirement:"Incident management with P1-P4 priority matrix"},{clause:"8.6.2",requirement:"Service request fulfillment via published catalogue"},{clause:"8.6.3",requirement:"Problem management & known-error database"},{clause:"8.5.1",requirement:"Change enablement & CAB participation"},{clause:"8.3.3",requirement:"Service level management for ASA, FCR, CSAT"},{clause:"8.7.1",requirement:"Availability >= 99.5% for self-service portal"},{clause:"9.4",requirement:"Monthly service reporting to the Government"},{clause:"10.2",requirement:"Continual service improvement program"}],
};

const DEMO_SMPOLICY = `## 1. Purpose
This Service Management Policy sets out Meridian Federal Solutions' commitment to delivering IT service desk and end-user support to the U.S. Department of Commerce under a service management system (SMS) aligned to ISO/IEC 20000-1:2018.

## 2. Scope
Applies to all services, personnel and processes supporting the ~9,200 users across 14 sites under the Enterprise IT Service Desk (EITSD) contract, operated within ServiceNow.

## 3. Policy Statements
- We manage services through defined, measurable and continually improving processes.
- We meet or exceed all contractual service levels and report performance transparently.
- We restore service quickly, reduce recurring incidents, and manage change safely.
- We protect Government information per FISMA, NIST SP 800-53 and Department policy.
- We achieve and maintain ISO/IEC 20000-1 certification.

## 4. Roles & Responsibilities
| Role | Responsibility |
|---|---|
| Program Manager | Accountable for the SMS and the Government relationship |
| Service Delivery Manager | Owns day-to-day operations and SLA performance |
| ITSM / Quality Manager | Maintains the SMS, internal audits and improvement |

## 5. Review & Approval
Reviewed at least annually and upon significant change.

| Version | Date | Author | Approved by |
|---|---|---|---|
| 1.0 | (current) | ITSM/Quality Manager | Program Manager |`;

const DEMO_SCOPE = `## Scope of the Service Management System

**Organization:** Meridian Federal Solutions, LLC
**Customer:** U.S. Department of Commerce — OCIO
**Contract:** Enterprise IT Service Desk (EITSD)

### Services in scope
Tier 1 and Tier 2 IT service desk and end-user support for ~9,200 users across 14 CONUS sites, delivered 24x7 (Tier 1) via the ServiceNow ITSM platform.

### Processes in scope
Incident, service request, problem, change support, configuration/asset support, knowledge management, service level management, availability, monitoring & reporting, and continual improvement.

### Boundaries & exclusions
Underlying network and data-center operations are Government-provided interfaces, not part of this SMS. Cloud platforms (M365 GCC High, AWS GovCloud, Azure Government) are consumed as Government-furnished services.

### Governing standard
ISO/IEC 20000-1:2018, clauses 4-10.`;

const DEMO_OBJECTIVES = `## Service Management Objectives

| # | Objective | Measure | Target | Clause |
|---|---|---|---|---|
| 1 | Answer users quickly | Average Speed to Answer | <= 30s (80%) | 8.3.3 |
| 2 | Resolve on first contact | First Contact Resolution | >= 70% | 8.6.1 |
| 3 | Restore critical service fast | P1 resolution | <= 4 hours | 8.6.1 |
| 4 | Keep users satisfied | CSAT | >= 90% | 8.3.3 |
| 5 | Reduce recurring incidents | Repeat incident rate | -10% YoY | 8.6.3 |
| 6 | Keep the portal available | Self-service uptime | >= 99.5% | 8.7.1 |

Objectives are monitored monthly and reviewed at management review (Clause 9.3).`;

const DEMO_RISKREG = `## Risk Register

| ID | Risk | Likelihood | Impact | Response | Owner |
|---|---|---|---|---|---|
| R1 | ISO 20000-1 certification not achieved by end of OY1 | Medium | High | Dedicated ITSM/Quality Manager; phased plan | PM |
| R2 | P1 15-min response not met off-hours | Medium | High | 24x7 staffing + on-call escalation | SDM |
| R3 | CSAT below 90% due to weak knowledge base | Medium | Medium | KCS program; monthly KB health review | ITSM Mgr |
| R4 | CMDB / asset data inaccurate | High | Medium | Scheduled reconciliation; discovery tooling | Config Lead |
| R5 | Key personnel turnover | Medium | Medium | Cross-training; contingency staffing plan | PM |`;

const DEMO_INCIDENT = `# Incident Management
_ISO/IEC 20000-1:2018 — Clause 8.6.1_

## Policy
Meridian restores normal service as quickly as possible following any unplanned interruption, minimizing impact to the ~9,200 Department of Commerce users. All incidents are recorded, prioritized and managed to resolution in ServiceNow.

## Procedure
1. **Detect & log** — capture every incident (phone, email, chat, portal) as a ticket.
2. **Categorize & prioritize** — apply the P1-P4 priority matrix (impact x urgency).
3. **Investigate & diagnose** — Tier 1 attempts first-contact resolution; else escalate to Tier 2.
4. **Resolve & recover** — apply fix or workaround; confirm service restored with the user.
5. **Close** — document resolution, confirm satisfaction, close ticket.
6. **Major incidents (P1)** — invoke bridge, assign Major Incident Manager, send stakeholder comms every 30 min.

## Workflow (step-by-step)
User contact -> Log ticket -> Categorize/Prioritize -> Tier 1 triage -> (resolved? close : escalate Tier 2) -> Resolve -> Confirm with user -> Close -> feed recurring issues to Problem Management.

## RACI Matrix
| Activity | Tier 1 | Tier 2 | Major Incident Mgr | SDM |
|---|---|---|---|---|
| Log & categorize | R | C | I | A |
| Prioritize | R | C | C | A |
| Resolve P3/P4 | R | C | I | A |
| Resolve P1/P2 | C | R | A | A |
| Stakeholder comms (P1) | I | I | R | A |

## Roles & Responsibilities
- **Tier 1 Analyst** — logging, triage, first-contact resolution.
- **Tier 2 Technician** — deeper diagnosis and desk-side support.
- **Major Incident Manager** — coordinates P1 response and communications.
- **Service Delivery Manager** — accountable for incident performance.

## Inputs & Outputs
**Inputs:** user contacts, monitoring alerts, event records, known errors.
**Outputs:** resolved incidents, updated records, workarounds, problem candidates, SLA data.

## KPIs & Targets
| KPI | Target |
|---|---|
| First Contact Resolution | >= 70% |
| P1 resolution | <= 4 hours (>=95%) |
| Mean time to resolve (P3) | <= 3 business days |
| Reopen rate | <= 5% |

## Risks & Controls
| Risk | Control |
|---|---|
| P1 breaches off-hours | 24x7 staffing + on-call escalation |
| Misprioritization | Priority matrix + QA sampling |
| Poor documentation | Mandatory fields + ticket quality audits |

## Required Records & Forms
Incident tickets, major-incident reports, communication logs, monthly SLA reports — retained per the Records Management Procedure.

## Templates & Work Instructions
Major Incident Report template; P1 communication template; Tier 1 triage work instruction; escalation-to-Tier-2 checklist.`;

const DEMO_AUDIT_CHECKLIST = `## Internal Audit Checklist — Clause 8 (Operation of the SMS)

| # | Sub-clause | Audit question | Evidence to sample | Conforms? |
|---|---|---|---|---|
| 1 | 8.2.4 | Is there a current service catalogue? | Service catalogue in ServiceNow | (check) |
| 2 | 8.3.3 | Are SLAs defined, agreed and monitored? | SLA definitions; monthly SLA reports | (check) |
| 3 | 8.5.1 | Are changes assessed, approved and recorded? | Change records; CAB minutes | (check) |
| 4 | 8.6.1 | Are incidents prioritized and resolved to target? | Incident sample across P1-P4 | (check) |
| 5 | 8.6.2 | Are service requests fulfilled via the catalogue? | Request sample; fulfilment times | (check) |
| 6 | 8.6.3 | Is problem management finding root causes? | Problem records; known-error DB | (check) |
| 7 | 8.7.1 | Is availability measured against targets? | Availability reports | (check) |

**Sampling:** minimum 15 incidents, 10 requests, 5 changes across the last 3 months.`;

const DEMO_INTERVIEW = `## Auditor Interview Questions — Clause 8

**Service desk lead**
- Walk me through what happens the moment a user reports a P1 incident.
- How do you decide priority, and who can override it?

**Change coordinator**
- How is a normal change assessed and approved before it reaches production?

**Problem analyst**
- Show me a recent root-cause analysis and the corrective action it produced.

**Service level manager**
- Which SLAs were missed last month, and what happened as a result?`;

const DEMO_CAPACITY = "# Capacity Management\n_ISO/IEC 20000-1:2018 — Clause 8.4.3_\n_Meridian Federal Solutions, LLC · Enterprise IT Service Desk (EITSD) · U.S. Department of Commerce_\n\n## Policy\nMeridian Federal Solutions ensures that the IT service desk and end-user services delivered to the Department of Commerce have sufficient capacity — human, technical, and platform — to meet agreed service levels now and over the planning horizon, at justifiable cost. Capacity is planned proactively against demand rather than reacting to shortfalls. This policy applies to the ServiceNow ITSM platform, the contact center telephony, the self-service portal, and the staffing model supporting approximately 9,200 users across 14 sites. Capacity decisions are evidence-based, documented, reviewed at least quarterly, and fed into budgeting and the continual improvement process.\n\n## Procedure\n1. **Establish capacity requirements.** Translate contractual service levels (ASA ≤ 30s, FCR ≥ 70%, P1 resolution ≤ 4h, self-service availability ≥ 99.5%) and forecast demand into concrete capacity targets for staffing, telephony lines, and platform resources.\n2. **Monitor current capacity and utilization.** Collect utilization data continuously from ServiceNow, the ACD/telephony platform, and portal monitoring (see Inputs).\n3. **Analyze and forecast.** Each month, compare utilization and demand trends against targets; project 3, 6, and 12 months forward, accounting for onboarding waves, seasonal peaks (open season, fiscal year-end), and site changes.\n4. **Identify capacity risks.** Flag any resource trending toward a threshold breach and log it in the capacity risk section of the risk register.\n5. **Plan and recommend actions.** Produce options (add staff, adjust shifts, expand licenses/lines, tune workflows) with cost and lead-time; route to budgeting and the Service Delivery Manager.\n6. **Approve and implement.** Approved changes flow through Change Enablement (clause 8.5.1) before production.\n7. **Review effectiveness.** Confirm the action resolved the constraint; update the Capacity Plan and report results at the monthly service review and quarterly management review.\n\n## Workflow (step-by-step)\nCollect utilization data → Compare to targets → Forecast demand (3/6/12 mo) → Constraint approaching? → **No:** record and continue monitoring → **Yes:** analyze options with cost & lead-time → Recommend in Capacity Plan → Approve via CAB → Implement change → Verify service levels restored → Update Capacity Plan → Report at service review.\n\n## RACI Matrix\n| Activity | Capacity Analyst | Service Delivery Manager | Program Manager | Customer (COR) |\n|---|---|---|---|---|\n| Monitor utilization & collect data | R | A | I | I |\n| Forecast demand | R | A | C | C |\n| Identify capacity risks | R | A | I | I |\n| Produce Capacity Plan | R | A | C | I |\n| Approve capacity investment | C | R | A | C |\n| Implement approved change | C | A | I | I |\n| Report performance | R | A | I | I |\n\n_R = Responsible, A = Accountable, C = Consulted, I = Informed._\n\n## Roles & Responsibilities\n- **Capacity Analyst** — monitors utilization, forecasts demand, maintains the Capacity Plan, raises capacity risks.\n- **Service Delivery Manager** — accountable for capacity meeting service levels; approves operational actions; owns the plan.\n- **Program Manager** — approves capacity investments with budget impact; interfaces with the Government.\n- **Contracting Officer's Representative (COR)** — consulted on demand changes (new sites, headcount, mission surges).\n\n## Inputs & Outputs\n**Inputs:** ServiceNow ticket volumes and trends; ACD/telephony statistics (call volumes, ASA, abandonment, concurrency); self-service portal usage and availability; staffing rosters and schedules; ServiceNow license/instance utilization; onboarding/offboarding forecasts; known upcoming projects and mission events; historical seasonal patterns.\n\n**Outputs:** the Capacity Plan; monthly capacity report; capacity risk entries; investment/change recommendations; updated forecasts; inputs to budgeting (clause 8.4.1) and continual improvement (clause 10.2).\n\n## KPIs & Targets\n| KPI | Definition | Target |\n|---|---|---|\n| Capacity-related SLA breaches | SLA misses attributable to insufficient capacity | 0 per quarter |\n| Forecast accuracy | Actual vs. forecast demand (± variance) | Within ± 10% |\n| Telephony headroom at peak | Spare concurrent-call capacity at busiest hour | ≥ 15% |\n| Staffing coverage vs. schedule | Scheduled agents ÷ required agents (Erlang-based) | ≥ 100% in all intervals |\n| Self-service portal availability | Monthly uptime of the portal | ≥ 99.5% |\n| Capacity Plan currency | Plan reviewed and updated on schedule | Quarterly, 100% on time |\n\n## Risks & Controls\n| Risk | Impact | Control |\n|---|---|---|\n| Onboarding wave spikes ticket volume beyond staffing | P1/P2 SLA breaches, long queues | Demand forecast tied to HR onboarding calendar; flex/on-call staffing plan |\n| Telephony concurrency saturates at peak | High ASA, abandonment > 5% | Peak headroom target ≥ 15%; ACD monitoring with alert thresholds |\n| ServiceNow license/instance limits reached | Ticketing degraded or blocked | Monthly license utilization review; renewal lead-time tracked |\n| Self-service portal outage during peak | Availability < 99.5%, demand shifts to phones | Redundancy and monitoring; capacity buffer on dependent services |\n| Forecast inaccuracy | Over- or under-provisioning, cost or SLA risk | Monthly forecast-accuracy KPI; rolling recalibration |\n\n## Required Records & Forms\n- **Capacity Plan** (living document; reviewed quarterly) — retained for the life of the contract plus one option year.\n- **Monthly Capacity Report** — retained 24 months.\n- **Capacity forecast worksheets** (staffing/Erlang, telephony, license) — retained 24 months.\n- **Capacity risk log entries** — retained until closed plus 12 months.\n- **Capacity investment/change recommendations and approvals** — retained per Records Management Procedure (clause 7.5).\n\n## Templates & Work Instructions\n- **Capacity Plan template** — scope, current capacity baseline, demand forecast (3/6/12 mo), constraints, recommended actions, cost/lead-time, review log.\n- **Monthly Capacity Report template** — utilization vs. target by resource, forecast vs. actual, risks, actions, KPI summary.\n- **Work Instruction: monthly capacity review** — data pull steps from ServiceNow and the ACD, calculation method, threshold checks, sign-off.\n- **Work Instruction: staffing (Erlang C) calculation** — inputs, tool/formula, interval coverage check, escalation if coverage < 100%.\n\n---\n_Revision 1.0 · Prepared by Capacity Analyst · Approved by Service Delivery Manager. Reviewed at least quarterly and upon significant change to demand, scope, or the operating environment._\n";

const DEMO_FULL = {"generated":{"smpolicy":{"title":"Service Management Policy","clause":"5.2","content":"# Service Management Policy\n_ISO/IEC 20000-1:2018 — Clause 5.2 · Meridian Federal Solutions_\n\n## 1. Purpose\nThis policy sets out Meridian Federal Solutions, LLC's commitment to delivering the Enterprise IT Service Desk (EITSD) contract to U.S. Department of Commerce under a service management system (SMS) conforming to ISO/IEC 20000-1:2018.\n\n## 2. Scope\nApplies to all services, personnel and processes supporting approximately 9,200 users across 14 sites, delivered on ServiceNow (24x7x365).\n\n## 3. Policy Statements\n- We manage services through defined, measurable and continually improving processes.\n- We meet or exceed all contractual service levels and report performance transparently.\n- We restore service quickly, reduce recurring incidents, and manage change safely.\n- We protect customer information in line with applicable security and privacy obligations.\n- We achieve and maintain ISO/IEC 20000-1 certification.\n\n## 4. Authority & Approval\nThis policy is issued by top management, is communicated to all personnel, and is reviewed at least annually.\n\n| Version | Date | Author | Approved by |\n|---|---|---|---|\n| 1.0 | (current) | ITSM / Quality Manager | Program Manager |"},"scope":{"title":"Scope Statement","clause":"4.3","content":"# Scope of the Service Management System\n_ISO/IEC 20000-1:2018 — Clause 4.3 · Meridian Federal Solutions_\n\n**Organization:** Meridian Federal Solutions, LLC\n**Customer:** U.S. Department of Commerce\n**Contract:** Enterprise IT Service Desk (EITSD) contract\n**Platform:** ServiceNow\n\n## Services in scope\nTier 1 and Tier 2 IT service desk and end-user support for approximately 9,200 users across 14 sites, delivered 24x7x365.\n\n## Processes in scope\nIncident, service request, problem, change, configuration, asset, knowledge, capacity, availability, continuity, service level, supplier, release, monitoring & reporting, and continual improvement.\n\n## Boundaries & exclusions\nUnderlying network and data-centre operations provided by the customer are interfaces to, not part of, this SMS. Where services are delivered by subcontractors, they are governed through Supplier Management.\n\n## Governing standard\nISO/IEC 20000-1:2018, clauses 4–10."},"context":{"title":"Context of the Organization","clause":"4.1","content":"# Context of the Organization\n_ISO/IEC 20000-1:2018 — Clause 4.1 · Meridian Federal Solutions_\n\nThe following internal and external issues are relevant to Meridian Federal Solutions's ability to deliver the Enterprise IT Service Desk (EITSD) contract and are reviewed at each management review.\n\n## External issues\n| Issue | Relevance to the SMS |\n|---|---|\n| Contractual & regulatory obligations (customer policy, security mandates) | Drive required controls, reporting and certification |\n| Customer expectations for uptime and responsiveness | Set service-level targets |\n| Labour market for qualified service-desk staff | Affects staffing capacity and continuity |\n| Technology change (ServiceNow, automation, AI) | Creates improvement opportunities and training needs |\n| Cyber-threat landscape | Drives security and continuity requirements |\n\n## Internal issues\n| Issue | Relevance to the SMS |\n|---|---|\n| Maturity of ITSM tooling and processes | Affects consistency and audit-readiness |\n| Staffing levels and skills coverage | Affects SLA achievement |\n| Knowledge retention across shifts | Affects first-contact resolution |\n| Governance and management commitment | Affects resourcing and improvement |\n\n## Review\nReviewed at least annually and on significant change to the contract, organization or services."},"parties":{"title":"Interested Parties Register","clause":"4.2","content":"# Interested Parties Register\n_ISO/IEC 20000-1:2018 — Clause 4.2 · Meridian Federal Solutions_\n\n| Interested party | Needs & expectations | How the SMS meets them |\n|---|---|---|\n| U.S. Department of Commerce (COR / agency) | Meets SLAs; transparent reporting; certification maintained | Monthly SLA reports; service reviews; certified SMS |\n| End users (~9,200) | Fast, correct resolution; easy self-service | Incident & request processes; knowledge base; portal |\n| Meridian Federal Solutions executive / Program Manager | Compliant delivery; profitable, low-risk operation | Governance, risk register, management review |\n| Service-desk employees | Clear roles; training; workable processes | Roles & competency matrix; training plan |\n| Suppliers / subcontractors | Clear requirements; timely information | Supplier Management; underpinning contracts |\n| Certification body | Evidence of conformity to ISO/IEC 20000-1 | Documented SMS; internal audits; records |\n| Regulators (security/privacy) | Compliance with applicable mandates | Security controls; records; audits |\n\n## Review\nReviewed at least annually and when parties or their requirements change."},"leadership":{"title":"Leadership & Responsibilities","clause":"5.1 / 5.3","content":"# Leadership Responsibilities\n_ISO/IEC 20000-1:2018 — Clauses 5.1 & 5.3 · Meridian Federal Solutions_\n\n## Management commitment\nTop management is accountable for the SMS: it sets the policy and objectives, ensures resources, promotes continual improvement, and reviews performance at management reviews.\n\n## Roles, responsibilities & authorities\n| Role | Responsibility | Authority |\n|---|---|---|\n| Program Manager | Accountable for the SMS and the U.S. Department of Commerce relationship | Approves policy, budget, major decisions |\n| Service Delivery Manager | Owns day-to-day operations and SLA performance | Directs operations; approves service changes |\n| ITSM / Quality Manager | Maintains the SMS; runs internal audits and improvement | Manages documents, audits, corrective actions |\n| Information Security Officer | Owns security obligations within the SMS | Approves security controls and exceptions |\n| Process Owners | Own individual ITSM processes | Direct their process; raise improvements |\n\n## Review\nReviewed at least annually and on organizational change."},"objectives":{"title":"Service Management Objectives","clause":"6.2","content":"# Service Management Objectives\n_ISO/IEC 20000-1:2018 — Clause 6.2 · Meridian Federal Solutions_\n\nObjectives are measurable, aligned to the policy and the U.S. Department of Commerce contract, and reviewed monthly.\n\n| Objective | Measure | Target | Owner |\n|---|---|---|---|\n| Meet service levels | SLA targets achieved | ≥ 95% | Service Level Manager |\n| Resolve at first contact | First Contact Resolution | ≥ 70% | Incident Manager |\n| Keep users satisfied | Customer satisfaction (CSAT) | ≥ 90% | Service Delivery Manager |\n| Change safely | Change success rate | ≥ 98% | Change Manager |\n| Reduce recurring issues | Repeat incidents | -10% YoY | Problem Manager |\n| Achieve certification | ISO/IEC 20000-1 certified | Within 12 months | Program Manager |\n\nObjectives are monitored monthly and reviewed at management review (clause 9.3)."},"riskreg":{"title":"Risk Register","clause":"6.1","content":"# Risk Register\n_ISO/IEC 20000-1:2018 — Clause 6.1 · Meridian Federal Solutions_\n\n| ID | Risk | Likelihood | Impact | Control / Treatment | Owner |\n|---|---|---|---|---|---|\n| R1 | Insufficient staffing to meet the contracted service hours (24x7x365) | Medium | High | Capacity forecasting; flex staffing; on-call coverage | Service Delivery Manager |\n| R2 | Major change causes an outage | Low | High | CAB review; risk assessment; back-out plans | Change Manager |\n| R3 | ServiceNow outage disrupts service | Low | High | Availability & continuity plans; monitoring | Availability Manager |\n| R4 | Loss of key knowledge on staff turnover | Medium | Medium | Knowledge base; KCS; cross-training | Knowledge Manager |\n| R5 | Supplier underperformance affects SLAs | Medium | Medium | Underpinning contracts; supplier reviews | Supplier Manager |\n| R6 | Security incident affecting customer data | Low | High | Security controls; incident response; training | Information Security Officer |\n\nRisks are reviewed at least quarterly and at management review."},"oppreg":{"title":"Opportunity Register","clause":"6.1","content":"# Opportunity Register\n_ISO/IEC 20000-1:2018 — Clause 6.1 · Meridian Federal Solutions_\n\n| ID | Opportunity | Expected benefit | Owner | Status |\n|---|---|---|---|---|\n| O1 | Expand the self-service catalogue in ServiceNow | Deflect ~15% of routine requests | Request Fulfilment Lead | In progress |\n| O2 | Add knowledge articles for the top 20 incidents | Raise FCR by ~5% | Knowledge Manager | Planned |\n| O3 | Automate password-reset requests | Faster fulfilment; lower load | Service Delivery Manager | Under review |\n| O4 | Proactive problem analysis on P1 trends | Fewer repeat incidents | Problem Manager | Planned |\n\nReviewed at management review alongside the risk register."},"commplan":{"title":"Communication Plan","clause":"7.4","content":"# Communication Plan\n_ISO/IEC 20000-1:2018 — Clause 7.4 · Meridian Federal Solutions_\n\n| Communication | Audience | Frequency | Channel | Owner |\n|---|---|---|---|---|\n| SLA performance report | U.S. Department of Commerce (COR) | Monthly | Written report | Service Level Manager |\n| Service review | Customer & delivery team | Monthly | Meeting + minutes | Service Delivery Manager |\n| Management review | Top management | Quarterly | Meeting + minutes | Program Manager |\n| Major incident notification | Affected users & customer | On occurrence | ServiceNow + email/phone | Incident Manager |\n| Change notifications | Affected stakeholders | Per change | ServiceNow + email | Change Manager |\n| Team briefing | Service-desk staff | Weekly | Stand-up | Service Delivery Manager |\n| Customer satisfaction survey | End users | Continuous / quarterly rollup | Survey tool | Service Level Manager |"},"competency":{"title":"Competency Matrix","clause":"7.2","content":"# Competency Matrix\n_ISO/IEC 20000-1:2018 — Clause 7.2 · Meridian Federal Solutions_\n\n| Role | Required competencies | Certifications | Status |\n|---|---|---|---|\n| Service Delivery Manager | Service management leadership; SLA governance | ITIL 4; PMP (desired) | Met |\n| Incident Manager | Incident & major-incident handling | ITIL 4 | Met |\n| Change Manager | Change/risk assessment; CAB facilitation | ITIL 4 | Met |\n| Problem Manager | Root-cause analysis; trend analysis | ITIL 4 | In progress |\n| Tier 1 Analyst | ServiceNow use; customer service; triage | ITIL 4 Foundation | In progress |\n| Tier 2 Engineer | Advanced troubleshooting; platform expertise | Relevant technical certs | Met |\n| ITSM / Quality Manager | SMS maintenance; internal auditing | ISO 20000 / auditor training | Met |\n\nGaps drive the Training Plan. Reviewed at least annually."},"training":{"title":"Training Plan","clause":"7.2 / 7.3","content":"# Training Plan\n_ISO/IEC 20000-1:2018 — Clauses 7.2 & 7.3 · Meridian Federal Solutions_\n\n## Onboarding (first 90 days)\n1. U.S. Department of Commerce account, security and privacy briefing.\n2. ServiceNow tool training and shadowing.\n3. Process training for the analyst's role (incident, request, knowledge).\n4. ITIL 4 Foundation enrolment.\n\n## Ongoing training\n| Topic | Audience | Frequency |\n|---|---|---|\n| ISO 20000 SMS awareness | All staff | Annual |\n| Security & privacy refresher | All staff | Annual |\n| Process/tool updates | Affected roles | On change |\n| Major-incident drill | Incident team | Semi-annual |\n| Knowledge-Centered Service | Analysts | Onboarding + annual |\n\nTraining records are retained per the Records Management Procedure."},"doccontrol":{"title":"Document Control Procedure","clause":"7.5","content":"# Document Control Procedure\n_ISO/IEC 20000-1:2018 — Clause 7.5 · Meridian Federal Solutions_\n\n## Purpose\nEnsure the right version of each controlled document is available where needed and that obsolete versions are not used.\n\n## Procedure\n1. **Create** — the author drafts using the approved template.\n2. **Review** — the ITSM/Quality Manager reviews for accuracy and completeness.\n3. **Approve** — the accountable owner approves before publication.\n4. **Version** — versions follow Major.Minor (e.g. 1.0, 1.1); version, date and approver are recorded.\n5. **Distribute** — the approved version is published to the controlled repository.\n6. **Review cycle** — each document is reviewed at least annually and on significant change.\n7. **Retire** — superseded documents are marked obsolete and archived.\n\n| Control | Rule |\n|---|---|\n| Naming | [DocType] - [Title] - v[version] |\n| Storage | Controlled repository with access control |\n| Change record | Version table in each document |\n| Retention | Per the Records Management Procedure |"},"records":{"title":"Records Management Procedure","clause":"7.5","content":"# Records Management Procedure\n_ISO/IEC 20000-1:2018 — Clause 7.5 · Meridian Federal Solutions_\n\n## Purpose\nDefine how records that provide evidence of conformity and effective SMS operation are identified, stored, protected, retained and disposed of.\n\n| Record type | Owner | Storage | Retention |\n|---|---|---|---|\n| Incident / request records | Service Delivery Manager | ServiceNow | Contract term + 1 year |\n| Change records & CAB minutes | Change Manager | ServiceNow | Contract term + 1 year |\n| Problem / known-error records | Problem Manager | ServiceNow | Contract term |\n| SLA & performance reports | Service Level Manager | Repository | Contract term + 1 year |\n| Management review minutes | Program Manager | Repository | Contract term + 1 year |\n| Internal audit reports | ITSM / Quality Manager | Repository | Contract term + 1 year |\n| Training records | Service Delivery Manager | HR system | Employment + per policy |\n\nRecords are protected against loss and unauthorised change, and disposed of securely at end of retention."},"proc_incident":{"title":"Incident Management — Full Pack","clause":"8.6.1","content":"# Incident Management\n_ISO/IEC 20000-1:2018 — Clause 8.6.1 · Meridian Federal Solutions · U.S. Department of Commerce_\n\n## Policy\nIt is Meridian Federal Solutions's policy to restore normal service operation as quickly as possible after any unplanned interruption. This process operates across ServiceNow supporting approximately 9,200 users at 14 sites (24x7x365), is defined, measured and continually improved, and supports the contractual service levels and ISO/IEC 20000-1 certification.\n\n## Procedure\n1. Detect and log every incident in ServiceNow with impact and urgency.\n2. Categorise and set priority P1–P4 using the priority matrix.\n3. Attempt first-contact resolution at Tier 1; escalate to Tier 2 where criteria are met.\n4. For P1/major incidents, invoke the major-incident procedure and open a bridge.\n5. Keep users informed; restore service and confirm resolution with the user.\n6. Close with a documented resolution and raise a problem where warranted.\n\n## Workflow\nUser contact or monitoring alert → log & categorise → prioritise → diagnose/resolve or escalate → (major-incident bridge if P1) → restore & confirm → close → feed problem & reporting.\n\n## RACI Matrix\n| Activity | Incident Manager | Analyst / Technician | Service Delivery Manager | Program Manager |\n|---|---|---|---|---|\n| Log & categorise the incident | A | R | C | I |\n| Prioritise & assign | A | R | C | I |\n| Resolve or escalate | R | R | A | I |\n| Coordinate a major (P1) incident | A | C | R | I |\n| Communicate to users & customer | R | C | A | C |\n| Review trends & report | R | C | A | I |\n\n_R = Responsible, A = Accountable, C = Consulted, I = Informed._\n\n## Roles & Responsibilities\n- **Incident Manager** — owns and runs Incident Management; accountable for its outcomes and reporting.\n- **Analyst / Technician** — performs the day-to-day work and records it in ServiceNow.\n- **Service Delivery Manager** — accountable for performance against the service levels.\n- **Program Manager** — owns the U.S. Department of Commerce relationship and approves investment.\n\n## Inputs & Outputs\n**Inputs:** user contacts, monitoring alerts, known errors.\n**Outputs:** restored service, incident records, problem candidates, SLA data.\n\n## KPIs & Targets\n| KPI | Target |\n|---|---|\n| First Contact Resolution | ≥ 70% |\n| P1 resolution within SLA | ≥ 95% |\n| Reopen rate | ≤ 5% |\n\n## Risks & Controls\n| Risk | Control |\n|---|---|\n| P1 raised outside core hours | Coverage aligned to contracted hours; on-call escalation for P1 |\n| Mis-prioritised tickets | Priority matrix + monthly QA sampling |\n\n## Required Records\nIncident tickets, major-incident reports, user communications, and the monthly incident report. Records are retained per the Records Management Procedure (clause 7.5).\n\n## Review\nReviewed at least annually and on significant change. Revision 1.0 — prepared by the Incident Manager, approved by the Service Delivery Manager."},"proc_request":{"title":"Service Request Management — Full Pack","clause":"8.6.2","content":"# Service Request Management\n_ISO/IEC 20000-1:2018 — Clause 8.6.2 · Meridian Federal Solutions · U.S. Department of Commerce_\n\n## Policy\nIt is Meridian Federal Solutions's policy to fulfil standard service requests through a published catalogue within agreed timeframes. This process operates across ServiceNow supporting approximately 9,200 users at 14 sites (24x7x365), is defined, measured and continually improved, and supports the contractual service levels and ISO/IEC 20000-1 certification.\n\n## Procedure\n1. Publish request types in the ServiceNow service catalogue with descriptions and target times.\n2. Log and validate each request against catalogue entitlements.\n3. Route for approval where the request type requires it.\n4. Fulfil using the standard model for that request type.\n5. Confirm completion with the requester and capture satisfaction.\n6. Update the catalogue or knowledge base where a gap is revealed.\n\n## Workflow\nCatalogue request → validate → approval (if required) → fulfil per standard model → confirm with requester → close & capture satisfaction.\n\n## RACI Matrix\n| Activity | Request Fulfilment Lead | Analyst / Technician | Service Delivery Manager | Program Manager |\n|---|---|---|---|---|\n| Maintain the service catalogue | A | C | R | I |\n| Validate & route the request | A | R | C | I |\n| Approve (where required) | I | I | R | A |\n| Fulfil the request | R | R | A | I |\n| Confirm & close | R | R | A | I |\n\n_R = Responsible, A = Accountable, C = Consulted, I = Informed._\n\n## Roles & Responsibilities\n- **Request Fulfilment Lead** — owns and runs Service Request Management; accountable for its outcomes and reporting.\n- **Analyst / Technician** — performs the day-to-day work and records it in ServiceNow.\n- **Service Delivery Manager** — accountable for performance against the service levels.\n- **Program Manager** — owns the U.S. Department of Commerce relationship and approves investment.\n\n## Inputs & Outputs\n**Inputs:** catalogue requests, approvals, entitlements.\n**Outputs:** fulfilled requests, provisioning records, satisfaction data.\n\n## KPIs & Targets\n| KPI | Target |\n|---|---|\n| Fulfilment within SLA | ≥ 90% |\n| Catalogue coverage of routine requests | ≥ 95% |\n| Approval cycle time | ≤ 1 business day |\n\n## Risks & Controls\n| Risk | Control |\n|---|---|\n| Approvals delay fulfilment | Defined approval matrix in the tool |\n| Off-catalogue requests bypass the process | Quarterly catalogue review and intake control |\n\n## Required Records\nRequest records, approval logs, catalogue definitions, and the monthly request report. Records are retained per the Records Management Procedure (clause 7.5).\n\n## Review\nReviewed at least annually and on significant change. Revision 1.0 — prepared by the Request Fulfilment Lead, approved by the Service Delivery Manager."},"proc_problem":{"title":"Problem Management — Full Pack","clause":"8.6.3","content":"# Problem Management\n_ISO/IEC 20000-1:2018 — Clause 8.6.3 · Meridian Federal Solutions · U.S. Department of Commerce_\n\n## Policy\nIt is Meridian Federal Solutions's policy to reduce recurring and high-impact incidents by finding and removing root causes. This process operates across ServiceNow supporting approximately 9,200 users at 14 sites (24x7x365), is defined, measured and continually improved, and supports the contractual service levels and ISO/IEC 20000-1 certification.\n\n## Procedure\n1. Identify problems from incident trends, major incidents and monitoring.\n2. Log and prioritise the problem by impact and recurrence.\n3. Perform root-cause analysis using a structured method (e.g. 5 Whys, Ishikawa).\n4. Record known errors and workarounds in the known-error database.\n5. Raise changes to implement permanent fixes and track them to closure.\n6. Verify effectiveness after the fix and close the problem.\n\n## Workflow\nIncident trend / major incident → log problem → root-cause analysis → known error + workaround → change for permanent fix → verify → close.\n\n## RACI Matrix\n| Activity | Problem Manager | Analyst / Technician | Service Delivery Manager | Program Manager |\n|---|---|---|---|---|\n| Identify & log problems | A | R | C | I |\n| Perform root-cause analysis | A | R | C | I |\n| Maintain the known-error database | R | R | C | I |\n| Raise permanent-fix changes | R | C | A | I |\n| Verify effectiveness & close | R | C | A | I |\n\n_R = Responsible, A = Accountable, C = Consulted, I = Informed._\n\n## Roles & Responsibilities\n- **Problem Manager** — owns and runs Problem Management; accountable for its outcomes and reporting.\n- **Analyst / Technician** — performs the day-to-day work and records it in ServiceNow.\n- **Service Delivery Manager** — accountable for performance against the service levels.\n- **Program Manager** — owns the U.S. Department of Commerce relationship and approves investment.\n\n## Inputs & Outputs\n**Inputs:** incident trends, major-incident outputs, monitoring data.\n**Outputs:** known errors, workarounds, change requests, fewer repeat incidents.\n\n## KPIs & Targets\n| KPI | Target |\n|---|---|\n| Repeat-incident reduction | -10% year on year |\n| Known errors documented | 100% of open problems |\n| RCA completed on P1s | 100% within 5 business days |\n\n## Risks & Controls\n| Risk | Control |\n|---|---|\n| Analysis without a permanent fix | Corrective actions tracked to closure |\n| No capacity for proactive analysis | Ring-fenced problem-management time |\n\n## Required Records\nProblem records, RCA reports, the known-error database, and corrective-action tracking. Records are retained per the Records Management Procedure (clause 7.5).\n\n## Review\nReviewed at least annually and on significant change. Revision 1.0 — prepared by the Problem Manager, approved by the Service Delivery Manager."},"proc_change":{"title":"Change Enablement — Full Pack","clause":"8.5.1","content":"# Change Enablement\n_ISO/IEC 20000-1:2018 — Clause 8.5.1 · Meridian Federal Solutions · U.S. Department of Commerce_\n\n## Policy\nIt is Meridian Federal Solutions's policy to make changes with the least disruption and risk while enabling needed change quickly. This process operates across ServiceNow supporting approximately 9,200 users at 14 sites (24x7x365), is defined, measured and continually improved, and supports the contractual service levels and ISO/IEC 20000-1 certification.\n\n## Procedure\n1. Record and classify each change as standard, normal or emergency.\n2. Assess risk and impact and define a back-out plan.\n3. Route normal changes to the Change Advisory Board (CAB) for approval.\n4. Schedule approved changes to minimise disruption and communicate to stakeholders.\n5. Implement with the back-out plan ready and verify success.\n6. Conduct a post-implementation review (PIR) and capture lessons.\n\n## Workflow\nChange request → classify → risk/impact + back-out plan → CAB approval (normal) → schedule & communicate → implement → verify → post-implementation review.\n\n## RACI Matrix\n| Activity | Change Manager | Analyst / Technician | Service Delivery Manager | Program Manager |\n|---|---|---|---|---|\n| Raise & classify the change | I | R | A | I |\n| Assess risk & impact | A | R | C | I |\n| Approve at CAB | C | I | R | A |\n| Implement with back-out | R | R | A | I |\n| Post-implementation review | A | C | R | I |\n\n_R = Responsible, A = Accountable, C = Consulted, I = Informed._\n\n## Roles & Responsibilities\n- **Change Manager** — owns and runs Change Enablement; accountable for its outcomes and reporting.\n- **Analyst / Technician** — performs the day-to-day work and records it in ServiceNow.\n- **Service Delivery Manager** — accountable for performance against the service levels.\n- **Program Manager** — owns the U.S. Department of Commerce relationship and approves investment.\n\n## Inputs & Outputs\n**Inputs:** change requests, release plans, risk assessments.\n**Outputs:** approved & scheduled changes, back-out plans, PIR results.\n\n## KPIs & Targets\n| KPI | Target |\n|---|---|\n| Change success rate | ≥ 98% |\n| Emergency changes | ≤ 5% of total |\n| Unauthorised changes | 0 |\n\n## Risks & Controls\n| Risk | Control |\n|---|---|\n| Change causes an outage | Risk assessment + back-out plan + CAB approval |\n| Process bypass / unauthorised change | Discovery reconciliation and audit trail |\n\n## Required Records\nChange records, CAB minutes, risk assessments and back-out plans, and PIR reports. Records are retained per the Records Management Procedure (clause 7.5).\n\n## Review\nReviewed at least annually and on significant change. Revision 1.0 — prepared by the Change Manager, approved by the Service Delivery Manager."},"proc_config":{"title":"Configuration Management — Full Pack","clause":"8.2.6","content":"# Configuration Management\n_ISO/IEC 20000-1:2018 — Clause 8.2.6 · Meridian Federal Solutions · U.S. Department of Commerce_\n\n## Policy\nIt is Meridian Federal Solutions's policy to maintain accurate information about configuration items (CIs) and their relationships. This process operates across ServiceNow supporting approximately 9,200 users at 14 sites (24x7x365), is defined, measured and continually improved, and supports the contractual service levels and ISO/IEC 20000-1 certification.\n\n## Procedure\n1. Define CI types, attributes and relationships in the CMDB model.\n2. Identify, record and baseline CIs.\n3. Control changes to CI records through Change Enablement.\n4. Run automated discovery and reconcile against the CMDB monthly.\n5. Audit CMDB accuracy and correct discrepancies.\n6. Report CMDB health and coverage.\n\n## Workflow\nCI model → identify & baseline CIs → control via change → discovery & reconciliation → accuracy audit → report.\n\n## RACI Matrix\n| Activity | Configuration Manager | Analyst / Technician | Service Delivery Manager | Program Manager |\n|---|---|---|---|---|\n| Define the CI model | A | C | R | I |\n| Record & baseline CIs | A | R | C | I |\n| Reconcile against discovery | R | R | C | I |\n| Audit CMDB accuracy | A | R | C | I |\n| Report CMDB health | R | C | A | I |\n\n_R = Responsible, A = Accountable, C = Consulted, I = Informed._\n\n## Roles & Responsibilities\n- **Configuration Manager** — owns and runs Configuration Management; accountable for its outcomes and reporting.\n- **Analyst / Technician** — performs the day-to-day work and records it in ServiceNow.\n- **Service Delivery Manager** — accountable for performance against the service levels.\n- **Program Manager** — owns the U.S. Department of Commerce relationship and approves investment.\n\n## Inputs & Outputs\n**Inputs:** discovery data, change records, asset feeds.\n**Outputs:** accurate CMDB, relationship maps, health reports.\n\n## KPIs & Targets\n| KPI | Target |\n|---|---|\n| CMDB accuracy | ≥ 95% |\n| Unauthorised CI changes | 0 |\n| Reconciliation cadence | Monthly |\n\n## Risks & Controls\n| Risk | Control |\n|---|---|\n| Stale CI data | Automated discovery + scheduled audits |\n| Undefined relationships | Defined CI model and ownership |\n\n## Required Records\nCMDB baselines, reconciliation results, and CMDB audit reports. Records are retained per the Records Management Procedure (clause 7.5).\n\n## Review\nReviewed at least annually and on significant change. Revision 1.0 — prepared by the Configuration Manager, approved by the Service Delivery Manager."},"proc_asset":{"title":"Asset Management — Full Pack","clause":"8.2.5","content":"# Asset Management\n_ISO/IEC 20000-1:2018 — Clause 8.2.5 · Meridian Federal Solutions · U.S. Department of Commerce_\n\n## Policy\nIt is Meridian Federal Solutions's policy to manage IT assets across their lifecycle to control cost, risk and compliance. This process operates across ServiceNow supporting approximately 9,200 users at 14 sites (24x7x365), is defined, measured and continually improved, and supports the contractual service levels and ISO/IEC 20000-1 certification.\n\n## Procedure\n1. Record assets at receipt with owner, location and status.\n2. Track assignment, moves and status changes through the lifecycle.\n3. Manage software licences and entitlements and reconcile against usage.\n4. Perform scheduled inventory reconciliation.\n5. Manage secure retirement and disposal per policy.\n6. Report asset and licence position.\n\n## Workflow\nReceipt → assign & track → licence management → inventory reconciliation → secure disposal → report.\n\n## RACI Matrix\n| Activity | Asset Manager | Analyst / Technician | Service Delivery Manager | Program Manager |\n|---|---|---|---|---|\n| Record & tag assets | A | R | C | I |\n| Track assignments & moves | R | R | C | I |\n| Manage licences & entitlements | A | R | C | I |\n| Reconcile inventory | R | R | C | I |\n| Manage disposal | A | R | C | I |\n\n_R = Responsible, A = Accountable, C = Consulted, I = Informed._\n\n## Roles & Responsibilities\n- **Asset Manager** — owns and runs Asset Management; accountable for its outcomes and reporting.\n- **Analyst / Technician** — performs the day-to-day work and records it in ServiceNow.\n- **Service Delivery Manager** — accountable for performance against the service levels.\n- **Program Manager** — owns the U.S. Department of Commerce relationship and approves investment.\n\n## Inputs & Outputs\n**Inputs:** procurement data, assignments, discovery.\n**Outputs:** asset register, licence position, disposal records.\n\n## KPIs & Targets\n| KPI | Target |\n|---|---|\n| Inventory accuracy | ≥ 98% |\n| Software licence compliance | 100% |\n| Disposal per policy | 100% |\n\n## Risks & Controls\n| Risk | Control |\n|---|---|\n| Licence non-compliance | Entitlement tracking and periodic true-up |\n| Lost or untracked assets | Barcoding and periodic audits |\n\n## Required Records\nAsset register, licence records, disposal certificates, and reconciliation reports. Records are retained per the Records Management Procedure (clause 7.5).\n\n## Review\nReviewed at least annually and on significant change. Revision 1.0 — prepared by the Asset Manager, approved by the Service Delivery Manager."},"proc_knowledge":{"title":"Knowledge Management — Full Pack","clause":"7.6","content":"# Knowledge Management\n_ISO/IEC 20000-1:2018 — Clause 7.6 · Meridian Federal Solutions · U.S. Department of Commerce_\n\n## Policy\nIt is Meridian Federal Solutions's policy to capture, share and improve knowledge to raise first-contact resolution and self-service success. This process operates across ServiceNow supporting approximately 9,200 users at 14 sites (24x7x365), is defined, measured and continually improved, and supports the contractual service levels and ISO/IEC 20000-1 certification.\n\n## Procedure\n1. Identify knowledge needs from incident and request trends.\n2. Create and review articles using Knowledge-Centered Service (KCS).\n3. Publish articles to agents and the self-service portal.\n4. Maintain accuracy and retire stale content on a schedule.\n5. Measure article usage, value and self-service deflection.\n6. Feed gaps back into article creation.\n\n## Workflow\nTicket trends → draft article (KCS) → review → publish (agent + portal) → measure use → review/retire.\n\n## RACI Matrix\n| Activity | Knowledge Manager | Analyst / Technician | Service Delivery Manager | Program Manager |\n|---|---|---|---|---|\n| Identify knowledge needs | R | R | A | I |\n| Create & review articles | A | R | C | I |\n| Publish to the portal | A | R | C | I |\n| Review & retire content | A | R | C | I |\n| Measure value | R | C | A | I |\n\n_R = Responsible, A = Accountable, C = Consulted, I = Informed._\n\n## Roles & Responsibilities\n- **Knowledge Manager** — owns and runs Knowledge Management; accountable for its outcomes and reporting.\n- **Analyst / Technician** — performs the day-to-day work and records it in ServiceNow.\n- **Service Delivery Manager** — accountable for performance against the service levels.\n- **Program Manager** — owns the U.S. Department of Commerce relationship and approves investment.\n\n## Inputs & Outputs\n**Inputs:** incidents, requests, agent input.\n**Outputs:** knowledge articles, self-help content, usage metrics.\n\n## KPIs & Targets\n| KPI | Target |\n|---|---|\n| FCR uplift from the knowledge base | ≥ 5% year on year |\n| Article accuracy at review | ≥ 95% |\n| Self-service deflection | Increasing each quarter |\n\n## Risks & Controls\n| Risk | Control |\n|---|---|\n| Stale or incorrect articles | Scheduled review cycle and feedback loop |\n| Low adoption | KCS embedded in the ticket workflow |\n\n## Required Records\nThe knowledge base, article review logs, and knowledge-health reports. Records are retained per the Records Management Procedure (clause 7.5).\n\n## Review\nReviewed at least annually and on significant change. Revision 1.0 — prepared by the Knowledge Manager, approved by the Service Delivery Manager."},"proc_capacity":{"title":"Capacity Management — Full Pack","clause":"8.4.3","content":"# Capacity Management\n_ISO/IEC 20000-1:2018 — Clause 8.4.3 · Meridian Federal Solutions · U.S. Department of Commerce_\n\n## Policy\nIt is Meridian Federal Solutions's policy to ensure sufficient staffing, telephony and platform capacity to meet service levels at justifiable cost. This process operates across ServiceNow supporting approximately 9,200 users at 14 sites (24x7x365), is defined, measured and continually improved, and supports the contractual service levels and ISO/IEC 20000-1 certification.\n\n## Procedure\n1. Set capacity targets from SLAs and forecast demand, including onboarding calendars.\n2. Monitor staffing, telephony/queue and platform utilisation.\n3. Forecast 3, 6 and 12 months ahead.\n4. Flag constraints as capacity risks with lead time and cost.\n5. Recommend actions and implement via Change Enablement.\n6. Review at the monthly capacity review.\n\n## Workflow\nSLA + demand → monitor utilisation → forecast → flag constraints → recommend → implement via change → review.\n\n## RACI Matrix\n| Activity | Capacity Analyst | Analyst / Technician | Service Delivery Manager | Program Manager |\n|---|---|---|---|---|\n| Set capacity targets | A | C | R | I |\n| Monitor utilisation | A | R | C | I |\n| Forecast demand | A | R | C | I |\n| Recommend investment | R | C | A | C |\n| Review capacity | R | C | A | I |\n\n_R = Responsible, A = Accountable, C = Consulted, I = Informed._\n\n## Roles & Responsibilities\n- **Capacity Analyst** — owns and runs Capacity Management; accountable for its outcomes and reporting.\n- **Analyst / Technician** — performs the day-to-day work and records it in ServiceNow.\n- **Service Delivery Manager** — accountable for performance against the service levels.\n- **Program Manager** — owns the U.S. Department of Commerce relationship and approves investment.\n\n## Inputs & Outputs\n**Inputs:** ticket/telephony/portal utilisation, staffing rosters, demand signals.\n**Outputs:** capacity plan, forecasts, investment recommendations.\n\n## KPIs & Targets\n| KPI | Target |\n|---|---|\n| Capacity-related SLA breaches | 0 per quarter |\n| Forecast accuracy | ± 10% |\n| Peak telephony headroom | ≥ 15% |\n\n## Risks & Controls\n| Risk | Control |\n|---|---|\n| Onboarding spikes overwhelm staffing | Demand forecast tied to HR calendar; flex staffing |\n| Telephony saturation at peak | Headroom target and queue alerts |\n\n## Required Records\nThe capacity plan, the monthly capacity report, and forecast worksheets. Records are retained per the Records Management Procedure (clause 7.5).\n\n## Review\nReviewed at least annually and on significant change. Revision 1.0 — prepared by the Capacity Analyst, approved by the Service Delivery Manager."},"proc_availability":{"title":"Availability Management — Full Pack","clause":"8.7.1","content":"# Availability Management\n_ISO/IEC 20000-1:2018 — Clause 8.7.1 · Meridian Federal Solutions · U.S. Department of Commerce_\n\n## Policy\nIt is Meridian Federal Solutions's policy to ensure services are available when users need them, meeting agreed availability targets. This process operates across ServiceNow supporting approximately 9,200 users at 14 sites (24x7x365), is defined, measured and continually improved, and supports the contractual service levels and ISO/IEC 20000-1 certification.\n\n## Procedure\n1. Define availability requirements and targets from the SLAs.\n2. Design for resilience; identify and remove single points of failure.\n3. Monitor availability continuously with alert thresholds.\n4. Analyse downtime and availability trends.\n5. Drive improvements and test recovery.\n6. Report availability against targets.\n\n## Workflow\nRequirements → resilient design → monitor → analyse downtime → improve & test → report.\n\n## RACI Matrix\n| Activity | Availability Manager | Analyst / Technician | Service Delivery Manager | Program Manager |\n|---|---|---|---|---|\n| Define availability targets | A | C | R | I |\n| Design for resilience | A | R | C | I |\n| Monitor availability | R | R | A | I |\n| Analyse downtime | A | R | C | I |\n| Report availability | R | C | A | I |\n\n_R = Responsible, A = Accountable, C = Consulted, I = Informed._\n\n## Roles & Responsibilities\n- **Availability Manager** — owns and runs Availability Management; accountable for its outcomes and reporting.\n- **Analyst / Technician** — performs the day-to-day work and records it in ServiceNow.\n- **Service Delivery Manager** — accountable for performance against the service levels.\n- **Program Manager** — owns the U.S. Department of Commerce relationship and approves investment.\n\n## Inputs & Outputs\n**Inputs:** availability requirements, monitoring data, incident data.\n**Outputs:** availability reports, improvement actions, risk inputs.\n\n## KPIs & Targets\n| KPI | Target |\n|---|---|\n| Self-service portal availability | ≥ 99.5% |\n| Unplanned downtime | Reducing year on year |\n| Mean time to restore | Within P-level targets |\n\n## Risks & Controls\n| Risk | Control |\n|---|---|\n| Single point of failure | Redundancy in design and periodic review |\n| Undetected degradation | Proactive monitoring and alert thresholds |\n\n## Required Records\nThe availability plan, uptime reports, and downtime analyses. Records are retained per the Records Management Procedure (clause 7.5).\n\n## Review\nReviewed at least annually and on significant change. Revision 1.0 — prepared by the Availability Manager, approved by the Service Delivery Manager."},"proc_continuity":{"title":"Service Continuity Management — Full Pack","clause":"8.7.2","content":"# Service Continuity Management\n_ISO/IEC 20000-1:2018 — Clause 8.7.2 · Meridian Federal Solutions · U.S. Department of Commerce_\n\n## Policy\nIt is Meridian Federal Solutions's policy to ensure services can be recovered and continued after a major disruption within agreed targets. This process operates across ServiceNow supporting approximately 9,200 users at 14 sites (24x7x365), is defined, measured and continually improved, and supports the contractual service levels and ISO/IEC 20000-1 certification.\n\n## Procedure\n1. Assess continuity requirements and risks with the customer.\n2. Agree recovery objectives (RTO and RPO).\n3. Document continuity and recovery plans and run-books.\n4. Provision recovery capability: staffing, alternate access and backups.\n5. Test the plans at least annually and after major change.\n6. Review after each test and update the plans.\n\n## Workflow\nRisk assessment → agree RTO/RPO → document plans → provision recovery → test → review & update.\n\n## RACI Matrix\n| Activity | Continuity Manager | Analyst / Technician | Service Delivery Manager | Program Manager |\n|---|---|---|---|---|\n| Assess continuity risk | A | C | R | I |\n| Agree RTO/RPO with customer | C | I | R | A |\n| Document recovery plans | A | R | C | I |\n| Test the plans | A | R | C | I |\n| Review & update | R | C | A | I |\n\n_R = Responsible, A = Accountable, C = Consulted, I = Informed._\n\n## Roles & Responsibilities\n- **Continuity Manager** — owns and runs Service Continuity Management; accountable for its outcomes and reporting.\n- **Analyst / Technician** — performs the day-to-day work and records it in ServiceNow.\n- **Service Delivery Manager** — accountable for performance against the service levels.\n- **Program Manager** — owns the U.S. Department of Commerce relationship and approves investment.\n\n## Inputs & Outputs\n**Inputs:** risk assessments, RTO/RPO, dependency maps.\n**Outputs:** continuity plans, test results, improvement actions.\n\n## KPIs & Targets\n| KPI | Target |\n|---|---|\n| Continuity test cadence | At least annual |\n| Recovery within RTO in tests | 100% |\n| Plan currency | Reviewed annually |\n\n## Risks & Controls\n| Risk | Control |\n|---|---|\n| Plans untested or outdated | Annual test and post-test review |\n| Dependencies not covered | Dependency mapping via the CMDB |\n\n## Required Records\nContinuity plans, recovery run-books, and continuity test reports. Records are retained per the Records Management Procedure (clause 7.5).\n\n## Review\nReviewed at least annually and on significant change. Revision 1.0 — prepared by the Continuity Manager, approved by the Service Delivery Manager."},"proc_slm":{"title":"Service Level Management — Full Pack","clause":"8.3.3","content":"# Service Level Management\n_ISO/IEC 20000-1:2018 — Clause 8.3.3 · Meridian Federal Solutions · U.S. Department of Commerce_\n\n## Policy\nIt is Meridian Federal Solutions's policy to agree, monitor and report service levels and drive the service to meet them. This process operates across ServiceNow supporting approximately 9,200 users at 14 sites (24x7x365), is defined, measured and continually improved, and supports the contractual service levels and ISO/IEC 20000-1 certification.\n\n## Procedure\n1. Agree SLAs, OLAs and targets with the customer and internal teams.\n2. Instrument dashboards to measure each target.\n3. Monitor performance and manage breaches.\n4. Report to the customer by the 5th business day.\n5. Hold monthly service reviews and record actions.\n6. Review and refresh SLAs periodically.\n\n## Workflow\nAgree SLAs/OLAs → instrument → monitor → report → service review → refresh.\n\n## RACI Matrix\n| Activity | Service Level Manager | Analyst / Technician | Service Delivery Manager | Program Manager |\n|---|---|---|---|---|\n| Agree SLAs & OLAs | C | I | R | A |\n| Measure performance | A | R | C | I |\n| Report to the customer | A | R | C | I |\n| Run the service review | R | C | A | C |\n| Manage breaches & actions | A | R | C | I |\n\n_R = Responsible, A = Accountable, C = Consulted, I = Informed._\n\n## Roles & Responsibilities\n- **Service Level Manager** — owns and runs Service Level Management; accountable for its outcomes and reporting.\n- **Analyst / Technician** — performs the day-to-day work and records it in ServiceNow.\n- **Service Delivery Manager** — accountable for performance against the service levels.\n- **Program Manager** — owns the U.S. Department of Commerce relationship and approves investment.\n\n## Inputs & Outputs\n**Inputs:** SLA definitions, performance data, customer feedback.\n**Outputs:** SLA reports, service-review minutes, improvement actions.\n\n## KPIs & Targets\n| KPI | Target |\n|---|---|\n| SLA targets achieved | ≥ 95% |\n| Report timeliness | By 5th business day |\n| Service reviews held | Monthly |\n\n## Risks & Controls\n| Risk | Control |\n|---|---|\n| Unrealistic or stale SLAs | Periodic SLA review with the customer |\n| Measurement blind spots | Instrumented dashboards with data owners |\n\n## Required Records\nSLA/OLA documents, monthly SLA reports, and service-review minutes. Records are retained per the Records Management Procedure (clause 7.5).\n\n## Review\nReviewed at least annually and on significant change. Revision 1.0 — prepared by the Service Level Manager, approved by the Service Delivery Manager."},"proc_supplier":{"title":"Supplier Management — Full Pack","clause":"8.3.4","content":"# Supplier Management\n_ISO/IEC 20000-1:2018 — Clause 8.3.4 · Meridian Federal Solutions · U.S. Department of Commerce_\n\n## Policy\nIt is Meridian Federal Solutions's policy to manage suppliers and subcontractors so their performance supports the agreed service levels. This process operates across ServiceNow supporting approximately 9,200 users at 14 sites (24x7x365), is defined, measured and continually improved, and supports the contractual service levels and ISO/IEC 20000-1 certification.\n\n## Procedure\n1. Maintain a supplier register with role, contract and criticality.\n2. Define underpinning contracts and OLAs that support the SLAs.\n3. Monitor supplier performance against those agreements.\n4. Hold supplier reviews at the contracted cadence.\n5. Manage issues, disputes and improvement actions.\n6. Manage renewal, exit and continuity for key suppliers.\n\n## Workflow\nRegister suppliers → underpinning contracts → monitor → supplier review → manage issues → renew/exit.\n\n## RACI Matrix\n| Activity | Supplier Manager | Analyst / Technician | Service Delivery Manager | Program Manager |\n|---|---|---|---|---|\n| Maintain the supplier register | A | R | C | I |\n| Define underpinning contracts | A | C | R | C |\n| Monitor performance | A | R | C | I |\n| Hold supplier reviews | R | C | A | C |\n| Manage renewal / exit | R | C | A | C |\n\n_R = Responsible, A = Accountable, C = Consulted, I = Informed._\n\n## Roles & Responsibilities\n- **Supplier Manager** — owns and runs Supplier Management; accountable for its outcomes and reporting.\n- **Analyst / Technician** — performs the day-to-day work and records it in ServiceNow.\n- **Service Delivery Manager** — accountable for performance against the service levels.\n- **Program Manager** — owns the U.S. Department of Commerce relationship and approves investment.\n\n## Inputs & Outputs\n**Inputs:** contracts, supplier performance data, escalations.\n**Outputs:** supplier scorecards, review minutes, improvement actions.\n\n## KPIs & Targets\n| KPI | Target |\n|---|---|\n| Supplier SLA conformance | ≥ 95% |\n| Supplier reviews held | Per contract cadence |\n| Contracts current | 100% within term |\n\n## Risks & Controls\n| Risk | Control |\n|---|---|\n| Supplier underperformance affects SLAs | Underpinning contracts and monitoring |\n| Key-supplier dependency | Continuity and exit planning |\n\n## Required Records\nThe supplier register, underpinning contracts/OLAs, and supplier scorecards. Records are retained per the Records Management Procedure (clause 7.5).\n\n## Review\nReviewed at least annually and on significant change. Revision 1.0 — prepared by the Supplier Manager, approved by the Service Delivery Manager."},"proc_release":{"title":"Release & Deployment Management — Full Pack","clause":"8.5.3","content":"# Release & Deployment Management\n_ISO/IEC 20000-1:2018 — Clause 8.5.3 · Meridian Federal Solutions · U.S. Department of Commerce_\n\n## Policy\nIt is Meridian Federal Solutions's policy to plan, build, test and deploy releases so changes reach production reliably. This process operates across ServiceNow supporting approximately 9,200 users at 14 sites (24x7x365), is defined, measured and continually improved, and supports the contractual service levels and ISO/IEC 20000-1 certification.\n\n## Procedure\n1. Plan releases and define scope and acceptance criteria.\n2. Build and package the release.\n3. Test against acceptance criteria and test gates.\n4. Approve deployment through Change Enablement.\n5. Deploy with back-out readiness and provide early-life support.\n6. Review the release and capture lessons.\n\n## Workflow\nPlan → build & package → test → change approval → deploy (+ early-life support) → review.\n\n## RACI Matrix\n| Activity | Release Manager | Analyst / Technician | Service Delivery Manager | Program Manager |\n|---|---|---|---|---|\n| Plan the release | A | C | R | I |\n| Build & test | A | R | C | I |\n| Approve deployment | C | I | R | A |\n| Deploy & support early life | R | R | A | I |\n| Review the release | A | C | R | I |\n\n_R = Responsible, A = Accountable, C = Consulted, I = Informed._\n\n## Roles & Responsibilities\n- **Release Manager** — owns and runs Release & Deployment Management; accountable for its outcomes and reporting.\n- **Analyst / Technician** — performs the day-to-day work and records it in ServiceNow.\n- **Service Delivery Manager** — accountable for performance against the service levels.\n- **Program Manager** — owns the U.S. Department of Commerce relationship and approves investment.\n\n## Inputs & Outputs\n**Inputs:** approved changes, build artifacts, test results.\n**Outputs:** deployed releases, release notes, PIR results.\n\n## KPIs & Targets\n| KPI | Target |\n|---|---|\n| Release success rate | ≥ 98% |\n| Clean roll-backs of failed deployments | 100% |\n| Emergency releases | ≤ 5% |\n\n## Risks & Controls\n| Risk | Control |\n|---|---|\n| Deployment failure | Tested back-out and early-life support |\n| Scope or quality gaps | Acceptance criteria and test gates |\n\n## Required Records\nRelease plans, test evidence, deployment records, and release notes. Records are retained per the Records Management Procedure (clause 7.5).\n\n## Review\nReviewed at least annually and on significant change. Revision 1.0 — prepared by the Release Manager, approved by the Service Delivery Manager."},"proc_monitoring":{"title":"Monitoring & Reporting — Full Pack","clause":"9.1","content":"# Monitoring & Reporting\n_ISO/IEC 20000-1:2018 — Clause 9.1 · Meridian Federal Solutions · U.S. Department of Commerce_\n\n## Policy\nIt is Meridian Federal Solutions's policy to monitor service performance and report it accurately to the customer and management. This process operates across ServiceNow supporting approximately 9,200 users at 14 sites (24x7x365), is defined, measured and continually improved, and supports the contractual service levels and ISO/IEC 20000-1 certification.\n\n## Procedure\n1. Define what to measure from the SLAs and objectives.\n2. Instrument dashboards in ServiceNow and telephony.\n3. Collect and validate data with named data owners.\n4. Produce the monthly report pack by the 5th business day.\n5. Present at service and management reviews.\n6. Feed findings into Continual Improvement.\n\n## Workflow\nDefine measures → instrument → collect & validate → monthly report → review → improvement.\n\n## RACI Matrix\n| Activity | Reporting Analyst | Analyst / Technician | Service Delivery Manager | Program Manager |\n|---|---|---|---|---|\n| Define measures | A | C | R | I |\n| Build dashboards | A | R | C | I |\n| Validate data | A | R | C | I |\n| Produce the report pack | A | R | C | I |\n| Present at reviews | R | C | A | C |\n\n_R = Responsible, A = Accountable, C = Consulted, I = Informed._\n\n## Roles & Responsibilities\n- **Reporting Analyst** — owns and runs Monitoring & Reporting; accountable for its outcomes and reporting.\n- **Analyst / Technician** — performs the day-to-day work and records it in ServiceNow.\n- **Service Delivery Manager** — accountable for performance against the service levels.\n- **Program Manager** — owns the U.S. Department of Commerce relationship and approves investment.\n\n## Inputs & Outputs\n**Inputs:** SLA data, utilisation, satisfaction, event data.\n**Outputs:** monthly reports, dashboards, trend analysis.\n\n## KPIs & Targets\n| KPI | Target |\n|---|---|\n| Report accuracy | ≥ 99% |\n| Report timeliness | By 5th business day |\n| Dashboard coverage of SLAs | 100% |\n\n## Risks & Controls\n| Risk | Control |\n|---|---|\n| Inaccurate data undermines trust | Validation checks and named data owners |\n| Metrics without action | Reviews drive improvement actions |\n\n## Required Records\nReport definitions, the monthly report pack, and dashboard exports. Records are retained per the Records Management Procedure (clause 7.5).\n\n## Review\nReviewed at least annually and on significant change. Revision 1.0 — prepared by the Reporting Analyst, approved by the Service Delivery Manager."},"proc_improvement":{"title":"Continual Improvement — Full Pack","clause":"10.2","content":"# Continual Improvement\n_ISO/IEC 20000-1:2018 — Clause 10.2 · Meridian Federal Solutions · U.S. Department of Commerce_\n\n## Policy\nIt is Meridian Federal Solutions's policy to provide a repeatable way to identify and deliver improvements to services and the SMS. This process operates across ServiceNow supporting approximately 9,200 users at 14 sites (24x7x365), is defined, measured and continually improved, and supports the contractual service levels and ISO/IEC 20000-1 certification.\n\n## Procedure\n1. Capture improvement opportunities from audits, SLA misses, feedback and reviews.\n2. Log them in the improvement register with owner and expected benefit.\n3. Prioritise by value and effort.\n4. Plan and assign actions with target dates.\n5. Implement and measure the result against a baseline.\n6. Review at management review and close with evidence.\n\n## Workflow\nCapture opportunity → log & prioritise → plan → implement → measure benefit → review & close.\n\n## RACI Matrix\n| Activity | Improvement Lead | Analyst / Technician | Service Delivery Manager | Program Manager |\n|---|---|---|---|---|\n| Capture opportunities | R | R | A | I |\n| Maintain the register | A | R | C | I |\n| Prioritise & plan | A | C | R | C |\n| Implement improvements | R | R | A | I |\n| Measure & review benefit | A | C | R | C |\n\n_R = Responsible, A = Accountable, C = Consulted, I = Informed._\n\n## Roles & Responsibilities\n- **Improvement Lead** — owns and runs Continual Improvement; accountable for its outcomes and reporting.\n- **Analyst / Technician** — performs the day-to-day work and records it in ServiceNow.\n- **Service Delivery Manager** — accountable for performance against the service levels.\n- **Program Manager** — owns the U.S. Department of Commerce relationship and approves investment.\n\n## Inputs & Outputs\n**Inputs:** audit findings, SLA misses, feedback, review outputs.\n**Outputs:** improvement register, delivered improvements, benefit data.\n\n## KPIs & Targets\n| KPI | Target |\n|---|---|\n| Improvements delivered per quarter | ≥ target |\n| Register aging | No item stale > 90 days |\n| Measured benefit | Tracked per item |\n\n## Risks & Controls\n| Risk | Control |\n|---|---|\n| Ideas captured but not delivered | Owned register and review cadence |\n| No measurable benefit | Baseline and post-implementation review |\n\n## Required Records\nThe improvement register, action plans, and benefit measurements. Records are retained per the Records Management Procedure (clause 7.5).\n\n## Review\nReviewed at least annually and on significant change. Revision 1.0 — prepared by the Improvement Lead, approved by the Service Delivery Manager."}},"audit":{"4":{"Audit Checklist":"## Internal Audit Checklist — Clause 4 (Context of the organization)\nMeridian Federal Solutions · Enterprise IT Service Desk (EITSD) contract · U.S. Department of Commerce\n\n| # | Requirement | Audit question | Evidence to sample | Conforms? |\n|---|---|---|---|---|\n| 1 | 4.1 | Is the requirement defined and documented? | Controlling policy/procedure | ( ) |\n| 2 | 4.2 | Is it implemented in day-to-day operation? | Records, tickets, minutes | ( ) |\n| 3 | 4.3 | Is it monitored and reviewed? | Reports, review minutes | ( ) |\n| 4 | 4.x | Are improvements tracked to closure? | Improvement register | ( ) |\n\n**Sampling:** at least 5 records across the last 3 months per requirement.","Interview Questions":"## Auditor Interview Questions — Clause 4 (Context of the organization)\n\n- Who owns this part of the SMS, and how is it kept current?\n- Walk me through how you meet clause 4 day to day.\n- What records prove it is working, and where are they kept?\n- How do you know it is effective, and what changed after the last review?","Objective Evidence Requirements":"## Objective Evidence — Clause 4 (Context of the organization)\n\nExpect to see: the controlling document(s) for clause 4; dated records showing the process operating (tickets, minutes, reports); monitoring/measurement output; and evidence that issues were actioned and closed. Evidence must be current, attributable and retained per the Records Management Procedure."},"5":{"Audit Checklist":"## Internal Audit Checklist — Clause 5 (Leadership)\nMeridian Federal Solutions · Enterprise IT Service Desk (EITSD) contract · U.S. Department of Commerce\n\n| # | Requirement | Audit question | Evidence to sample | Conforms? |\n|---|---|---|---|---|\n| 1 | 5.1 | Is the requirement defined and documented? | Controlling policy/procedure | ( ) |\n| 2 | 5.2 | Is it implemented in day-to-day operation? | Records, tickets, minutes | ( ) |\n| 3 | 5.3 | Is it monitored and reviewed? | Reports, review minutes | ( ) |\n| 4 | 5.x | Are improvements tracked to closure? | Improvement register | ( ) |\n\n**Sampling:** at least 5 records across the last 3 months per requirement.","Interview Questions":"## Auditor Interview Questions — Clause 5 (Leadership)\n\n- Who owns this part of the SMS, and how is it kept current?\n- Walk me through how you meet clause 5 day to day.\n- What records prove it is working, and where are they kept?\n- How do you know it is effective, and what changed after the last review?","Objective Evidence Requirements":"## Objective Evidence — Clause 5 (Leadership)\n\nExpect to see: the controlling document(s) for clause 5; dated records showing the process operating (tickets, minutes, reports); monitoring/measurement output; and evidence that issues were actioned and closed. Evidence must be current, attributable and retained per the Records Management Procedure."},"6":{"Audit Checklist":"## Internal Audit Checklist — Clause 6 (Planning)\nMeridian Federal Solutions · Enterprise IT Service Desk (EITSD) contract · U.S. Department of Commerce\n\n| # | Requirement | Audit question | Evidence to sample | Conforms? |\n|---|---|---|---|---|\n| 1 | 6.1 | Is the requirement defined and documented? | Controlling policy/procedure | ( ) |\n| 2 | 6.2 | Is it implemented in day-to-day operation? | Records, tickets, minutes | ( ) |\n| 3 | 6.3 | Is it monitored and reviewed? | Reports, review minutes | ( ) |\n| 4 | 6.x | Are improvements tracked to closure? | Improvement register | ( ) |\n\n**Sampling:** at least 5 records across the last 3 months per requirement.","Interview Questions":"## Auditor Interview Questions — Clause 6 (Planning)\n\n- Who owns this part of the SMS, and how is it kept current?\n- Walk me through how you meet clause 6 day to day.\n- What records prove it is working, and where are they kept?\n- How do you know it is effective, and what changed after the last review?","Objective Evidence Requirements":"## Objective Evidence — Clause 6 (Planning)\n\nExpect to see: the controlling document(s) for clause 6; dated records showing the process operating (tickets, minutes, reports); monitoring/measurement output; and evidence that issues were actioned and closed. Evidence must be current, attributable and retained per the Records Management Procedure."},"7":{"Audit Checklist":"## Internal Audit Checklist — Clause 7 (Support)\nMeridian Federal Solutions · Enterprise IT Service Desk (EITSD) contract · U.S. Department of Commerce\n\n| # | Requirement | Audit question | Evidence to sample | Conforms? |\n|---|---|---|---|---|\n| 1 | 7.1 | Is the requirement defined and documented? | Controlling policy/procedure | ( ) |\n| 2 | 7.2 | Is it implemented in day-to-day operation? | Records, tickets, minutes | ( ) |\n| 3 | 7.3 | Is it monitored and reviewed? | Reports, review minutes | ( ) |\n| 4 | 7.x | Are improvements tracked to closure? | Improvement register | ( ) |\n\n**Sampling:** at least 5 records across the last 3 months per requirement.","Interview Questions":"## Auditor Interview Questions — Clause 7 (Support)\n\n- Who owns this part of the SMS, and how is it kept current?\n- Walk me through how you meet clause 7 day to day.\n- What records prove it is working, and where are they kept?\n- How do you know it is effective, and what changed after the last review?","Objective Evidence Requirements":"## Objective Evidence — Clause 7 (Support)\n\nExpect to see: the controlling document(s) for clause 7; dated records showing the process operating (tickets, minutes, reports); monitoring/measurement output; and evidence that issues were actioned and closed. Evidence must be current, attributable and retained per the Records Management Procedure."},"8":{"Audit Checklist":"## Internal Audit Checklist — Clause 8 (Operation)\nMeridian Federal Solutions · Enterprise IT Service Desk (EITSD) contract · U.S. Department of Commerce\n\n| # | Requirement | Audit question | Evidence to sample | Conforms? |\n|---|---|---|---|---|\n| 1 | 8.1 | Is the requirement defined and documented? | Controlling policy/procedure | ( ) |\n| 2 | 8.2 | Is it implemented in day-to-day operation? | Records, tickets, minutes | ( ) |\n| 3 | 8.3 | Is it monitored and reviewed? | Reports, review minutes | ( ) |\n| 4 | 8.x | Are improvements tracked to closure? | Improvement register | ( ) |\n\n**Sampling:** at least 5 records across the last 3 months per requirement.","Interview Questions":"## Auditor Interview Questions — Clause 8 (Operation)\n\n- Who owns this part of the SMS, and how is it kept current?\n- Walk me through how you meet clause 8 day to day.\n- What records prove it is working, and where are they kept?\n- How do you know it is effective, and what changed after the last review?","Objective Evidence Requirements":"## Objective Evidence — Clause 8 (Operation)\n\nExpect to see: the controlling document(s) for clause 8; dated records showing the process operating (tickets, minutes, reports); monitoring/measurement output; and evidence that issues were actioned and closed. Evidence must be current, attributable and retained per the Records Management Procedure."},"9":{"Audit Checklist":"## Internal Audit Checklist — Clause 9 (Performance evaluation)\nMeridian Federal Solutions · Enterprise IT Service Desk (EITSD) contract · U.S. Department of Commerce\n\n| # | Requirement | Audit question | Evidence to sample | Conforms? |\n|---|---|---|---|---|\n| 1 | 9.1 | Is the requirement defined and documented? | Controlling policy/procedure | ( ) |\n| 2 | 9.2 | Is it implemented in day-to-day operation? | Records, tickets, minutes | ( ) |\n| 3 | 9.3 | Is it monitored and reviewed? | Reports, review minutes | ( ) |\n| 4 | 9.x | Are improvements tracked to closure? | Improvement register | ( ) |\n\n**Sampling:** at least 5 records across the last 3 months per requirement.","Interview Questions":"## Auditor Interview Questions — Clause 9 (Performance evaluation)\n\n- Who owns this part of the SMS, and how is it kept current?\n- Walk me through how you meet clause 9 day to day.\n- What records prove it is working, and where are they kept?\n- How do you know it is effective, and what changed after the last review?","Objective Evidence Requirements":"## Objective Evidence — Clause 9 (Performance evaluation)\n\nExpect to see: the controlling document(s) for clause 9; dated records showing the process operating (tickets, minutes, reports); monitoring/measurement output; and evidence that issues were actioned and closed. Evidence must be current, attributable and retained per the Records Management Procedure."},"10":{"Audit Checklist":"## Internal Audit Checklist — Clause 10 (Improvement)\nMeridian Federal Solutions · Enterprise IT Service Desk (EITSD) contract · U.S. Department of Commerce\n\n| # | Requirement | Audit question | Evidence to sample | Conforms? |\n|---|---|---|---|---|\n| 1 | 10.1 | Is the requirement defined and documented? | Controlling policy/procedure | ( ) |\n| 2 | 10.2 | Is it implemented in day-to-day operation? | Records, tickets, minutes | ( ) |\n| 3 | 10.3 | Is it monitored and reviewed? | Reports, review minutes | ( ) |\n| 4 | 10.x | Are improvements tracked to closure? | Improvement register | ( ) |\n\n**Sampling:** at least 5 records across the last 3 months per requirement.","Interview Questions":"## Auditor Interview Questions — Clause 10 (Improvement)\n\n- Who owns this part of the SMS, and how is it kept current?\n- Walk me through how you meet clause 10 day to day.\n- What records prove it is working, and where are they kept?\n- How do you know it is effective, and what changed after the last review?","Objective Evidence Requirements":"## Objective Evidence — Clause 10 (Improvement)\n\nExpect to see: the controlling document(s) for clause 10; dated records showing the process operating (tickets, minutes, reports); monitoring/measurement output; and evidence that issues were actioned and closed. Evidence must be current, attributable and retained per the Records Management Procedure."}}};

const DEMO_27K = {"generated":{"ismspolicy":{"title":"Information Security Policy","clause":"5.2","content":"# Information Security Policy\n_ISO/IEC 27001:2022 — Clause 5.2 · Meridian Federal Solutions_\n\n## 1. Purpose\nThis policy states Meridian Federal Solutions, LLC's commitment to protecting the confidentiality, integrity and availability of information involved in delivering the Enterprise IT Service Desk (EITSD) contract to U.S. Department of Commerce, under an ISMS conforming to ISO/IEC 27001:2022.\n\n## 2. Scope\nApplies to all information, systems (ServiceNow), personnel and sites (14) within the ISMS scope supporting approximately 9,200 users.\n\n## 3. Policy Statements\n- We protect information based on assessed risk and classification.\n- We grant access on least-privilege and need-to-know principles.\n- We meet legal, regulatory and contractual security obligations.\n- We detect, respond to and learn from security incidents.\n- We continually improve the ISMS and maintain ISO/IEC 27001 certification.\n\n## 4. Authority & Approval\nIssued by top management; communicated to all personnel; reviewed at least annually.\n\n| Version | Date | Author | Approved by |\n|---|---|---|---|\n| 1.0 | (current) | ISMS / Security Manager | Program Manager |"},"ismsscope":{"title":"ISMS Scope","clause":"4.3","content":"# Scope of the ISMS\n_ISO/IEC 27001:2022 — Clause 4.3 · Meridian Federal Solutions_\n\n**Organization:** Meridian Federal Solutions, LLC\n**Customer / driver:** U.S. Department of Commerce — Enterprise IT Service Desk (EITSD) contract\n**Systems:** ServiceNow and supporting infrastructure\n\n## In scope\nInformation, systems, people and processes used to deliver the Enterprise IT Service Desk (EITSD) contract, supporting ~9,200 users across 14 sites.\n\n## Interfaces & dependencies\nCustomer-provided network and hosting are dependencies at the boundary; cloud services are governed through Supplier & Cloud Security.\n\n## Exclusions\nExclusions (if any) are justified in the Statement of Applicability by the risk assessment.\n\n## Governing standard\nISO/IEC 27001:2022, clauses 4–10 and Annex A."},"context":{"title":"Context of the Organization","clause":"4.1","content":"# Context of the Organization\n_ISO/IEC 27001:2022 — Clause 4.1 · Meridian Federal Solutions_\n\nInternal and external issues relevant to the ISMS for the Enterprise IT Service Desk (EITSD) contract, reviewed at management review.\n\n## External issues\n| Issue | Relevance to the ISMS |\n|---|---|\n| Regulatory & contractual security obligations | Set mandatory controls and reporting |\n| Threat landscape (phishing, ransomware, insider) | Drives control selection and monitoring |\n| Customer security expectations | Set assurance and reporting requirements |\n| Cloud & supplier ecosystem | Introduces third-party risk |\n\n## Internal issues\n| Issue | Relevance to the ISMS |\n|---|---|\n| Security maturity and tooling | Affects control effectiveness |\n| Staffing and security skills | Affects operation of controls |\n| Culture and awareness | Affects human-factor risk |\n\n## Review\nReviewed at least annually and on significant change."},"parties":{"title":"Interested Parties & Requirements","clause":"4.2","content":"# Interested Parties & Requirements\n_ISO/IEC 27001:2022 — Clause 4.2 · Meridian Federal Solutions_\n\n| Interested party | Security needs & expectations | How the ISMS meets them |\n|---|---|---|\n| U.S. Department of Commerce | Protection of its data; breach notification; assurance | Controls, incident process, reporting, certification |\n| End users (~9,200) | Secure, available services | Access control, availability, awareness |\n| Regulators | Compliance with applicable law | Obligations register; controls; records |\n| Meridian Federal Solutions management | Low-risk, compliant delivery | Governance, risk management, audits |\n| Employees | Clear responsibilities; training | Roles, awareness programme |\n| Suppliers / cloud providers | Clear security requirements | Supplier & Cloud Security process |\n\n## Review\nReviewed at least annually and when requirements change."},"leadership":{"title":"Leadership & Roles","clause":"5.1 / 5.3","content":"# Leadership & Roles\n_ISO/IEC 27001:2022 — Clauses 5.1 & 5.3 · Meridian Federal Solutions_\n\n## Management commitment\nTop management is accountable for the ISMS: it sets policy and objectives, ensures resources, and reviews performance.\n\n| Role | Responsibility | Authority |\n|---|---|---|\n| Program Manager | Accountable for the ISMS and the U.S. Department of Commerce relationship | Approves policy, budget, risk acceptance |\n| ISMS / Security Manager | Runs the ISMS; risk, controls, audits | Directs security operations |\n| Information Security Officer | Owns technical security controls | Approves controls and exceptions |\n| Asset / System Owners | Implement controls for their systems | Manage their assets |\n| All personnel | Comply and report events | — |\n\n## Review\nReviewed at least annually and on organizational change."},"riskmethod":{"title":"Risk Assessment & Treatment Methodology","clause":"6.1.2","content":"# Risk Assessment & Treatment Methodology\n_ISO/IEC 27001:2022 — Clause 6.1.2 · Meridian Federal Solutions_\n\n## Method\n1. Identify information assets and their owners.\n2. Identify threats and vulnerabilities for each asset.\n3. Assess likelihood and impact on a defined scale (1–5).\n4. Calculate risk = likelihood × impact; compare to the risk acceptance criteria.\n5. Select treatment: mitigate (apply Annex A controls), transfer, avoid, or accept.\n6. Record residual risk and obtain risk owner acceptance.\n\n## Risk acceptance criteria\nRisks scoring above the agreed threshold require treatment; residual risks are accepted by the risk owner and recorded.\n\n## Review\nThe assessment is reviewed at least annually and on significant change."},"riskreport":{"title":"Risk Assessment Report","clause":"6.1.2","content":"# Risk Assessment Report\n_ISO/IEC 27001:2022 — Clause 6.1.2 · Meridian Federal Solutions_\n\n| ID | Asset | Threat | L | I | Risk | Treatment (Annex A) | Owner |\n|---|---|---|---|---|---|---|---|\n| IR1 | U.S. Department of Commerce data in ServiceNow | Unauthorised access | 3 | 5 | High | A.5.15, A.8.2, A.8.5 access control + MFA | Security Manager |\n| IR2 | Credentials | Phishing | 4 | 4 | High | A.6.3 awareness; A.8.5 MFA | Security Manager |\n| IR3 | Endpoints | Malware / ransomware | 3 | 4 | High | A.8.7 anti-malware; A.8.13 backup | Security Officer |\n| IR4 | Data in transit | Interception | 2 | 4 | Medium | A.8.24 encryption (TLS) | Security Officer |\n| IR5 | Cloud service | Provider weakness | 2 | 4 | Medium | A.5.23 cloud security; assurance review | Security Manager |\n| IR6 | Systems | Unpatched vulnerability | 3 | 4 | High | A.8.8 vulnerability & patch mgmt | Security Officer |\n\nRisks are reviewed at least annually and at management review."},"rtp":{"title":"Risk Treatment Plan","clause":"6.1.3","content":"# Risk Treatment Plan\n_ISO/IEC 27001:2022 — Clause 6.1.3 · Meridian Federal Solutions_\n\n| Risk | Treatment | Controls | Owner | Target | Status |\n|---|---|---|---|---|---|\n| IR1 Unauthorised access | Mitigate | RBAC, least privilege, MFA, access reviews | Security Manager | Q1 | In progress |\n| IR2 Phishing | Mitigate | Awareness training, MFA, email filtering | Security Manager | Q1 | In progress |\n| IR3 Malware/ransomware | Mitigate | Endpoint protection, backup, restore tests | Security Officer | Q2 | Planned |\n| IR4 Interception | Mitigate | TLS 1.2+, encryption at rest | Security Officer | Q1 | Done |\n| IR5 Cloud provider | Mitigate/transfer | Assurance review, contract clauses | Security Manager | Q2 | Planned |\n| IR6 Vulnerabilities | Mitigate | Scanning, patch SLAs | Security Officer | Ongoing | In progress |\n\nProgress is tracked to closure and reported at management review."},"objectives":{"title":"Information Security Objectives","clause":"6.2","content":"# Information Security Objectives\n_ISO/IEC 27001:2022 — Clause 6.2 · Meridian Federal Solutions_\n\n| Objective | Measure | Target | Owner |\n|---|---|---|---|\n| Reduce access risk | Access reviews completed | 100% quarterly | Security Manager |\n| Raise awareness | Staff completing training | ≥ 95% | Security Manager |\n| Patch quickly | Critical patches within SLA | ≥ 95% | Security Officer |\n| Respond to incidents | Major incidents reviewed | 100% | Security Manager |\n| Maintain certification | ISO/IEC 27001 certified | Within 12 months | Program Manager |\n\nObjectives are monitored and reviewed at management review (clause 9.3)."},"competency":{"title":"Competence & Awareness","clause":"7.2 / 7.3","content":"# Competence & Awareness\n_ISO/IEC 27001:2022 — Clauses 7.2 & 7.3 · Meridian Federal Solutions_\n\n| Role | Required competence | Evidence |\n|---|---|---|\n| ISMS / Security Manager | ISMS operation; risk management | ISO 27001 training / certification |\n| Security Officer | Technical security controls | Security certifications (e.g. Security+) |\n| Asset / System Owners | Controls for their systems | Role training records |\n| All personnel | Security awareness | Onboarding + annual training |\n\n## Awareness programme\nSecurity awareness at onboarding and at least annually, plus targeted phishing simulations. Records are retained."},"commplan":{"title":"Communication Plan","clause":"7.4","content":"# Communication Plan\n_ISO/IEC 27001:2022 — Clause 7.4 · Meridian Federal Solutions_\n\n| Communication | Audience | Frequency | Channel | Owner |\n|---|---|---|---|---|\n| Security posture report | U.S. Department of Commerce | Per contract | Report | Security Manager |\n| Management review | Top management | Quarterly | Meeting + minutes | Program Manager |\n| Security incident notification | Customer/regulator | On occurrence | Per plan | Security Manager |\n| Awareness communications | All staff | Ongoing | Email/portal | Security Manager |\n| Policy updates | All staff | On change | Portal | ISMS Manager |"},"doccontrol":{"title":"Documented Information Control","clause":"7.5","content":"# Documented Information Control\n_ISO/IEC 27001:2022 — Clause 7.5 · Meridian Federal Solutions_\n\n## Procedure\n1. Create using approved templates.\n2. Review and approve before publication.\n3. Version as Major.Minor; record version, date and approver.\n4. Publish to the controlled repository with access control.\n5. Review at least annually and on significant change.\n6. Retire and archive superseded versions.\n\n| Control | Rule |\n|---|---|\n| Classification | Documents classified and access-controlled |\n| Versioning | Major.Minor with change record |\n| Retention | Per Records procedure |"},"records":{"title":"Records & Retention","clause":"7.5","content":"# Records & Retention\n_ISO/IEC 27001:2022 — Clause 7.5 · Meridian Federal Solutions_\n\n| Record | Owner | Storage | Retention |\n|---|---|---|---|\n| Risk assessments & treatment plans | Security Manager | Repository | ISMS term + 1 year |\n| Access reviews | Security Manager | Repository | ISMS term + 1 year |\n| Security incident records | Security Manager | ServiceNow/repository | ISMS term + 1 year |\n| Training & awareness records | HR | HR system | Employment + per policy |\n| Internal audit reports | ISMS Manager | Repository | ISMS term + 1 year |\n| Management review minutes | Program Manager | Repository | ISMS term + 1 year |\n\nRecords are protected and disposed of securely at end of retention."},"soa":{"title":"Statement of Applicability (SoA)","clause":"6.1.3 d)","content":"# Statement of Applicability\n_ISO/IEC 27001:2022 — Clause 6.1.3 d) · Meridian Federal Solutions_\n\nThe Statement of Applicability lists the Annex A controls, whether each is applicable to the ISMS for the Enterprise IT Service Desk (EITSD) contract, and how it is implemented. Exclusions are justified by the risk assessment.\n\n### Theme 5 Organizational\n\n| Control | Title | Applicability | Implementation |\n|---|---|---|---|\n| A.5.1 | Policies for information security | Applicable | Information Security Policy approved and communicated |\n| A.5.2 | Information security roles and responsibilities | Applicable | Roles defined in the Leadership & Roles document |\n| A.5.7 | Threat intelligence | Applicable | Threat feeds reviewed; findings drive risk updates |\n| A.5.9 | Inventory of information and other associated assets | Applicable | Asset & classification register maintained |\n| A.5.12 | Classification of information | Applicable | Classification scheme (Public/Internal/Confidential/CUI) |\n| A.5.15 | Access control | Applicable | Access Control Policy; least-privilege; RBAC |\n| A.5.19 | Information security in supplier relationships | Applicable | Supplier Security process; security clauses in contracts |\n| A.5.23 | Information security for use of cloud services | Applicable | Cloud security requirements; provider assurance reviewed |\n| A.5.24 | Information security incident management planning | Applicable | Security Incident Management procedure |\n| A.5.29 | Information security during disruption | Applicable | Business Continuity & recovery plans |\n| A.5.31 | Legal, statutory, regulatory and contractual requirements | Applicable | Obligations register; contract security terms |\n\n### Theme 6 People\n\n| Control | Title | Applicability | Implementation |\n|---|---|---|---|\n| A.6.1 | Screening | Applicable | Background screening prior to access, per contract |\n| A.6.2 | Terms and conditions of employment | Applicable | Security responsibilities in employment terms |\n| A.6.3 | Information security awareness, education and training | Applicable | Security awareness programme; annual refresh |\n| A.6.4 | Disciplinary process | Applicable | Documented disciplinary process for violations |\n| A.6.7 | Remote working | Applicable | Remote-work security controls and VPN |\n| A.6.8 | Information security event reporting | Applicable | Reporting channel for security events |\n\n### Theme 7 Physical\n\n| Control | Title | Applicability | Implementation |\n|---|---|---|---|\n| A.7.1 | Physical security perimeters | Applicable | Secure areas defined for on-site work |\n| A.7.2 | Physical entry | Applicable | Badge access and visitor control |\n| A.7.4 | Physical security monitoring | Applicable | Monitoring of secure areas |\n| A.7.7 | Clear desk and clear screen | Applicable | Clear-desk/clear-screen policy enforced |\n| A.7.10 | Storage media | Applicable | Media handling and secure disposal |\n| A.7.14 | Secure disposal or re-use of equipment | Applicable | Sanitisation before disposal or re-use |\n\n### Theme 8 Technological\n\n| Control | Title | Applicability | Implementation |\n|---|---|---|---|\n| A.8.1 | User endpoint devices | Applicable | Endpoint hardening and MDM |\n| A.8.2 | Privileged access rights | Applicable | Privileged access managed and reviewed |\n| A.8.5 | Secure authentication | Applicable | MFA for remote and privileged access |\n| A.8.7 | Protection against malware | Applicable | Endpoint protection; updates monitored |\n| A.8.8 | Management of technical vulnerabilities | Applicable | Vulnerability & Patch Management process |\n| A.8.12 | Data leakage prevention | Applicable | DLP controls on egress paths |\n| A.8.13 | Information backup | Applicable | Backup schedule and restore testing |\n| A.8.15 | Logging | Applicable | Centralised logging of security events |\n| A.8.16 | Monitoring activities | Applicable | Monitoring and alerting on anomalies |\n| A.8.24 | Use of cryptography | Applicable | Cryptography & Key Management policy |\n| A.8.25 | Secure development life cycle | Conditional | Applies where the team develops software |\n| A.8.28 | Secure coding | Conditional | Applies where the team develops software |\n\n_This is a representative control set; the full SoA covers all Annex A:2022 controls. Applicability is confirmed by the risk assessment and treatment plan._"},"sec_access":{"title":"Access Control — Control Pack","clause":"A.5.15–5.18, A.8.2–8.5","content":"# Access Control\n_ISO/IEC 27001:2022 — A.5.15–5.18, A.8.2–8.5 · Meridian Federal Solutions · U.S. Department of Commerce_\n\n## Policy\nIt is Meridian Federal Solutions's policy to grant, review and revoke access on least-privilege and need-to-know principles, in support of securely delivering the Enterprise IT Service Desk (EITSD) contract and maintaining ISO/IEC 27001 certification.\n\n## Procedure\n1. Provision access via role-based access control (RBAC) on joiner.\n2. Require MFA for remote and privileged access.\n3. Enforce least privilege; separate duties for sensitive functions.\n4. Review access rights at least quarterly and on role change.\n5. Revoke access immediately on leaver or role removal.\n6. Log and monitor privileged access.\n\n## Key Controls\n| Control | Standard |\n|---|---|\n| Least privilege / RBAC | Roles mapped to job function |\n| MFA | Remote + privileged access |\n| Access review | Quarterly + on change |\n| Joiner/mover/leaver | Tied to HR process |\n\n## Roles & Responsibilities\n- **Security Lead** — owns this control area and its effectiveness.\n- **Asset/System Owners** — implement controls for their systems.\n- **All personnel** — comply and report security events.\n\n## Required Records\nAccess requests, quarterly access reviews, and privileged-access logs. Records are retained per the Documented Information Control procedure.\n\n## Review\nReviewed at least annually and on significant change. Revision 1.0."},"sec_crypto":{"title":"Cryptography & Key Management — Control Pack","clause":"A.8.24","content":"# Cryptography & Key Management\n_ISO/IEC 27001:2022 — A.8.24 · Meridian Federal Solutions · U.S. Department of Commerce_\n\n## Policy\nIt is Meridian Federal Solutions's policy to protect information in transit and at rest with appropriate cryptography and managed keys, in support of securely delivering the Enterprise IT Service Desk (EITSD) contract and maintaining ISO/IEC 27001 certification.\n\n## Procedure\n1. Encrypt data in transit (TLS 1.2+) and at rest (AES-256).\n2. Define approved algorithms and key lengths.\n3. Manage keys through their lifecycle: generate, store, rotate, revoke.\n4. Protect keys with access control and, where required, an HSM/KMS.\n5. Rotate keys on schedule and on compromise.\n6. Record cryptographic controls in the asset register.\n\n## Key Controls\n| Control | Standard |\n|---|---|\n| In transit | TLS 1.2+ |\n| At rest | AES-256 |\n| Key storage | KMS/HSM, access-controlled |\n| Rotation | Scheduled + on compromise |\n\n## Roles & Responsibilities\n- **Security Lead** — owns this control area and its effectiveness.\n- **Asset/System Owners** — implement controls for their systems.\n- **All personnel** — comply and report security events.\n\n## Required Records\nThe cryptographic controls register and key-rotation logs. Records are retained per the Documented Information Control procedure.\n\n## Review\nReviewed at least annually and on significant change. Revision 1.0."},"sec_incident":{"title":"Information Security Incident Management — Control Pack","clause":"A.5.24–5.28","content":"# Information Security Incident Management\n_ISO/IEC 27001:2022 — A.5.24–5.28 · Meridian Federal Solutions · U.S. Department of Commerce_\n\n## Policy\nIt is Meridian Federal Solutions's policy to detect, respond to, and learn from information security incidents and breaches, in support of securely delivering the Enterprise IT Service Desk (EITSD) contract and maintaining ISO/IEC 27001 certification.\n\n## Procedure\n1. Provide a channel to report security events.\n2. Triage and classify events; declare incidents by severity.\n3. Contain, eradicate and recover per the response plan.\n4. Notify the customer and regulators within contractual/legal timeframes.\n5. Preserve evidence and conduct post-incident review.\n6. Feed lessons into risk and control improvements.\n\n## Key Controls\n| Control | Standard |\n|---|---|\n| Reporting channel | Available to all staff |\n| Severity classification | Defined matrix |\n| Breach notification | Per contract/law timeframes |\n| Post-incident review | For all major incidents |\n\n## Roles & Responsibilities\n- **Security Lead** — owns this control area and its effectiveness.\n- **Asset/System Owners** — implement controls for their systems.\n- **All personnel** — comply and report security events.\n\n## Required Records\nSecurity incident records, breach notifications, and post-incident reviews. Records are retained per the Documented Information Control procedure.\n\n## Review\nReviewed at least annually and on significant change. Revision 1.0."},"sec_supplier":{"title":"Supplier & Cloud Security — Control Pack","clause":"A.5.19–5.23","content":"# Supplier & Cloud Security\n_ISO/IEC 27001:2022 — A.5.19–5.23 · Meridian Federal Solutions · U.S. Department of Commerce_\n\n## Policy\nIt is Meridian Federal Solutions's policy to ensure suppliers and cloud services meet the organization's security requirements, in support of securely delivering the Enterprise IT Service Desk (EITSD) contract and maintaining ISO/IEC 27001 certification.\n\n## Procedure\n1. Assess supplier/cloud security before engagement.\n2. Include security requirements and right-to-audit in contracts.\n3. Review provider assurance (e.g. SOC 2, ISO 27001, FedRAMP).\n4. Monitor supplier security performance.\n5. Manage changes and offboarding securely.\n6. Maintain a register of suppliers and their assurance status.\n\n## Key Controls\n| Control | Standard |\n|---|---|\n| Pre-engagement assessment | Required |\n| Contract security clauses | Standard |\n| Provider assurance | Reviewed periodically |\n| Offboarding | Access and data removal |\n\n## Roles & Responsibilities\n- **Security Lead** — owns this control area and its effectiveness.\n- **Asset/System Owners** — implement controls for their systems.\n- **All personnel** — comply and report security events.\n\n## Required Records\nThe supplier security register and assurance reviews. Records are retained per the Documented Information Control procedure.\n\n## Review\nReviewed at least annually and on significant change. Revision 1.0."},"sec_logging":{"title":"Logging & Monitoring — Control Pack","clause":"A.8.15–8.16","content":"# Logging & Monitoring\n_ISO/IEC 27001:2022 — A.8.15–8.16 · Meridian Federal Solutions · U.S. Department of Commerce_\n\n## Policy\nIt is Meridian Federal Solutions's policy to record security-relevant events and detect anomalies in a timely way, in support of securely delivering the Enterprise IT Service Desk (EITSD) contract and maintaining ISO/IEC 27001 certification.\n\n## Procedure\n1. Log authentication, access, and administrative events centrally.\n2. Protect logs from tampering; retain per policy.\n3. Define alerting rules for anomalies and threats.\n4. Review alerts and investigate as needed.\n5. Correlate events for detection (SIEM where available).\n6. Report monitoring outcomes to management.\n\n## Key Controls\n| Control | Standard |\n|---|---|\n| Central logging | Security-relevant events |\n| Log protection | Tamper-resistant, retained |\n| Alerting | Anomaly + threat rules |\n| Review | Defined cadence |\n\n## Roles & Responsibilities\n- **Security Lead** — owns this control area and its effectiveness.\n- **Asset/System Owners** — implement controls for their systems.\n- **All personnel** — comply and report security events.\n\n## Required Records\nLog configuration, alert definitions, and monitoring reports. Records are retained per the Documented Information Control procedure.\n\n## Review\nReviewed at least annually and on significant change. Revision 1.0."},"sec_vuln":{"title":"Vulnerability & Patch Management — Control Pack","clause":"A.8.8","content":"# Vulnerability & Patch Management\n_ISO/IEC 27001:2022 — A.8.8 · Meridian Federal Solutions · U.S. Department of Commerce_\n\n## Policy\nIt is Meridian Federal Solutions's policy to identify and remediate technical vulnerabilities before they can be exploited, in support of securely delivering the Enterprise IT Service Desk (EITSD) contract and maintaining ISO/IEC 27001 certification.\n\n## Procedure\n1. Scan systems for vulnerabilities on a schedule.\n2. Rate findings by severity (e.g. CVSS).\n3. Remediate within severity-based SLAs.\n4. Patch systems on a defined cadence and for emergencies.\n5. Verify remediation and track exceptions.\n6. Report vulnerability posture to management.\n\n## Key Controls\n| Control | Standard |\n|---|---|\n| Scanning | Scheduled |\n| Severity SLAs | Critical fastest |\n| Patch cadence | Routine + emergency |\n| Exceptions | Tracked with risk acceptance |\n\n## Roles & Responsibilities\n- **Security Lead** — owns this control area and its effectiveness.\n- **Asset/System Owners** — implement controls for their systems.\n- **All personnel** — comply and report security events.\n\n## Required Records\nScan results, remediation tracking, and patch records. Records are retained per the Documented Information Control procedure.\n\n## Review\nReviewed at least annually and on significant change. Revision 1.0."},"sec_continuity":{"title":"Business Continuity & Backup — Control Pack","clause":"A.5.29–5.30, A.8.13–8.14","content":"# Business Continuity & Backup\n_ISO/IEC 27001:2022 — A.5.29–5.30, A.8.13–8.14 · Meridian Federal Solutions · U.S. Department of Commerce_\n\n## Policy\nIt is Meridian Federal Solutions's policy to maintain and recover information security during and after disruption, in support of securely delivering the Enterprise IT Service Desk (EITSD) contract and maintaining ISO/IEC 27001 certification.\n\n## Procedure\n1. Identify critical services and set RTO/RPO.\n2. Back up data on schedule and protect backups.\n3. Document continuity and recovery plans.\n4. Test recovery from backup at least annually.\n5. Include security requirements in continuity plans.\n6. Review and update after tests and major change.\n\n## Key Controls\n| Control | Standard |\n|---|---|\n| Backup schedule | Defined; protected copies |\n| Restore testing | At least annual |\n| RTO/RPO | Agreed with customer |\n| Plan review | Post-test + on change |\n\n## Roles & Responsibilities\n- **Continuity Manager** — owns this control area and its effectiveness.\n- **Asset/System Owners** — implement controls for their systems.\n- **All personnel** — comply and report security events.\n\n## Required Records\nBackup logs, restore-test results, and continuity plans. Records are retained per the Documented Information Control procedure.\n\n## Review\nReviewed at least annually and on significant change. Revision 1.0."},"sec_hr":{"title":"Human Resource Security — Control Pack","clause":"A.6.1–6.8","content":"# Human Resource Security\n_ISO/IEC 27001:2022 — A.6.1–6.8 · Meridian Federal Solutions · U.S. Department of Commerce_\n\n## Policy\nIt is Meridian Federal Solutions's policy to ensure personnel are suitable for, aware of, and accountable to their security responsibilities, in support of securely delivering the Enterprise IT Service Desk (EITSD) contract and maintaining ISO/IEC 27001 certification.\n\n## Procedure\n1. Screen personnel before granting access, per contract.\n2. State security responsibilities in employment terms.\n3. Deliver security awareness training at onboarding and annually.\n4. Apply the disciplinary process for violations.\n5. Manage secure remote working.\n6. Remove access and return assets on exit.\n\n## Key Controls\n| Control | Standard |\n|---|---|\n| Screening | Pre-access |\n| Awareness | Onboarding + annual |\n| Disciplinary | Documented |\n| Leaver process | Access + asset return |\n\n## Roles & Responsibilities\n- **HR + Security Lead** — owns this control area and its effectiveness.\n- **Asset/System Owners** — implement controls for their systems.\n- **All personnel** — comply and report security events.\n\n## Required Records\nScreening records, training records, and leaver checklists. Records are retained per the Documented Information Control procedure.\n\n## Review\nReviewed at least annually and on significant change. Revision 1.0."}},"audit":{"4":{"Audit Checklist":"## ISMS Internal Audit Checklist — Clause 4 (Context of the organization)\nMeridian Federal Solutions · Enterprise IT Service Desk (EITSD) contract · U.S. Department of Commerce\n\n| # | Requirement | Audit question | Evidence to sample | Conforms? |\n|---|---|---|---|---|\n| 1 | 4.1 | Is the requirement defined and documented? | Policy/procedure | ( ) |\n| 2 | 4.2 | Is it implemented? | Records, logs, tickets | ( ) |\n| 3 | 4.3 | Is it monitored and reviewed? | Reports, minutes | ( ) |\n\n**Sampling:** at least 5 records across the last 3 months.","Interview Questions":"## ISMS Auditor Interview Questions — Clause 4 (Context of the organization)\n\n- Who owns this part of the ISMS?\n- Walk me through how clause 4 works day to day.\n- What records evidence it, and where are they?\n- How is effectiveness measured and improved?","Objective Evidence Requirements":"## Objective Evidence — Clause 4 (Context of the organization)\n\nExpect the controlling document(s), dated operational records, monitoring output, and evidence of actions closed — current, attributable, and retained."},"5":{"Audit Checklist":"## ISMS Internal Audit Checklist — Clause 5 (Leadership)\nMeridian Federal Solutions · Enterprise IT Service Desk (EITSD) contract · U.S. Department of Commerce\n\n| # | Requirement | Audit question | Evidence to sample | Conforms? |\n|---|---|---|---|---|\n| 1 | 5.1 | Is the requirement defined and documented? | Policy/procedure | ( ) |\n| 2 | 5.2 | Is it implemented? | Records, logs, tickets | ( ) |\n| 3 | 5.3 | Is it monitored and reviewed? | Reports, minutes | ( ) |\n\n**Sampling:** at least 5 records across the last 3 months.","Interview Questions":"## ISMS Auditor Interview Questions — Clause 5 (Leadership)\n\n- Who owns this part of the ISMS?\n- Walk me through how clause 5 works day to day.\n- What records evidence it, and where are they?\n- How is effectiveness measured and improved?","Objective Evidence Requirements":"## Objective Evidence — Clause 5 (Leadership)\n\nExpect the controlling document(s), dated operational records, monitoring output, and evidence of actions closed — current, attributable, and retained."},"6":{"Audit Checklist":"## ISMS Internal Audit Checklist — Clause 6 (Planning)\nMeridian Federal Solutions · Enterprise IT Service Desk (EITSD) contract · U.S. Department of Commerce\n\n| # | Requirement | Audit question | Evidence to sample | Conforms? |\n|---|---|---|---|---|\n| 1 | 6.1 | Is the requirement defined and documented? | Policy/procedure | ( ) |\n| 2 | 6.2 | Is it implemented? | Records, logs, tickets | ( ) |\n| 3 | 6.3 | Is it monitored and reviewed? | Reports, minutes | ( ) |\n\n**Sampling:** at least 5 records across the last 3 months.","Interview Questions":"## ISMS Auditor Interview Questions — Clause 6 (Planning)\n\n- Who owns this part of the ISMS?\n- Walk me through how clause 6 works day to day.\n- What records evidence it, and where are they?\n- How is effectiveness measured and improved?","Objective Evidence Requirements":"## Objective Evidence — Clause 6 (Planning)\n\nExpect the controlling document(s), dated operational records, monitoring output, and evidence of actions closed — current, attributable, and retained."},"7":{"Audit Checklist":"## ISMS Internal Audit Checklist — Clause 7 (Support)\nMeridian Federal Solutions · Enterprise IT Service Desk (EITSD) contract · U.S. Department of Commerce\n\n| # | Requirement | Audit question | Evidence to sample | Conforms? |\n|---|---|---|---|---|\n| 1 | 7.1 | Is the requirement defined and documented? | Policy/procedure | ( ) |\n| 2 | 7.2 | Is it implemented? | Records, logs, tickets | ( ) |\n| 3 | 7.3 | Is it monitored and reviewed? | Reports, minutes | ( ) |\n\n**Sampling:** at least 5 records across the last 3 months.","Interview Questions":"## ISMS Auditor Interview Questions — Clause 7 (Support)\n\n- Who owns this part of the ISMS?\n- Walk me through how clause 7 works day to day.\n- What records evidence it, and where are they?\n- How is effectiveness measured and improved?","Objective Evidence Requirements":"## Objective Evidence — Clause 7 (Support)\n\nExpect the controlling document(s), dated operational records, monitoring output, and evidence of actions closed — current, attributable, and retained."},"8":{"Audit Checklist":"## ISMS Internal Audit Checklist — Clause 8 (Operation)\nMeridian Federal Solutions · Enterprise IT Service Desk (EITSD) contract · U.S. Department of Commerce\n\n| # | Requirement | Audit question | Evidence to sample | Conforms? |\n|---|---|---|---|---|\n| 1 | 8.1 | Is the requirement defined and documented? | Policy/procedure | ( ) |\n| 2 | 8.2 | Is it implemented? | Records, logs, tickets | ( ) |\n| 3 | 8.3 | Is it monitored and reviewed? | Reports, minutes | ( ) |\n\n**Sampling:** at least 5 records across the last 3 months.","Interview Questions":"## ISMS Auditor Interview Questions — Clause 8 (Operation)\n\n- Who owns this part of the ISMS?\n- Walk me through how clause 8 works day to day.\n- What records evidence it, and where are they?\n- How is effectiveness measured and improved?","Objective Evidence Requirements":"## Objective Evidence — Clause 8 (Operation)\n\nExpect the controlling document(s), dated operational records, monitoring output, and evidence of actions closed — current, attributable, and retained."},"9":{"Audit Checklist":"## ISMS Internal Audit Checklist — Clause 9 (Performance evaluation)\nMeridian Federal Solutions · Enterprise IT Service Desk (EITSD) contract · U.S. Department of Commerce\n\n| # | Requirement | Audit question | Evidence to sample | Conforms? |\n|---|---|---|---|---|\n| 1 | 9.1 | Is the requirement defined and documented? | Policy/procedure | ( ) |\n| 2 | 9.2 | Is it implemented? | Records, logs, tickets | ( ) |\n| 3 | 9.3 | Is it monitored and reviewed? | Reports, minutes | ( ) |\n\n**Sampling:** at least 5 records across the last 3 months.","Interview Questions":"## ISMS Auditor Interview Questions — Clause 9 (Performance evaluation)\n\n- Who owns this part of the ISMS?\n- Walk me through how clause 9 works day to day.\n- What records evidence it, and where are they?\n- How is effectiveness measured and improved?","Objective Evidence Requirements":"## Objective Evidence — Clause 9 (Performance evaluation)\n\nExpect the controlling document(s), dated operational records, monitoring output, and evidence of actions closed — current, attributable, and retained."},"10":{"Audit Checklist":"## ISMS Internal Audit Checklist — Clause 10 (Improvement)\nMeridian Federal Solutions · Enterprise IT Service Desk (EITSD) contract · U.S. Department of Commerce\n\n| # | Requirement | Audit question | Evidence to sample | Conforms? |\n|---|---|---|---|---|\n| 1 | 10.1 | Is the requirement defined and documented? | Policy/procedure | ( ) |\n| 2 | 10.2 | Is it implemented? | Records, logs, tickets | ( ) |\n| 3 | 10.3 | Is it monitored and reviewed? | Reports, minutes | ( ) |\n\n**Sampling:** at least 5 records across the last 3 months.","Interview Questions":"## ISMS Auditor Interview Questions — Clause 10 (Improvement)\n\n- Who owns this part of the ISMS?\n- Walk me through how clause 10 works day to day.\n- What records evidence it, and where are they?\n- How is effectiveness measured and improved?","Objective Evidence Requirements":"## Objective Evidence — Clause 10 (Improvement)\n\nExpect the controlling document(s), dated operational records, monitoring output, and evidence of actions closed — current, attributable, and retained."}},"docList":[{"key":"ismspolicy","name":"Information Security Policy","clause":"5.2"},{"key":"ismsscope","name":"ISMS Scope","clause":"4.3"},{"key":"context","name":"Context of the Organization","clause":"4.1"},{"key":"parties","name":"Interested Parties & Requirements","clause":"4.2"},{"key":"leadership","name":"Leadership & Roles","clause":"5.1 / 5.3"},{"key":"riskmethod","name":"Risk Assessment & Treatment Methodology","clause":"6.1.2"},{"key":"riskreport","name":"Risk Assessment Report","clause":"6.1.2"},{"key":"rtp","name":"Risk Treatment Plan","clause":"6.1.3"},{"key":"soa","name":"Statement of Applicability (SoA)","clause":"6.1.3 d)"},{"key":"objectives","name":"Information Security Objectives","clause":"6.2"},{"key":"competency","name":"Competence & Awareness","clause":"7.2 / 7.3"},{"key":"commplan","name":"Communication Plan","clause":"7.4"},{"key":"doccontrol","name":"Documented Information Control","clause":"7.5"},{"key":"records","name":"Records & Retention","clause":"7.5"},{"key":"sec_access","name":"Access Control — Control Pack","clause":"A.5.15–5.18, A.8.2–8.5"},{"key":"sec_crypto","name":"Cryptography & Key Management — Control Pack","clause":"A.8.24"},{"key":"sec_incident","name":"Information Security Incident Management — Control Pack","clause":"A.5.24–5.28"},{"key":"sec_supplier","name":"Supplier & Cloud Security — Control Pack","clause":"A.5.19–5.23"},{"key":"sec_logging","name":"Logging & Monitoring — Control Pack","clause":"A.8.15–8.16"},{"key":"sec_vuln","name":"Vulnerability & Patch Management — Control Pack","clause":"A.8.8"},{"key":"sec_continuity","name":"Business Continuity & Backup — Control Pack","clause":"A.5.29–5.30, A.8.13–8.14"},{"key":"sec_hr","name":"Human Resource Security — Control Pack","clause":"A.6.1–6.8"}]};

const DEMO_CMMC = {"generated":{"ssp":{"title":"System Security Plan (SSP)","clause":"3.12.4","content":"# System Security Plan (SSP)\n_NIST SP 800-171 · 3.12.4 · CMMC Level 2 · Meridian Federal Solutions_\n\n## 1. System identification\n**Organization:** Meridian Federal Solutions, LLC\n**Contract / driver:** U.S. Department of Commerce — Enterprise IT Service Desk (EITSD) contract\n**System:** ServiceNow and supporting infrastructure serving ~9,200 users across 14 sites.\n\n## 2. CUI environment\nThe system processes Controlled Unclassified Information (CUI) in support of the contract. The security boundary, data flows, and connections are documented in the CUI Scoping document.\n\n## 3. Control implementation summary\nThe 110 NIST SP 800-171 security requirements across 14 families are implemented as described in the control-family documents. Status by family:\n\n| Family | Area | Status |\n|---|---|---|\n| 3.1 | Access Control | Implemented (see pack) |\n| 3.2 | Awareness & Training | Implemented (see pack) |\n| 3.3 | Audit & Accountability | Implemented (see pack) |\n| 3.4 | Configuration Management | Implemented (see pack) |\n| 3.5 | Identification & Authentication | Implemented (see pack) |\n| 3.6 | Incident Response | Implemented (see pack) |\n| 3.7 | Maintenance | Implemented (see pack) |\n| 3.8 | Media Protection | Implemented (see pack) |\n| 3.9 | Personnel Security | Implemented (see pack) |\n| 3.10 | Physical Protection | Implemented (see pack) |\n| 3.11 | Risk Assessment | Implemented (see pack) |\n| 3.12 | Security Assessment | Implemented (see pack) |\n| 3.13 | System & Communications Protection | Implemented (see pack) |\n| 3.14 | System & Information Integrity | Implemented (see pack) |\n\n## 4. Assessment & POA&M\nControls are assessed at least annually; gaps are tracked to closure in the Plan of Action & Milestones (POA&M). A CMMC Level 2 assessment is targeted per contract.\n\n## 5. Approval\n| Version | Date | Author | Approved by |\n|---|---|---|---|\n| 1.0 | (current) | Security Lead | Program Manager |"},"scope":{"title":"CUI Scoping & Boundary","clause":"Scoping","content":"# CUI Scoping & Boundary\n_CMMC Level 2 · Meridian Federal Solutions_\n\n## In-scope assets\n| Category | Examples | In scope |\n|---|---|---|\n| CUI assets | Systems that store/process/transmit CUI (ServiceNow) | Yes |\n| Security protection assets | Identity, logging, endpoint protection | Yes |\n| Contractor risk-managed assets | Endpoints, admin workstations | Yes |\n| Specialized assets | On-site devices, if any | Assessed |\n| Out-of-scope | Systems with no CUI and no connection | No |\n\n## Boundary\nThe security boundary covers the people, processes and technology used to deliver the Enterprise IT Service Desk (EITSD) contract for U.S. Department of Commerce. Customer-provided infrastructure is a documented interface.\n\n## Review\nReviewed at least annually and on significant change."},"policy":{"title":"CUI Security Policy","clause":"Policy","content":"# CUI Security Policy\n_CMMC Level 2 / NIST SP 800-171 · Meridian Federal Solutions_\n\n## Purpose\nMeridian Federal Solutions, LLC protects Controlled Unclassified Information (CUI) handled in delivering the Enterprise IT Service Desk (EITSD) contract to U.S. Department of Commerce, meeting NIST SP 800-171 and CMMC Level 2 requirements.\n\n## Policy statements\n- We identify and mark CUI and limit access to authorized personnel.\n- We implement all 110 NIST SP 800-171 requirements across the 14 families.\n- We use FIPS-validated cryptography to protect CUI in transit and at rest.\n- We detect, report and respond to incidents involving CUI.\n- We assess controls, maintain an SSP and POA&M, and pursue CMMC certification.\n\n## Approval\nIssued by top management; reviewed at least annually."},"roles":{"title":"Roles & Responsibilities","clause":"3.1 / 3.9","content":"# Roles & Responsibilities\n_CMMC Level 2 · Meridian Federal Solutions_\n\n| Role | Responsibility |\n|---|---|\n| Program Manager | Accountable for CMMC compliance and the U.S. Department of Commerce relationship |\n| Security Lead / ISSO | Implements and assesses the 800-171 controls; owns SSP & POA&M |\n| System Owners | Operate controls on their systems |\n| Privileged Admins | Manage access, configuration and logging |\n| All personnel | Handle CUI correctly; complete training; report incidents |\n\nReviewed at least annually."},"risk":{"title":"Risk Assessment","clause":"3.11","content":"# Risk Assessment\n_NIST SP 800-171 · 3.11 · Meridian Federal Solutions_\n\n| ID | Risk to CUI | Likelihood | Impact | Treatment (practice) | Owner |\n|---|---|---|---|---|---|\n| CR1 | Unauthorized access to CUI | Medium | High | 3.1 access control; 3.5 MFA | Security Lead |\n| CR2 | Phishing / credential theft | High | High | 3.2 training; 3.5.3 MFA | Security Lead |\n| CR3 | Unpatched vulnerabilities | Medium | High | 3.11.2/3 scan & remediate | System Owner |\n| CR4 | CUI exfiltration | Medium | High | 3.13 boundary protection; 3.8 media | Security Lead |\n| CR5 | Malicious code | Medium | High | 3.14.2 anti-malware | System Owner |\n\nAssessed at least annually; scanning performed on a defined cadence."},"poam":{"title":"Plan of Action & Milestones (POA&M)","clause":"3.12.2","content":"# Plan of Action & Milestones (POA&M)\n_NIST SP 800-171 · 3.12.2 · Meridian Federal Solutions_\n\n| Item | Requirement | Weakness | Remediation | Owner | Milestone | Status |\n|---|---|---|---|---|---|---|\n| P1 | 3.3.5 | Log correlation not automated | Deploy SIEM correlation rules | Security Lead | Q2 | Open |\n| P2 | 3.4.1 | Baseline not documented for all hosts | Document and enforce baselines | System Owner | Q1 | In progress |\n| P3 | 3.6.3 | IR plan not yet tested | Run tabletop exercise | Security Lead | Q2 | Open |\n| P4 | 3.11.2 | Vulnerability scanning ad hoc | Establish scheduled scanning | System Owner | Q1 | In progress |\n\nOpen items are tracked to closure and reviewed at management review."},"training":{"title":"Awareness & Training Plan","clause":"3.2","content":"# Awareness & Training Plan\n_NIST SP 800-171 · 3.2 · Meridian Federal Solutions_\n\n| Topic | Audience | Frequency |\n|---|---|---|\n| CUI handling & marking | All personnel | Onboarding + annual |\n| Security awareness | All personnel | Annual + phishing sims |\n| Role-based security training | Privileged/admin roles | Onboarding + annual |\n| Insider-threat awareness | All personnel | Annual |\n\nTraining records are retained as assessment evidence."},"config":{"title":"Configuration Baseline Standard","clause":"3.4","content":"# Configuration Baseline Standard\n_NIST SP 800-171 · 3.4 · Meridian Federal Solutions_\n\n## Baselines\nSecure baseline configurations are defined and enforced for endpoints, servers and ServiceNow, based on recognized benchmarks (e.g. CIS/DISA STIG).\n\n| Control | Standard |\n|---|---|\n| Baseline & inventory | Documented; maintained (3.4.1) |\n| Security settings | Enforced via policy/MDM (3.4.2) |\n| Change control | Tracked and approved (3.4.3) |\n| Least functionality | Unnecessary services disabled (3.4.6) |\n\nReviewed at least annually and on significant change."},"irplan":{"title":"Incident Response Plan","clause":"3.6","content":"# Incident Response Plan\n_NIST SP 800-171 · 3.6 · Meridian Federal Solutions_\n\n## Phases\n1. **Prepare** — roles, tools and reporting channels defined.\n2. **Detect & analyze** — identify and classify incidents, including CUI exposure.\n3. **Contain, eradicate, recover** — limit impact and restore service.\n4. **Report** — notify the customer and required authorities (including DoD reporting where applicable) within required timeframes.\n5. **Post-incident** — review, preserve evidence, and improve.\n\nThe plan is tested (e.g. tabletop) at least annually per 3.6.3."},"fam_ac":{"title":"Access Control (3.1)","clause":"3.1","content":"# Access Control\n_NIST SP 800-171 · 3.1 · CMMC Level 2 · Meridian Federal Solutions · U.S. Department of Commerce_\n\n## Policy\nIt is Meridian Federal Solutions's policy to limit system access to authorized users and processes, on least privilege, protecting Controlled Unclassified Information (CUI) processed in support of the Enterprise IT Service Desk (EITSD) contract.\n\n## Procedure\n1. Apply the Access Control controls to all in-scope systems (ServiceNow and CUI assets).\n2. Assign responsibility to the System Owner and Security Lead.\n3. Operate and monitor the controls day to day.\n4. Record evidence of implementation and effectiveness.\n5. Remediate gaps via the Plan of Action & Milestones (POA&M).\n6. Review at least annually and on significant change.\n\n## Practices (NIST SP 800-171)\n| Practice | Requirement | Status |\n|---|---|---|\n| 3.1.1 | Limit access to authorized users, processes, devices | Implemented |\n| 3.1.2 | Limit access to permitted functions | Implemented |\n| 3.1.5 | Least privilege | Implemented |\n| 3.1.12 | Monitor and control remote access | Implemented |\n| 3.1.20 | Control connections to external systems | Implemented |\n\n## Roles & Responsibilities\n- **Security Lead** — accountable for this family's implementation and assessment.\n- **System Owners** — implement and operate the controls on their systems.\n- **All personnel** — comply and report issues.\n\n## Required Records\nImplementation evidence, monitoring output, and POA&M entries for Access Control, retained per policy.\n\n## Review\nAssessed at least annually and on significant change. Revision 1.0."},"fam_at":{"title":"Awareness & Training (3.2)","clause":"3.2","content":"# Awareness & Training\n_NIST SP 800-171 · 3.2 · CMMC Level 2 · Meridian Federal Solutions · U.S. Department of Commerce_\n\n## Policy\nIt is Meridian Federal Solutions's policy to make personnel aware of security risks and their responsibilities, protecting Controlled Unclassified Information (CUI) processed in support of the Enterprise IT Service Desk (EITSD) contract.\n\n## Procedure\n1. Apply the Awareness & Training controls to all in-scope systems (ServiceNow and CUI assets).\n2. Assign responsibility to the System Owner and Security Lead.\n3. Operate and monitor the controls day to day.\n4. Record evidence of implementation and effectiveness.\n5. Remediate gaps via the Plan of Action & Milestones (POA&M).\n6. Review at least annually and on significant change.\n\n## Practices (NIST SP 800-171)\n| Practice | Requirement | Status |\n|---|---|---|\n| 3.2.1 | Security awareness for all users | Implemented |\n| 3.2.2 | Role-based security training | Implemented |\n| 3.2.3 | Insider-threat awareness | Implemented |\n\n## Roles & Responsibilities\n- **Security Lead** — accountable for this family's implementation and assessment.\n- **System Owners** — implement and operate the controls on their systems.\n- **All personnel** — comply and report issues.\n\n## Required Records\nImplementation evidence, monitoring output, and POA&M entries for Awareness & Training, retained per policy.\n\n## Review\nAssessed at least annually and on significant change. Revision 1.0."},"fam_au":{"title":"Audit & Accountability (3.3)","clause":"3.3","content":"# Audit & Accountability\n_NIST SP 800-171 · 3.3 · CMMC Level 2 · Meridian Federal Solutions · U.S. Department of Commerce_\n\n## Policy\nIt is Meridian Federal Solutions's policy to create and protect audit logs to enable monitoring and investigation, protecting Controlled Unclassified Information (CUI) processed in support of the Enterprise IT Service Desk (EITSD) contract.\n\n## Procedure\n1. Apply the Audit & Accountability controls to all in-scope systems (ServiceNow and CUI assets).\n2. Assign responsibility to the System Owner and Security Lead.\n3. Operate and monitor the controls day to day.\n4. Record evidence of implementation and effectiveness.\n5. Remediate gaps via the Plan of Action & Milestones (POA&M).\n6. Review at least annually and on significant change.\n\n## Practices (NIST SP 800-171)\n| Practice | Requirement | Status |\n|---|---|---|\n| 3.3.1 | Create and retain system audit logs | Implemented |\n| 3.3.2 | Trace actions to individual users | Implemented |\n| 3.3.5 | Correlate audit review for investigation | Implemented |\n| 3.3.8 | Protect audit information from tampering | Implemented |\n\n## Roles & Responsibilities\n- **Security Lead** — accountable for this family's implementation and assessment.\n- **System Owners** — implement and operate the controls on their systems.\n- **All personnel** — comply and report issues.\n\n## Required Records\nImplementation evidence, monitoring output, and POA&M entries for Audit & Accountability, retained per policy.\n\n## Review\nAssessed at least annually and on significant change. Revision 1.0."},"fam_cm":{"title":"Configuration Management (3.4)","clause":"3.4","content":"# Configuration Management\n_NIST SP 800-171 · 3.4 · CMMC Level 2 · Meridian Federal Solutions · U.S. Department of Commerce_\n\n## Policy\nIt is Meridian Federal Solutions's policy to establish and maintain secure baseline configurations, protecting Controlled Unclassified Information (CUI) processed in support of the Enterprise IT Service Desk (EITSD) contract.\n\n## Procedure\n1. Apply the Configuration Management controls to all in-scope systems (ServiceNow and CUI assets).\n2. Assign responsibility to the System Owner and Security Lead.\n3. Operate and monitor the controls day to day.\n4. Record evidence of implementation and effectiveness.\n5. Remediate gaps via the Plan of Action & Milestones (POA&M).\n6. Review at least annually and on significant change.\n\n## Practices (NIST SP 800-171)\n| Practice | Requirement | Status |\n|---|---|---|\n| 3.4.1 | Baseline configurations and inventory | Implemented |\n| 3.4.2 | Enforce security configuration settings | Implemented |\n| 3.4.3 | Track and approve changes | Implemented |\n| 3.4.6 | Least functionality | Implemented |\n\n## Roles & Responsibilities\n- **Security Lead** — accountable for this family's implementation and assessment.\n- **System Owners** — implement and operate the controls on their systems.\n- **All personnel** — comply and report issues.\n\n## Required Records\nImplementation evidence, monitoring output, and POA&M entries for Configuration Management, retained per policy.\n\n## Review\nAssessed at least annually and on significant change. Revision 1.0."},"fam_ia":{"title":"Identification & Authentication (3.5)","clause":"3.5","content":"# Identification & Authentication\n_NIST SP 800-171 · 3.5 · CMMC Level 2 · Meridian Federal Solutions · U.S. Department of Commerce_\n\n## Policy\nIt is Meridian Federal Solutions's policy to identify and authenticate users and devices before access, protecting Controlled Unclassified Information (CUI) processed in support of the Enterprise IT Service Desk (EITSD) contract.\n\n## Procedure\n1. Apply the Identification & Authentication controls to all in-scope systems (ServiceNow and CUI assets).\n2. Assign responsibility to the System Owner and Security Lead.\n3. Operate and monitor the controls day to day.\n4. Record evidence of implementation and effectiveness.\n5. Remediate gaps via the Plan of Action & Milestones (POA&M).\n6. Review at least annually and on significant change.\n\n## Practices (NIST SP 800-171)\n| Practice | Requirement | Status |\n|---|---|---|\n| 3.5.1 | Identify users, processes, devices | Implemented |\n| 3.5.2 | Authenticate identities | Implemented |\n| 3.5.3 | Multifactor authentication | Implemented |\n| 3.5.10 | Store/transmit only cryptographically-protected passwords | Implemented |\n\n## Roles & Responsibilities\n- **Security Lead** — accountable for this family's implementation and assessment.\n- **System Owners** — implement and operate the controls on their systems.\n- **All personnel** — comply and report issues.\n\n## Required Records\nImplementation evidence, monitoring output, and POA&M entries for Identification & Authentication, retained per policy.\n\n## Review\nAssessed at least annually and on significant change. Revision 1.0."},"fam_ir":{"title":"Incident Response (3.6)","clause":"3.6","content":"# Incident Response\n_NIST SP 800-171 · 3.6 · CMMC Level 2 · Meridian Federal Solutions · U.S. Department of Commerce_\n\n## Policy\nIt is Meridian Federal Solutions's policy to establish an operational incident-handling capability, protecting Controlled Unclassified Information (CUI) processed in support of the Enterprise IT Service Desk (EITSD) contract.\n\n## Procedure\n1. Apply the Incident Response controls to all in-scope systems (ServiceNow and CUI assets).\n2. Assign responsibility to the System Owner and Security Lead.\n3. Operate and monitor the controls day to day.\n4. Record evidence of implementation and effectiveness.\n5. Remediate gaps via the Plan of Action & Milestones (POA&M).\n6. Review at least annually and on significant change.\n\n## Practices (NIST SP 800-171)\n| Practice | Requirement | Status |\n|---|---|---|\n| 3.6.1 | Incident-handling capability | Implemented |\n| 3.6.2 | Track, document and report incidents | Implemented |\n| 3.6.3 | Test incident response | Implemented |\n\n## Roles & Responsibilities\n- **Security Lead** — accountable for this family's implementation and assessment.\n- **System Owners** — implement and operate the controls on their systems.\n- **All personnel** — comply and report issues.\n\n## Required Records\nImplementation evidence, monitoring output, and POA&M entries for Incident Response, retained per policy.\n\n## Review\nAssessed at least annually and on significant change. Revision 1.0."},"fam_ma":{"title":"Maintenance (3.7)","clause":"3.7","content":"# Maintenance\n_NIST SP 800-171 · 3.7 · CMMC Level 2 · Meridian Federal Solutions · U.S. Department of Commerce_\n\n## Policy\nIt is Meridian Federal Solutions's policy to perform maintenance securely and control maintenance tools/personnel, protecting Controlled Unclassified Information (CUI) processed in support of the Enterprise IT Service Desk (EITSD) contract.\n\n## Procedure\n1. Apply the Maintenance controls to all in-scope systems (ServiceNow and CUI assets).\n2. Assign responsibility to the System Owner and Security Lead.\n3. Operate and monitor the controls day to day.\n4. Record evidence of implementation and effectiveness.\n5. Remediate gaps via the Plan of Action & Milestones (POA&M).\n6. Review at least annually and on significant change.\n\n## Practices (NIST SP 800-171)\n| Practice | Requirement | Status |\n|---|---|---|\n| 3.7.1 | Perform maintenance | Implemented |\n| 3.7.2 | Control maintenance tools | Implemented |\n| 3.7.5 | MFA for nonlocal maintenance | Implemented |\n\n## Roles & Responsibilities\n- **Security Lead** — accountable for this family's implementation and assessment.\n- **System Owners** — implement and operate the controls on their systems.\n- **All personnel** — comply and report issues.\n\n## Required Records\nImplementation evidence, monitoring output, and POA&M entries for Maintenance, retained per policy.\n\n## Review\nAssessed at least annually and on significant change. Revision 1.0."},"fam_mp":{"title":"Media Protection (3.8)","clause":"3.8","content":"# Media Protection\n_NIST SP 800-171 · 3.8 · CMMC Level 2 · Meridian Federal Solutions · U.S. Department of Commerce_\n\n## Policy\nIt is Meridian Federal Solutions's policy to protect and sanitize media containing CUI, protecting Controlled Unclassified Information (CUI) processed in support of the Enterprise IT Service Desk (EITSD) contract.\n\n## Procedure\n1. Apply the Media Protection controls to all in-scope systems (ServiceNow and CUI assets).\n2. Assign responsibility to the System Owner and Security Lead.\n3. Operate and monitor the controls day to day.\n4. Record evidence of implementation and effectiveness.\n5. Remediate gaps via the Plan of Action & Milestones (POA&M).\n6. Review at least annually and on significant change.\n\n## Practices (NIST SP 800-171)\n| Practice | Requirement | Status |\n|---|---|---|\n| 3.8.1 | Protect media with CUI | Implemented |\n| 3.8.3 | Sanitize media before disposal | Implemented |\n| 3.8.9 | Protect backup CUI | Implemented |\n\n## Roles & Responsibilities\n- **Security Lead** — accountable for this family's implementation and assessment.\n- **System Owners** — implement and operate the controls on their systems.\n- **All personnel** — comply and report issues.\n\n## Required Records\nImplementation evidence, monitoring output, and POA&M entries for Media Protection, retained per policy.\n\n## Review\nAssessed at least annually and on significant change. Revision 1.0."},"fam_ps":{"title":"Personnel Security (3.9)","clause":"3.9","content":"# Personnel Security\n_NIST SP 800-171 · 3.9 · CMMC Level 2 · Meridian Federal Solutions · U.S. Department of Commerce_\n\n## Policy\nIt is Meridian Federal Solutions's policy to screen personnel and protect CUI during personnel actions, protecting Controlled Unclassified Information (CUI) processed in support of the Enterprise IT Service Desk (EITSD) contract.\n\n## Procedure\n1. Apply the Personnel Security controls to all in-scope systems (ServiceNow and CUI assets).\n2. Assign responsibility to the System Owner and Security Lead.\n3. Operate and monitor the controls day to day.\n4. Record evidence of implementation and effectiveness.\n5. Remediate gaps via the Plan of Action & Milestones (POA&M).\n6. Review at least annually and on significant change.\n\n## Practices (NIST SP 800-171)\n| Practice | Requirement | Status |\n|---|---|---|\n| 3.9.1 | Screen individuals before access | Implemented |\n| 3.9.2 | Protect CUI during transfers/terminations | Implemented |\n\n## Roles & Responsibilities\n- **Security Lead** — accountable for this family's implementation and assessment.\n- **System Owners** — implement and operate the controls on their systems.\n- **All personnel** — comply and report issues.\n\n## Required Records\nImplementation evidence, monitoring output, and POA&M entries for Personnel Security, retained per policy.\n\n## Review\nAssessed at least annually and on significant change. Revision 1.0."},"fam_pe":{"title":"Physical Protection (3.10)","clause":"3.10","content":"# Physical Protection\n_NIST SP 800-171 · 3.10 · CMMC Level 2 · Meridian Federal Solutions · U.S. Department of Commerce_\n\n## Policy\nIt is Meridian Federal Solutions's policy to limit physical access to systems and environments, protecting Controlled Unclassified Information (CUI) processed in support of the Enterprise IT Service Desk (EITSD) contract.\n\n## Procedure\n1. Apply the Physical Protection controls to all in-scope systems (ServiceNow and CUI assets).\n2. Assign responsibility to the System Owner and Security Lead.\n3. Operate and monitor the controls day to day.\n4. Record evidence of implementation and effectiveness.\n5. Remediate gaps via the Plan of Action & Milestones (POA&M).\n6. Review at least annually and on significant change.\n\n## Practices (NIST SP 800-171)\n| Practice | Requirement | Status |\n|---|---|---|\n| 3.10.1 | Limit physical access | Implemented |\n| 3.10.3 | Escort visitors | Implemented |\n| 3.10.6 | Safeguard CUI at alternate work sites | Implemented |\n\n## Roles & Responsibilities\n- **Security Lead** — accountable for this family's implementation and assessment.\n- **System Owners** — implement and operate the controls on their systems.\n- **All personnel** — comply and report issues.\n\n## Required Records\nImplementation evidence, monitoring output, and POA&M entries for Physical Protection, retained per policy.\n\n## Review\nAssessed at least annually and on significant change. Revision 1.0."},"fam_ra":{"title":"Risk Assessment (3.11)","clause":"3.11","content":"# Risk Assessment\n_NIST SP 800-171 · 3.11 · CMMC Level 2 · Meridian Federal Solutions · U.S. Department of Commerce_\n\n## Policy\nIt is Meridian Federal Solutions's policy to assess and manage risk to operations and CUI, protecting Controlled Unclassified Information (CUI) processed in support of the Enterprise IT Service Desk (EITSD) contract.\n\n## Procedure\n1. Apply the Risk Assessment controls to all in-scope systems (ServiceNow and CUI assets).\n2. Assign responsibility to the System Owner and Security Lead.\n3. Operate and monitor the controls day to day.\n4. Record evidence of implementation and effectiveness.\n5. Remediate gaps via the Plan of Action & Milestones (POA&M).\n6. Review at least annually and on significant change.\n\n## Practices (NIST SP 800-171)\n| Practice | Requirement | Status |\n|---|---|---|\n| 3.11.1 | Assess risk periodically | Implemented |\n| 3.11.2 | Scan for vulnerabilities | Implemented |\n| 3.11.3 | Remediate vulnerabilities | Implemented |\n\n## Roles & Responsibilities\n- **Security Lead** — accountable for this family's implementation and assessment.\n- **System Owners** — implement and operate the controls on their systems.\n- **All personnel** — comply and report issues.\n\n## Required Records\nImplementation evidence, monitoring output, and POA&M entries for Risk Assessment, retained per policy.\n\n## Review\nAssessed at least annually and on significant change. Revision 1.0."},"fam_ca":{"title":"Security Assessment (3.12)","clause":"3.12","content":"# Security Assessment\n_NIST SP 800-171 · 3.12 · CMMC Level 2 · Meridian Federal Solutions · U.S. Department of Commerce_\n\n## Policy\nIt is Meridian Federal Solutions's policy to assess controls and maintain plans of action, protecting Controlled Unclassified Information (CUI) processed in support of the Enterprise IT Service Desk (EITSD) contract.\n\n## Procedure\n1. Apply the Security Assessment controls to all in-scope systems (ServiceNow and CUI assets).\n2. Assign responsibility to the System Owner and Security Lead.\n3. Operate and monitor the controls day to day.\n4. Record evidence of implementation and effectiveness.\n5. Remediate gaps via the Plan of Action & Milestones (POA&M).\n6. Review at least annually and on significant change.\n\n## Practices (NIST SP 800-171)\n| Practice | Requirement | Status |\n|---|---|---|\n| 3.12.1 | Assess controls periodically | Implemented |\n| 3.12.2 | Plans of action (POA&M) | Implemented |\n| 3.12.4 | System Security Plan | Implemented |\n\n## Roles & Responsibilities\n- **Security Lead** — accountable for this family's implementation and assessment.\n- **System Owners** — implement and operate the controls on their systems.\n- **All personnel** — comply and report issues.\n\n## Required Records\nImplementation evidence, monitoring output, and POA&M entries for Security Assessment, retained per policy.\n\n## Review\nAssessed at least annually and on significant change. Revision 1.0."},"fam_sc":{"title":"System & Communications Protection (3.13)","clause":"3.13","content":"# System & Communications Protection\n_NIST SP 800-171 · 3.13 · CMMC Level 2 · Meridian Federal Solutions · U.S. Department of Commerce_\n\n## Policy\nIt is Meridian Federal Solutions's policy to monitor and protect communications and system boundaries, protecting Controlled Unclassified Information (CUI) processed in support of the Enterprise IT Service Desk (EITSD) contract.\n\n## Procedure\n1. Apply the System & Communications Protection controls to all in-scope systems (ServiceNow and CUI assets).\n2. Assign responsibility to the System Owner and Security Lead.\n3. Operate and monitor the controls day to day.\n4. Record evidence of implementation and effectiveness.\n5. Remediate gaps via the Plan of Action & Milestones (POA&M).\n6. Review at least annually and on significant change.\n\n## Practices (NIST SP 800-171)\n| Practice | Requirement | Status |\n|---|---|---|\n| 3.13.1 | Monitor/protect boundaries | Implemented |\n| 3.13.8 | Encrypt CUI in transit | Implemented |\n| 3.13.11 | FIPS-validated cryptography | Implemented |\n| 3.13.16 | Protect CUI at rest | Implemented |\n\n## Roles & Responsibilities\n- **Security Lead** — accountable for this family's implementation and assessment.\n- **System Owners** — implement and operate the controls on their systems.\n- **All personnel** — comply and report issues.\n\n## Required Records\nImplementation evidence, monitoring output, and POA&M entries for System & Communications Protection, retained per policy.\n\n## Review\nAssessed at least annually and on significant change. Revision 1.0."},"fam_si":{"title":"System & Information Integrity (3.14)","clause":"3.14","content":"# System & Information Integrity\n_NIST SP 800-171 · 3.14 · CMMC Level 2 · Meridian Federal Solutions · U.S. Department of Commerce_\n\n## Policy\nIt is Meridian Federal Solutions's policy to identify and correct flaws and protect against malicious code, protecting Controlled Unclassified Information (CUI) processed in support of the Enterprise IT Service Desk (EITSD) contract.\n\n## Procedure\n1. Apply the System & Information Integrity controls to all in-scope systems (ServiceNow and CUI assets).\n2. Assign responsibility to the System Owner and Security Lead.\n3. Operate and monitor the controls day to day.\n4. Record evidence of implementation and effectiveness.\n5. Remediate gaps via the Plan of Action & Milestones (POA&M).\n6. Review at least annually and on significant change.\n\n## Practices (NIST SP 800-171)\n| Practice | Requirement | Status |\n|---|---|---|\n| 3.14.1 | Remediate flaws timely | Implemented |\n| 3.14.2 | Protect against malicious code | Implemented |\n| 3.14.6 | Monitor systems for attacks | Implemented |\n\n## Roles & Responsibilities\n- **Security Lead** — accountable for this family's implementation and assessment.\n- **System Owners** — implement and operate the controls on their systems.\n- **All personnel** — comply and report issues.\n\n## Required Records\nImplementation evidence, monitoring output, and POA&M entries for System & Information Integrity, retained per policy.\n\n## Review\nAssessed at least annually and on significant change. Revision 1.0."}},"audit":{"4":{"Assessment Checklist":"## CMMC / 800-171 Assessment Checklist — Family group 4\nMeridian Federal Solutions · Enterprise IT Service Desk (EITSD) contract · U.S. Department of Commerce\n\n| # | Practice area | Assessment question | Evidence | Met? |\n|---|---|---|---|---|\n| 1 | Definition | Is the requirement documented in the SSP? | SSP section | ( ) |\n| 2 | Implementation | Is it implemented on in-scope systems? | Configs, logs, records | ( ) |\n| 3 | Assessment | Is it assessed, with gaps in the POA&M? | Assessment + POA&M | ( ) |\n\n**Objective:** meet or POA&M every applicable 800-171 practice.","Assessor Interview Questions":"## Assessor Interview Questions — group 4\n\n- Show me where this is documented in the SSP.\n- Demonstrate the control operating on an in-scope system.\n- Where are the records, and how far back do they go?\n- For any gap, show the POA&M entry and milestone.","Objective Evidence":"## Objective Evidence — group 4\n\nExpect: the SSP narrative, system configurations, logs/records showing operation, assessment results, and POA&M entries for gaps — current, attributable and retained."},"5":{"Assessment Checklist":"## CMMC / 800-171 Assessment Checklist — Family group 5\nMeridian Federal Solutions · Enterprise IT Service Desk (EITSD) contract · U.S. Department of Commerce\n\n| # | Practice area | Assessment question | Evidence | Met? |\n|---|---|---|---|---|\n| 1 | Definition | Is the requirement documented in the SSP? | SSP section | ( ) |\n| 2 | Implementation | Is it implemented on in-scope systems? | Configs, logs, records | ( ) |\n| 3 | Assessment | Is it assessed, with gaps in the POA&M? | Assessment + POA&M | ( ) |\n\n**Objective:** meet or POA&M every applicable 800-171 practice.","Assessor Interview Questions":"## Assessor Interview Questions — group 5\n\n- Show me where this is documented in the SSP.\n- Demonstrate the control operating on an in-scope system.\n- Where are the records, and how far back do they go?\n- For any gap, show the POA&M entry and milestone.","Objective Evidence":"## Objective Evidence — group 5\n\nExpect: the SSP narrative, system configurations, logs/records showing operation, assessment results, and POA&M entries for gaps — current, attributable and retained."},"6":{"Assessment Checklist":"## CMMC / 800-171 Assessment Checklist — Family group 6\nMeridian Federal Solutions · Enterprise IT Service Desk (EITSD) contract · U.S. Department of Commerce\n\n| # | Practice area | Assessment question | Evidence | Met? |\n|---|---|---|---|---|\n| 1 | Definition | Is the requirement documented in the SSP? | SSP section | ( ) |\n| 2 | Implementation | Is it implemented on in-scope systems? | Configs, logs, records | ( ) |\n| 3 | Assessment | Is it assessed, with gaps in the POA&M? | Assessment + POA&M | ( ) |\n\n**Objective:** meet or POA&M every applicable 800-171 practice.","Assessor Interview Questions":"## Assessor Interview Questions — group 6\n\n- Show me where this is documented in the SSP.\n- Demonstrate the control operating on an in-scope system.\n- Where are the records, and how far back do they go?\n- For any gap, show the POA&M entry and milestone.","Objective Evidence":"## Objective Evidence — group 6\n\nExpect: the SSP narrative, system configurations, logs/records showing operation, assessment results, and POA&M entries for gaps — current, attributable and retained."},"7":{"Assessment Checklist":"## CMMC / 800-171 Assessment Checklist — Family group 7\nMeridian Federal Solutions · Enterprise IT Service Desk (EITSD) contract · U.S. Department of Commerce\n\n| # | Practice area | Assessment question | Evidence | Met? |\n|---|---|---|---|---|\n| 1 | Definition | Is the requirement documented in the SSP? | SSP section | ( ) |\n| 2 | Implementation | Is it implemented on in-scope systems? | Configs, logs, records | ( ) |\n| 3 | Assessment | Is it assessed, with gaps in the POA&M? | Assessment + POA&M | ( ) |\n\n**Objective:** meet or POA&M every applicable 800-171 practice.","Assessor Interview Questions":"## Assessor Interview Questions — group 7\n\n- Show me where this is documented in the SSP.\n- Demonstrate the control operating on an in-scope system.\n- Where are the records, and how far back do they go?\n- For any gap, show the POA&M entry and milestone.","Objective Evidence":"## Objective Evidence — group 7\n\nExpect: the SSP narrative, system configurations, logs/records showing operation, assessment results, and POA&M entries for gaps — current, attributable and retained."},"8":{"Assessment Checklist":"## CMMC / 800-171 Assessment Checklist — Family group 8\nMeridian Federal Solutions · Enterprise IT Service Desk (EITSD) contract · U.S. Department of Commerce\n\n| # | Practice area | Assessment question | Evidence | Met? |\n|---|---|---|---|---|\n| 1 | Definition | Is the requirement documented in the SSP? | SSP section | ( ) |\n| 2 | Implementation | Is it implemented on in-scope systems? | Configs, logs, records | ( ) |\n| 3 | Assessment | Is it assessed, with gaps in the POA&M? | Assessment + POA&M | ( ) |\n\n**Objective:** meet or POA&M every applicable 800-171 practice.","Assessor Interview Questions":"## Assessor Interview Questions — group 8\n\n- Show me where this is documented in the SSP.\n- Demonstrate the control operating on an in-scope system.\n- Where are the records, and how far back do they go?\n- For any gap, show the POA&M entry and milestone.","Objective Evidence":"## Objective Evidence — group 8\n\nExpect: the SSP narrative, system configurations, logs/records showing operation, assessment results, and POA&M entries for gaps — current, attributable and retained."},"9":{"Assessment Checklist":"## CMMC / 800-171 Assessment Checklist — Family group 9\nMeridian Federal Solutions · Enterprise IT Service Desk (EITSD) contract · U.S. Department of Commerce\n\n| # | Practice area | Assessment question | Evidence | Met? |\n|---|---|---|---|---|\n| 1 | Definition | Is the requirement documented in the SSP? | SSP section | ( ) |\n| 2 | Implementation | Is it implemented on in-scope systems? | Configs, logs, records | ( ) |\n| 3 | Assessment | Is it assessed, with gaps in the POA&M? | Assessment + POA&M | ( ) |\n\n**Objective:** meet or POA&M every applicable 800-171 practice.","Assessor Interview Questions":"## Assessor Interview Questions — group 9\n\n- Show me where this is documented in the SSP.\n- Demonstrate the control operating on an in-scope system.\n- Where are the records, and how far back do they go?\n- For any gap, show the POA&M entry and milestone.","Objective Evidence":"## Objective Evidence — group 9\n\nExpect: the SSP narrative, system configurations, logs/records showing operation, assessment results, and POA&M entries for gaps — current, attributable and retained."},"10":{"Assessment Checklist":"## CMMC / 800-171 Assessment Checklist — Family group 10\nMeridian Federal Solutions · Enterprise IT Service Desk (EITSD) contract · U.S. Department of Commerce\n\n| # | Practice area | Assessment question | Evidence | Met? |\n|---|---|---|---|---|\n| 1 | Definition | Is the requirement documented in the SSP? | SSP section | ( ) |\n| 2 | Implementation | Is it implemented on in-scope systems? | Configs, logs, records | ( ) |\n| 3 | Assessment | Is it assessed, with gaps in the POA&M? | Assessment + POA&M | ( ) |\n\n**Objective:** meet or POA&M every applicable 800-171 practice.","Assessor Interview Questions":"## Assessor Interview Questions — group 10\n\n- Show me where this is documented in the SSP.\n- Demonstrate the control operating on an in-scope system.\n- Where are the records, and how far back do they go?\n- For any gap, show the POA&M entry and milestone.","Objective Evidence":"## Objective Evidence — group 10\n\nExpect: the SSP narrative, system configurations, logs/records showing operation, assessment results, and POA&M entries for gaps — current, attributable and retained."}},"docList":[{"key":"policy","name":"CUI Security Policy","clause":"Policy"},{"key":"scope","name":"CUI Scoping & Boundary","clause":"Scoping"},{"key":"ssp","name":"System Security Plan (SSP)","clause":"3.12.4"},{"key":"roles","name":"Roles & Responsibilities","clause":"3.1 / 3.9"},{"key":"risk","name":"Risk Assessment","clause":"3.11"},{"key":"poam","name":"Plan of Action & Milestones (POA&M)","clause":"3.12.2"},{"key":"training","name":"Awareness & Training Plan","clause":"3.2"},{"key":"config","name":"Configuration Baseline Standard","clause":"3.4"},{"key":"irplan","name":"Incident Response Plan","clause":"3.6"},{"key":"fam_ac","name":"Access Control (3.1)","clause":"3.1"},{"key":"fam_at","name":"Awareness & Training (3.2)","clause":"3.2"},{"key":"fam_au","name":"Audit & Accountability (3.3)","clause":"3.3"},{"key":"fam_cm","name":"Configuration Management (3.4)","clause":"3.4"},{"key":"fam_ia","name":"Identification & Authentication (3.5)","clause":"3.5"},{"key":"fam_ir","name":"Incident Response (3.6)","clause":"3.6"},{"key":"fam_ma","name":"Maintenance (3.7)","clause":"3.7"},{"key":"fam_mp","name":"Media Protection (3.8)","clause":"3.8"},{"key":"fam_ps","name":"Personnel Security (3.9)","clause":"3.9"},{"key":"fam_pe","name":"Physical Protection (3.10)","clause":"3.10"},{"key":"fam_ra","name":"Risk Assessment (3.11)","clause":"3.11"},{"key":"fam_ca","name":"Security Assessment (3.12)","clause":"3.12"},{"key":"fam_sc","name":"System & Communications Protection (3.13)","clause":"3.13"},{"key":"fam_si","name":"System & Information Integrity (3.14)","clause":"3.14"}]};

const DEMO_9001 = {"generated":{"qualitypolicy":{"title":"Quality Policy","clause":"5.2","content":"# Quality Policy\n_ISO 9001:2015 — Clause 5.2 · Meridian Federal Solutions_\n\n## Purpose\nMeridian Federal Solutions, LLC is committed to consistently delivering the Enterprise IT Service Desk (EITSD) contract to U.S. Department of Commerce in a way that meets requirements and enhances customer satisfaction, under a QMS conforming to ISO 9001:2015.\n\n## Policy statements\n- Meet customer, statutory and regulatory requirements.\n- Set and review measurable quality objectives.\n- Apply the process approach and risk-based thinking.\n- Continually improve the QMS.\n\n| Version | Date | Author | Approved by |\n|---|---|---|---|\n| 1.0 | (current) | Quality Manager | Program Manager |"},"qmsscope":{"title":"QMS Scope","clause":"4.3","content":"# Scope of the QMS\n_ISO 9001:2015 — Clause 4.3 · Meridian Federal Solutions_\n\n**Organization:** Meridian Federal Solutions, LLC · **Customer:** U.S. Department of Commerce · **Services:** delivery of the Enterprise IT Service Desk (EITSD) contract (~9,200 users, 14 sites, on ServiceNow).\n\nThe QMS covers planning, delivery, control and improvement of the contracted services. Clause 8.3 (Design & Development) applies only where the organization designs services; otherwise justified as not applicable. Governing standard: ISO 9001:2015, clauses 4–10."},"context":{"title":"Context & Interested Parties","clause":"4.1 / 4.2","content":"# Context & Interested Parties\n_ISO 9001:2015 — Clauses 4.1 & 4.2 · Meridian Federal Solutions_\n\n## Issues\n| Type | Issue | Relevance |\n|---|---|---|\n| External | Customer & regulatory requirements | Set quality obligations |\n| External | Technology & market change | Improvement drivers |\n| Internal | Resource & competence | Affect conformity |\n| Internal | Process maturity | Affects consistency |\n\n## Interested parties\n| Party | Requirements |\n|---|---|\n| U.S. Department of Commerce | Conforming services; satisfaction |\n| End users (~9,200) | Reliable, correct service |\n| Employees | Clear processes; competence |\n| Suppliers | Clear requirements |\n| Regulators | Compliance |"},"leadership":{"title":"Leadership & Customer Focus","clause":"5.1","content":"# Leadership & Customer Focus\n_ISO 9001:2015 — Clause 5.1 · Meridian Federal Solutions_\n\nTop management demonstrates commitment by setting policy and objectives, ensuring resources, promoting the process approach and risk-based thinking, and maintaining customer focus.\n\n| Role | Responsibility | Authority |\n|---|---|---|\n| Program Manager | Accountable for the QMS & U.S. Department of Commerce relationship | Approves policy, budget |\n| Quality Manager | Maintains QMS; audits; improvement | Manages documents, actions |\n| Process Owners | Own & improve their processes | Direct their process |"},"objectives":{"title":"Quality Objectives","clause":"6.2","content":"# Quality Objectives\n_ISO 9001:2015 — Clause 6.2 · Meridian Federal Solutions_\n\n| Objective | Measure | Target | Owner |\n|---|---|---|---|\n| Meet service levels | SLA attainment | ≥ 95% | Service Delivery Manager |\n| Satisfy customers | CSAT | ≥ 90% | Quality Manager |\n| Reduce nonconformities | NCRs per quarter | Downward trend | Quality Manager |\n| On-time delivery | Deliverables on time | ≥ 98% | Program Manager |\n\nReviewed at management review (9.3)."},"riskopps":{"title":"Risks & Opportunities Register","clause":"6.1","content":"# Risks & Opportunities Register\n_ISO 9001:2015 — Clause 6.1 · Meridian Federal Solutions_\n\n| ID | Risk / Opportunity | Type | Action | Owner |\n|---|---|---|---|---|\n| Q1 | Missed SLAs from resource gaps | Risk | Capacity planning | Service Delivery Manager |\n| Q2 | Inconsistent execution | Risk | Documented procedures + audit | Quality Manager |\n| Q3 | Automation to reduce errors | Opportunity | Pilot automation | Program Manager |\n| Q4 | Best-practice reuse across sites | Opportunity | Standardize | Quality Manager |\n\nReviewed at management review."},"customerreq":{"title":"Requirements & Customer Communication","clause":"8.2","content":"# Requirements for Services & Customer Communication\n_ISO 9001:2015 — Clause 8.2 · Meridian Federal Solutions · U.S. Department of Commerce_\n\n## Policy\nIt is Meridian Federal Solutions's policy to determine, review and communicate requirements for the services before commitment, in delivering the Enterprise IT Service Desk (EITSD) contract to U.S. Department of Commerce across ServiceNow (9,200 users, 14 sites). Defined, measured and continually improved.\n\n## Procedure\n1. Capture requirements from the contract and customer.\n2. Review requirements for feasibility before committing (8.2.3).\n3. Resolve differences between stated and contracted requirements.\n4. Communicate with the customer on enquiries, changes and feedback.\n5. Record requirement reviews and changes.\n6. Handle customer property and feedback appropriately.\n\n## Workflow\nRequirement → review feasibility → commit → deliver → feedback → change control.\n\n## Key Controls\n| Control | Standard |\n|---|---|\n| Requirements review | Before commitment (8.2.3) |\n| Change control | Documented |\n| Customer communication | Defined channels |\n| Feedback capture | Continuous |\n\n## Roles & Responsibilities\n- **Service Delivery Manager** — owns this area; accountable for its outcomes.\n- **Team** — perform the work and record it.\n- **Manager** — accountable for performance.\n- **Executive / Program Manager** — owns the U.S. Department of Commerce relationship; approves resources.\n\n## Metrics & Targets\n| Metric | Target |\n|---|---|\n| Requirement reviews completed | 100% |\n| Customer enquiries answered on time | ≥ 95% |\n\n## Required Records\nRequirement reviews, change records, and customer communications. Retained per the records procedure.\n\n## Review\nReviewed at least annually and on significant change. Revision 1.0."},"serviceprovision":{"title":"Service Provision (Operation)","clause":"8.1 / 8.5","content":"# Operational Planning & Service Provision\n_ISO 9001:2015 — Clauses 8.1 & 8.5 · Meridian Federal Solutions · U.S. Department of Commerce_\n\n## Policy\nIt is Meridian Federal Solutions's policy to plan and control service provision so outputs consistently meet requirements, in delivering the Enterprise IT Service Desk (EITSD) contract to U.S. Department of Commerce across ServiceNow (9,200 users, 14 sites). Defined, measured and continually improved.\n\n## Procedure\n1. Plan delivery, resources and controls (8.1).\n2. Control service provision against defined criteria (8.5).\n3. Identify and trace outputs; preserve information.\n4. Control changes to service provision.\n5. Release only conforming services.\n6. Monitor against acceptance criteria.\n\n## Workflow\nPlan → control provision → monitor → release conforming service → change control.\n\n## RACI Matrix\n| Activity | Service Delivery Manager | Team | Manager | Executive |\n|---|---|---|---|---|\n| Plan delivery | A | R | C | I |\n| Control service provision | A | R | C | I |\n| Release conforming output | R | R | A | I |\n| Control changes | A | C | R | I |\n\n_R = Responsible, A = Accountable, C = Consulted, I = Informed._\n\n## Roles & Responsibilities\n- **Service Delivery Manager** — owns this area; accountable for its outcomes.\n- **Team** — perform the work and record it.\n- **Manager** — accountable for performance.\n- **Executive / Program Manager** — owns the U.S. Department of Commerce relationship; approves resources.\n\n## Metrics & Targets\n| Metric | Target |\n|---|---|\n| Services meeting acceptance criteria | ≥ 98% |\n| Unplanned changes | Downward trend |\n\n## Required Records\nService records, acceptance evidence, and change records. Retained per the records procedure.\n\n## Review\nReviewed at least annually and on significant change. Revision 1.0."},"purchasing":{"title":"Control of External Providers","clause":"8.4","content":"# Control of Externally Provided Processes & Suppliers\n_ISO 9001:2015 — Clause 8.4 · Meridian Federal Solutions · U.S. Department of Commerce_\n\n## Policy\nIt is Meridian Federal Solutions's policy to ensure externally provided processes, products and services conform to requirements, in delivering the Enterprise IT Service Desk (EITSD) contract to U.S. Department of Commerce across ServiceNow (9,200 users, 14 sites). Defined, measured and continually improved.\n\n## Procedure\n1. Define criteria for evaluation and selection of providers.\n2. Communicate requirements to providers.\n3. Verify externally provided items meet requirements.\n4. Monitor provider performance.\n5. Re-evaluate and re-approve providers periodically.\n6. Address provider nonconformities.\n\n## Workflow\nEvaluate → select → communicate requirements → verify → monitor → re-approve.\n\n## Key Controls\n| Control | Standard |\n|---|---|\n| Evaluation & selection | Criteria-based |\n| Requirements to suppliers | Documented |\n| Verification | On receipt/service |\n| Performance monitoring | Periodic |\n\n## Roles & Responsibilities\n- **Quality Manager** — owns this area; accountable for its outcomes.\n- **Team** — perform the work and record it.\n- **Manager** — accountable for performance.\n- **Executive / Program Manager** — owns the U.S. Department of Commerce relationship; approves resources.\n\n## Metrics & Targets\n| Metric | Target |\n|---|---|\n| Supplier conformance | ≥ 95% |\n| Approved-supplier use | 100% |\n\n## Required Records\nApproved supplier list, evaluations, and verification records. Retained per the records procedure.\n\n## Review\nReviewed at least annually and on significant change. Revision 1.0."},"nonconformity":{"title":"Control of Nonconforming Outputs","clause":"8.7","content":"# Control of Nonconforming Outputs\n_ISO 9001:2015 — Clause 8.7 · Meridian Federal Solutions · U.S. Department of Commerce_\n\n## Policy\nIt is Meridian Federal Solutions's policy to identify and control outputs that do not conform, to prevent unintended use, in delivering the Enterprise IT Service Desk (EITSD) contract to U.S. Department of Commerce across ServiceNow (9,200 users, 14 sites). Defined, measured and continually improved.\n\n## Procedure\n1. Identify and segregate nonconforming output.\n2. Correct, or obtain concession where appropriate.\n3. Record the nonconformity and action taken.\n4. Verify conformity after correction.\n5. Raise corrective action where recurrence is likely.\n\n## Workflow\nDetect nonconformity → segregate → correct/concession → verify → record → corrective action.\n\n## Key Controls\n| Control | Standard |\n|---|---|\n| Identification | Marked & segregated |\n| Disposition | Correct / concession / reject |\n| Verification | Re-checked |\n| Records | Retained |\n\n## Roles & Responsibilities\n- **Quality Manager** — owns this area; accountable for its outcomes.\n- **Team** — perform the work and record it.\n- **Manager** — accountable for performance.\n- **Executive / Program Manager** — owns the U.S. Department of Commerce relationship; approves resources.\n\n## Metrics & Targets\n| Metric | Target |\n|---|---|\n| Escaped nonconformities | 0 |\n| NCR closure on time | ≥ 90% |\n\n## Required Records\nNonconformity records and disposition decisions. Retained per the records procedure.\n\n## Review\nReviewed at least annually and on significant change. Revision 1.0."},"monitoring":{"title":"Monitoring, Measurement & Customer Satisfaction","clause":"9.1","content":"# Monitoring, Measurement & Customer Satisfaction\n_ISO 9001:2015 — Clause 9.1 · Meridian Federal Solutions · U.S. Department of Commerce_\n\n## Policy\nIt is Meridian Federal Solutions's policy to monitor performance and customer satisfaction and act on the results, in delivering the Enterprise IT Service Desk (EITSD) contract to U.S. Department of Commerce across ServiceNow (9,200 users, 14 sites). Defined, measured and continually improved.\n\n## Procedure\n1. Determine what to monitor and measure.\n2. Track service performance against SLAs.\n3. Measure customer satisfaction (survey / feedback).\n4. Analyse data for trends.\n5. Report to management review.\n6. Trigger improvement where targets are missed.\n\n## Workflow\nDefine measures → monitor → measure satisfaction → analyse → report → improve.\n\n\n\n## Roles & Responsibilities\n- **Quality Manager** — owns this area; accountable for its outcomes.\n- **Team** — perform the work and record it.\n- **Manager** — accountable for performance.\n- **Executive / Program Manager** — owns the U.S. Department of Commerce relationship; approves resources.\n\n## Metrics & Targets\n| Metric | Target |\n|---|---|\n| SLA attainment | ≥ 95% |\n| CSAT | ≥ 90% |\n| Data reviewed at MR | 100% |\n\n## Required Records\nPerformance data, satisfaction results, and analysis. Retained per the records procedure.\n\n## Review\nReviewed at least annually and on significant change. Revision 1.0."},"competency":{"title":"Competence & Awareness","clause":"7.2 / 7.3","content":"# Competence & Awareness\n_ISO 9001:2015 — Clauses 7.2 & 7.3 · Meridian Federal Solutions_\n\n| Role | Required competence | Evidence |\n|---|---|---|\n| Management representative | ISO 9001:2015 operation; auditing | Training / certification |\n| Process owners | Their process & controls | Role training records |\n| Delivery staff | ServiceNow; procedures | Onboarding + refresher |\n| Internal auditors | Auditing this standard | Auditor training |\n\nAwareness of the policy, objectives and their contribution is provided to all personnel at onboarding and annually. Records are retained."},"communication":{"title":"Communication Plan","clause":"7.4","content":"# Communication Plan\n_ISO 9001:2015 — Clause 7.4 · Meridian Federal Solutions_\n\n| Communication | Audience | Frequency | Channel | Owner |\n|---|---|---|---|---|\n| Performance report | U.S. Department of Commerce | Monthly | Report | Management rep |\n| Management review | Top management | Quarterly | Meeting + minutes | Program Manager |\n| Policy & changes | All staff | On change | Portal / briefing | Management rep |\n| Issues & escalations | Affected parties | As needed | ServiceNow / email | Process owners |\n| Objectives & results | All staff | Quarterly | Briefing | Management rep |"},"doccontrol":{"title":"Control of Documented Information","clause":"7.5","content":"# Control of Documented Information\n_ISO 9001:2015 — Clause 7.5 · Meridian Federal Solutions_\n\n## Procedure\n1. Create using approved templates.\n2. Review and approve before publication.\n3. Version as Major.Minor; record version, date, approver.\n4. Publish to the controlled repository with access control.\n5. Review at least annually and on significant change.\n6. Archive superseded versions.\n\n| Control | Rule |\n|---|---|\n| Naming | [Type] - [Title] - v[version] |\n| Storage | Controlled, access-restricted repository |\n| Change record | Version table in each document |\n| Retention | Per the records procedure |"},"records":{"title":"Records & Retention","clause":"7.5","content":"# Records & Retention\n_ISO 9001:2015 — Clause 7.5 · Meridian Federal Solutions_\n\n| Record | Owner | Storage | Retention |\n|---|---|---|---|\n| Objectives & KPI results | Management rep | Repository | Term + 1 year |\n| Internal audit reports | Internal auditor | Repository | Term + 1 year |\n| Management review minutes | Program Manager | Repository | Term + 1 year |\n| Nonconformity & actions | Management rep | Repository | Term + 1 year |\n| Training records | HR | HR system | Employment + per policy |\n| Operational records | Process owners | ServiceNow | Term + 1 year |\n\nRecords are protected against loss and unauthorised change; disposed of securely at end of retention."},"internalaudit":{"title":"Internal Audit Programme","clause":"9.2","content":"# Internal Audit Programme\n_ISO 9001:2015 — Clause 9.2 · Meridian Federal Solutions_\n\n## Procedure\n1. Plan an annual audit programme covering all clauses/controls.\n2. Assign impartial auditors (not auditing their own work).\n3. Conduct audits against the standard and this system.\n4. Record findings (conformities and nonconformities).\n5. Raise corrective actions and track to closure.\n6. Report results to management review.\n\n| Element | Standard |\n|---|---|\n| Frequency | At least annual; risk-based |\n| Auditor independence | Required |\n| Evidence | Sampled records, interviews |\n| Output | Audit report + actions |"},"mgmtreview":{"title":"Management Review","clause":"9.3","content":"# Management Review\n_ISO 9001:2015 — Clause 9.3 · Meridian Federal Solutions_\n\nTop management reviews the system at least quarterly. Inputs and outputs:\n\n| Inputs | Outputs |\n|---|---|\n| Status of prior actions | Decisions on improvement |\n| Objective & KPI performance | Resource decisions |\n| Audit results & nonconformities | Changes to the system |\n| Customer feedback / satisfaction | Updated objectives |\n| Risks & opportunities | Action assignments |\n\nMinutes are recorded and retained as evidence."},"improvement":{"title":"Nonconformity, Corrective Action & Improvement","clause":"10.1 / 10.2","content":"# Nonconformity, Corrective Action & Improvement\n_ISO 9001:2015 — Clauses 10.1 & 10.2 · Meridian Federal Solutions_\n\n## Procedure\n1. Identify and record the nonconformity.\n2. Contain and correct the immediate issue.\n3. Analyse the root cause.\n4. Implement corrective action to prevent recurrence.\n5. Verify effectiveness and close.\n6. Feed improvement opportunities into the register.\n\n| Field | Example |\n|---|---|\n| Source | Audit, complaint, incident, KPI miss |\n| Correction | Immediate fix |\n| Corrective action | Root-cause removal |\n| Verification | Effectiveness confirmed |\n\nContinual improvement is driven through the register, reviewed at management review."}},"audit":{"4":{"Audit Checklist":"## Internal Audit Checklist — Clause 4 (Context)\nMeridian Federal Solutions · Enterprise IT Service Desk (EITSD) contract · ISO 9001:2015\n\n| # | Requirement | Audit question | Evidence | Conforms? |\n|---|---|---|---|---|\n| 1 | 4.1 | Defined & documented? | Policy/procedure | ( ) |\n| 2 | 4.2 | Implemented? | Records | ( ) |\n| 3 | 4.3 | Monitored & reviewed? | Reports, minutes | ( ) |","Interview Questions":"## Interview Questions — Clause 4 (Context)\n- Who owns this and how is it kept current?\n- Walk me through how you meet clause 4.\n- What records evidence it, and where?\n- How is effectiveness measured and improved?","Objective Evidence":"## Objective Evidence — Clause 4 (Context)\nExpect controlling document(s), dated operational records, monitoring output, and evidence of closed actions — current, attributable, retained."},"5":{"Audit Checklist":"## Internal Audit Checklist — Clause 5 (Leadership)\nMeridian Federal Solutions · Enterprise IT Service Desk (EITSD) contract · ISO 9001:2015\n\n| # | Requirement | Audit question | Evidence | Conforms? |\n|---|---|---|---|---|\n| 1 | 5.1 | Defined & documented? | Policy/procedure | ( ) |\n| 2 | 5.2 | Implemented? | Records | ( ) |\n| 3 | 5.3 | Monitored & reviewed? | Reports, minutes | ( ) |","Interview Questions":"## Interview Questions — Clause 5 (Leadership)\n- Who owns this and how is it kept current?\n- Walk me through how you meet clause 5.\n- What records evidence it, and where?\n- How is effectiveness measured and improved?","Objective Evidence":"## Objective Evidence — Clause 5 (Leadership)\nExpect controlling document(s), dated operational records, monitoring output, and evidence of closed actions — current, attributable, retained."},"6":{"Audit Checklist":"## Internal Audit Checklist — Clause 6 (Planning)\nMeridian Federal Solutions · Enterprise IT Service Desk (EITSD) contract · ISO 9001:2015\n\n| # | Requirement | Audit question | Evidence | Conforms? |\n|---|---|---|---|---|\n| 1 | 6.1 | Defined & documented? | Policy/procedure | ( ) |\n| 2 | 6.2 | Implemented? | Records | ( ) |\n| 3 | 6.3 | Monitored & reviewed? | Reports, minutes | ( ) |","Interview Questions":"## Interview Questions — Clause 6 (Planning)\n- Who owns this and how is it kept current?\n- Walk me through how you meet clause 6.\n- What records evidence it, and where?\n- How is effectiveness measured and improved?","Objective Evidence":"## Objective Evidence — Clause 6 (Planning)\nExpect controlling document(s), dated operational records, monitoring output, and evidence of closed actions — current, attributable, retained."},"7":{"Audit Checklist":"## Internal Audit Checklist — Clause 7 (Support)\nMeridian Federal Solutions · Enterprise IT Service Desk (EITSD) contract · ISO 9001:2015\n\n| # | Requirement | Audit question | Evidence | Conforms? |\n|---|---|---|---|---|\n| 1 | 7.1 | Defined & documented? | Policy/procedure | ( ) |\n| 2 | 7.2 | Implemented? | Records | ( ) |\n| 3 | 7.3 | Monitored & reviewed? | Reports, minutes | ( ) |","Interview Questions":"## Interview Questions — Clause 7 (Support)\n- Who owns this and how is it kept current?\n- Walk me through how you meet clause 7.\n- What records evidence it, and where?\n- How is effectiveness measured and improved?","Objective Evidence":"## Objective Evidence — Clause 7 (Support)\nExpect controlling document(s), dated operational records, monitoring output, and evidence of closed actions — current, attributable, retained."},"8":{"Audit Checklist":"## Internal Audit Checklist — Clause 8 (Operation)\nMeridian Federal Solutions · Enterprise IT Service Desk (EITSD) contract · ISO 9001:2015\n\n| # | Requirement | Audit question | Evidence | Conforms? |\n|---|---|---|---|---|\n| 1 | 8.1 | Defined & documented? | Policy/procedure | ( ) |\n| 2 | 8.2 | Implemented? | Records | ( ) |\n| 3 | 8.3 | Monitored & reviewed? | Reports, minutes | ( ) |","Interview Questions":"## Interview Questions — Clause 8 (Operation)\n- Who owns this and how is it kept current?\n- Walk me through how you meet clause 8.\n- What records evidence it, and where?\n- How is effectiveness measured and improved?","Objective Evidence":"## Objective Evidence — Clause 8 (Operation)\nExpect controlling document(s), dated operational records, monitoring output, and evidence of closed actions — current, attributable, retained."},"9":{"Audit Checklist":"## Internal Audit Checklist — Clause 9 (Performance evaluation)\nMeridian Federal Solutions · Enterprise IT Service Desk (EITSD) contract · ISO 9001:2015\n\n| # | Requirement | Audit question | Evidence | Conforms? |\n|---|---|---|---|---|\n| 1 | 9.1 | Defined & documented? | Policy/procedure | ( ) |\n| 2 | 9.2 | Implemented? | Records | ( ) |\n| 3 | 9.3 | Monitored & reviewed? | Reports, minutes | ( ) |","Interview Questions":"## Interview Questions — Clause 9 (Performance evaluation)\n- Who owns this and how is it kept current?\n- Walk me through how you meet clause 9.\n- What records evidence it, and where?\n- How is effectiveness measured and improved?","Objective Evidence":"## Objective Evidence — Clause 9 (Performance evaluation)\nExpect controlling document(s), dated operational records, monitoring output, and evidence of closed actions — current, attributable, retained."},"10":{"Audit Checklist":"## Internal Audit Checklist — Clause 10 (Improvement)\nMeridian Federal Solutions · Enterprise IT Service Desk (EITSD) contract · ISO 9001:2015\n\n| # | Requirement | Audit question | Evidence | Conforms? |\n|---|---|---|---|---|\n| 1 | 10.1 | Defined & documented? | Policy/procedure | ( ) |\n| 2 | 10.2 | Implemented? | Records | ( ) |\n| 3 | 10.3 | Monitored & reviewed? | Reports, minutes | ( ) |","Interview Questions":"## Interview Questions — Clause 10 (Improvement)\n- Who owns this and how is it kept current?\n- Walk me through how you meet clause 10.\n- What records evidence it, and where?\n- How is effectiveness measured and improved?","Objective Evidence":"## Objective Evidence — Clause 10 (Improvement)\nExpect controlling document(s), dated operational records, monitoring output, and evidence of closed actions — current, attributable, retained."}},"docList":[{"key":"qualitypolicy","name":"Quality Policy","clause":"5.2"},{"key":"qmsscope","name":"QMS Scope","clause":"4.3"},{"key":"context","name":"Context & Interested Parties","clause":"4.1 / 4.2"},{"key":"leadership","name":"Leadership & Customer Focus","clause":"5.1"},{"key":"objectives","name":"Quality Objectives","clause":"6.2"},{"key":"riskopps","name":"Risks & Opportunities Register","clause":"6.1"},{"key":"competency","name":"Competence & Awareness","clause":"7.2 / 7.3"},{"key":"communication","name":"Communication Plan","clause":"7.4"},{"key":"doccontrol","name":"Control of Documented Information","clause":"7.5"},{"key":"records","name":"Records & Retention","clause":"7.5"},{"key":"customerreq","name":"Requirements & Customer Communication","clause":"8.2"},{"key":"serviceprovision","name":"Service Provision (Operation)","clause":"8.1 / 8.5"},{"key":"purchasing","name":"Control of External Providers","clause":"8.4"},{"key":"nonconformity","name":"Control of Nonconforming Outputs","clause":"8.7"},{"key":"monitoring","name":"Monitoring, Measurement & Customer Satisfaction","clause":"9.1"},{"key":"internalaudit","name":"Internal Audit Programme","clause":"9.2"},{"key":"mgmtreview","name":"Management Review","clause":"9.3"},{"key":"improvement","name":"Nonconformity, Corrective Action & Improvement","clause":"10.1 / 10.2"}]};
const DEMO_22301 = {"generated":{"bcpolicy":{"title":"Business Continuity Policy","clause":"5.2","content":"# Business Continuity Policy\n_ISO 22301:2019 — Clause 5.2 · Meridian Federal Solutions_\n\nMeridian Federal Solutions, LLC maintains the capability to continue delivery of the Enterprise IT Service Desk (EITSD) contract to U.S. Department of Commerce during and after disruption, under a BCMS conforming to ISO 22301:2019.\n\n- Identify critical activities and set recovery objectives.\n- Prepare, maintain and exercise continuity plans.\n- Meet contractual and regulatory continuity obligations.\n\n| Version | Date | Approved by |\n|---|---|---|\n| 1.0 | (current) | Program Manager |"},"bcscope":{"title":"BCMS Scope","clause":"4.3","content":"# Scope of the BCMS\n_ISO 22301:2019 — Clause 4.3 · Meridian Federal Solutions_\n\nCovers the people, processes and technology (ServiceNow) delivering the Enterprise IT Service Desk (EITSD) contract across 14 sites (~9,200 users). Governing standard: ISO 22301:2019, clauses 4–10."},"context":{"title":"Context & Interested Parties","clause":"4.1 / 4.2","content":"# Context & Interested Parties\n_ISO 22301:2019 — Clauses 4.1 & 4.2 · Meridian Federal Solutions_\n\n| Party | Continuity requirement |\n|---|---|\n| U.S. Department of Commerce | Continued service within agreed targets |\n| End users (~9,200) | Minimal disruption |\n| Regulators | Compliance with continuity obligations |\n| Suppliers | Coordinated recovery |\n\nExternal/internal issues (threats, dependencies, resourcing) are reviewed at management review."},"leadership":{"title":"Leadership & Roles","clause":"5.1 / 5.3","content":"# Leadership & Roles\n_ISO 22301:2019 — Clauses 5.1 & 5.3 · Meridian Federal Solutions_\n\n| Role | Responsibility |\n|---|---|\n| Program Manager | Accountable for the BCMS and U.S. Department of Commerce relationship |\n| Continuity Manager | Runs the BCMS; BIA, strategy, plans, exercises |\n| Incident Manager | Leads incident response and recovery |\n| Process Owners | Maintain their recovery procedures |"},"objectives":{"title":"BC Objectives","clause":"6.2","content":"# Business Continuity Objectives\n_ISO 22301:2019 — Clause 6.2 · Meridian Federal Solutions_\n\n| Objective | Measure | Target |\n|---|---|---|\n| Meet recovery targets | RTO met in tests | 100% |\n| Exercise the plans | Exercises completed | Per programme |\n| Maintain currency | Plans reviewed | Annual + on change |\n\nReviewed at management review."},"bia":{"title":"Business Impact Analysis (BIA)","clause":"8.2.2","content":"# Business Impact Analysis (BIA)\n_ISO 22301:2019 — Clause 8.2.2 · Meridian Federal Solutions_\n\n| Activity | Impact of disruption | MTPD | RTO | RPO | Priority |\n|---|---|---|---|---|---|\n| Service desk (P1 handling) | Users unable to work; SLA breach | 4h | 2h | 15m | Critical |\n| Ticketing platform (ServiceNow) | No incident/request handling | 4h | 2h | 15m | Critical |\n| Reporting | Delayed SLA reporting | 5d | 3d | 1d | Medium |\n| Knowledge base | Lower FCR | 3d | 2d | 1d | Medium |\n\n_MTPD = maximum tolerable period of disruption; RTO/RPO = recovery time/point objectives._ Reviewed at least annually and on significant change."},"riskassessment":{"title":"BC Risk Assessment","clause":"8.2.3","content":"# Business Continuity Risk Assessment\n_ISO 22301:2019 — Clause 8.2.3 · Meridian Federal Solutions_\n\n| ID | Threat | Likelihood | Impact | Treatment | Owner |\n|---|---|---|---|---|---|\n| B1 | Platform/data-center outage | Low | High | Redundancy; failover; backups | Continuity Manager |\n| B2 | Loss of site access | Low | High | Remote-work capability | Continuity Manager |\n| B3 | Key staff unavailability | Medium | Medium | Cross-training; on-call | Service Delivery Manager |\n| B4 | Cyber incident | Medium | High | IR + continuity integration | Security Lead |\n\nReviewed at least annually."},"strategy":{"title":"BC Strategy & Solutions","clause":"8.3","content":"# Business Continuity Strategy & Solutions\n_ISO 22301:2019 — Clause 8.3 · Meridian Federal Solutions · U.S. Department of Commerce_\n\n## Policy\nIt is Meridian Federal Solutions's policy to select strategies and solutions that meet the recovery objectives from the BIA, in delivering the Enterprise IT Service Desk (EITSD) contract to U.S. Department of Commerce across ServiceNow (9,200 users, 14 sites). Defined, measured and continually improved.\n\n## Procedure\n1. Derive requirements from the BIA (RTO/RPO/MTPD).\n2. Identify options for people, premises, technology and suppliers.\n3. Select strategies that meet objectives at justifiable cost.\n4. Provision the required resources.\n5. Document solution details and dependencies.\n6. Validate against the BIA.\n\n## Workflow\nBIA requirements → options → selection → provision → validate.\n\n## Key Controls\n| Control | Standard |\n|---|---|\n| Meet RTO/RPO | Redundancy; frequent backups; tested restore |\n| Site loss | Remote-work + alternate site |\n| Staffing | Cross-training; on-call |\n| Platform | Provider resilience + failover |\n\n## Roles & Responsibilities\n- **Continuity Manager** — owns this area; accountable for its outcomes.\n- **Team** — perform the work and record it.\n- **Manager** — accountable for performance.\n- **Executive / Program Manager** — owns the U.S. Department of Commerce relationship; approves resources.\n\n## Metrics & Targets\n| Metric | Target |\n|---|---|\n| Strategies meeting BIA targets | 100% |\n| Provisioned resources ready | 100% |\n\n## Required Records\nThe strategy document and resource provisioning records. Retained per the records procedure.\n\n## Review\nReviewed at least annually and on significant change. Revision 1.0."},"plans":{"title":"Business Continuity Plans","clause":"8.4","content":"# Business Continuity Plans\n_ISO 22301:2019 — Clause 8.4 · Meridian Federal Solutions · U.S. Department of Commerce_\n\n## Policy\nIt is Meridian Federal Solutions's policy to provide documented procedures to continue and recover critical activities, in delivering the Enterprise IT Service Desk (EITSD) contract to U.S. Department of Commerce across ServiceNow (9,200 users, 14 sites). Defined, measured and continually improved.\n\n## Procedure\n1. Define activation criteria and authority.\n2. Establish the incident response team and roles.\n3. Set out communications (staff, ${c.CUST}, suppliers).\n4. Document recovery procedures per critical activity to meet RTO/RPO.\n5. List resources and dependencies.\n6. Define return-to-normal criteria.\n\n## Workflow\nActivation → mobilize team → communicate → recover per procedure → return to normal.\n\n## Key Controls\n| Control | Standard |\n|---|---|\n| Activation criteria | Defined & authorized |\n| Team & roles | Named |\n| Communications | Pre-drafted |\n| Recovery procedures | Per critical activity |\n\n## Roles & Responsibilities\n- **Continuity Manager** — owns this area; accountable for its outcomes.\n- **Team** — perform the work and record it.\n- **Manager** — accountable for performance.\n- **Executive / Program Manager** — owns the U.S. Department of Commerce relationship; approves resources.\n\n## Metrics & Targets\n| Metric | Target |\n|---|---|\n| Plans covering critical activities | 100% |\n| Plans accessible during disruption | Yes |\n\n## Required Records\nContinuity plans, contact lists, and recovery procedures. Retained per the records procedure.\n\n## Review\nReviewed at least annually and on significant change. Revision 1.0."},"incident":{"title":"Incident Response Structure","clause":"8.4.2","content":"# Incident Response Structure\n_ISO 22301:2019 — Clause 8.4.2 · Meridian Federal Solutions · U.S. Department of Commerce_\n\n## Policy\nIt is Meridian Federal Solutions's policy to provide a defined structure to respond to disruptive incidents, in delivering the Enterprise IT Service Desk (EITSD) contract to U.S. Department of Commerce across ServiceNow (9,200 users, 14 sites). Defined, measured and continually improved.\n\n## Procedure\n1. Detect and assess the incident's severity.\n2. Activate the response structure and escalate.\n3. Establish command, safety and communications.\n4. Coordinate recovery per the plans.\n5. Communicate with ${c.CUST} and stakeholders.\n6. Stand down and review after resolution.\n\n## Workflow\nDetect → assess → activate → command → recover → communicate → stand down → review.\n\n## RACI Matrix\n| Activity | Incident Manager | Team | Manager | Executive |\n|---|---|---|---|---|\n| Assess & declare | A | R | C | I |\n| Activate response | A | R | C | I |\n| Coordinate recovery | R | R | A | I |\n| Stakeholder comms | R | C | A | C |\n\n_R = Responsible, A = Accountable, C = Consulted, I = Informed._\n\n## Roles & Responsibilities\n- **Incident Manager** — owns this area; accountable for its outcomes.\n- **Team** — perform the work and record it.\n- **Manager** — accountable for performance.\n- **Executive / Program Manager** — owns the U.S. Department of Commerce relationship; approves resources.\n\n## Metrics & Targets\n| Metric | Target |\n|---|---|\n| Time to activate | Within target |\n| Post-incident reviews | 100% |\n\n## Required Records\nIncident logs, decisions, and post-incident reviews. Retained per the records procedure.\n\n## Review\nReviewed at least annually and on significant change. Revision 1.0."},"exercise":{"title":"Exercising & Testing Programme","clause":"8.5","content":"# Exercising & Testing Programme\n_ISO 22301:2019 — Clause 8.5 · Meridian Federal Solutions · U.S. Department of Commerce_\n\n## Policy\nIt is Meridian Federal Solutions's policy to validate the plans and build capability through a programme of exercises, in delivering the Enterprise IT Service Desk (EITSD) contract to U.S. Department of Commerce across ServiceNow (9,200 users, 14 sites). Defined, measured and continually improved.\n\n## Procedure\n1. Plan a programme of exercises across plan types.\n2. Run tabletop walkthroughs of the plans.\n3. Run technical recovery / failover tests.\n4. Test communications and notifications.\n5. Capture findings and lessons.\n6. Update plans and re-test as needed.\n\n## Workflow\nPlan programme → tabletop → technical test → comms test → findings → update.\n\n## Key Controls\n| Control | Standard |\n|---|---|\n| Plan walkthrough | Semi-annual |\n| Recovery / failover | Annual |\n| Communications test | Annual |\n| Findings | Tracked to closure |\n\n## Roles & Responsibilities\n- **Continuity Manager** — owns this area; accountable for its outcomes.\n- **Team** — perform the work and record it.\n- **Manager** — accountable for performance.\n- **Executive / Program Manager** — owns the U.S. Department of Commerce relationship; approves resources.\n\n## Metrics & Targets\n| Metric | Target |\n|---|---|\n| Exercises completed | Per programme |\n| Recovery within RTO in tests | 100% |\n\n## Required Records\nExercise plans, results, and improvement actions. Retained per the records procedure.\n\n## Review\nReviewed at least annually and on significant change. Revision 1.0."},"performance":{"title":"Performance Evaluation","clause":"9.1","content":"# Performance Evaluation\n_ISO 22301:2019 — Clause 9.1 · Meridian Federal Solutions_\n\nContinuity performance is measured via exercise results, RTO/RPO achievement in tests, plan currency, and post-incident reviews.\n\n| Metric | Target |\n|---|---|\n| Recovery within RTO (tests) | 100% |\n| Plan currency | Reviewed annually + on change |\n| Exercises completed | Per programme |\n| Post-incident reviews | 100% of activations |\n\nReported at management review."},"competency":{"title":"Competence & Awareness","clause":"7.2 / 7.3","content":"# Competence & Awareness\n_ISO 22301:2019 — Clauses 7.2 & 7.3 · Meridian Federal Solutions_\n\n| Role | Required competence | Evidence |\n|---|---|---|\n| Management representative | ISO 22301:2019 operation; auditing | Training / certification |\n| Process owners | Their process & controls | Role training records |\n| Delivery staff | ServiceNow; procedures | Onboarding + refresher |\n| Internal auditors | Auditing this standard | Auditor training |\n\nAwareness of the policy, objectives and their contribution is provided to all personnel at onboarding and annually. Records are retained."},"communication":{"title":"Communication Plan","clause":"7.4","content":"# Communication Plan\n_ISO 22301:2019 — Clause 7.4 · Meridian Federal Solutions_\n\n| Communication | Audience | Frequency | Channel | Owner |\n|---|---|---|---|---|\n| Performance report | U.S. Department of Commerce | Monthly | Report | Management rep |\n| Management review | Top management | Quarterly | Meeting + minutes | Program Manager |\n| Policy & changes | All staff | On change | Portal / briefing | Management rep |\n| Issues & escalations | Affected parties | As needed | ServiceNow / email | Process owners |\n| Objectives & results | All staff | Quarterly | Briefing | Management rep |"},"doccontrol":{"title":"Control of Documented Information","clause":"7.5","content":"# Control of Documented Information\n_ISO 22301:2019 — Clause 7.5 · Meridian Federal Solutions_\n\n## Procedure\n1. Create using approved templates.\n2. Review and approve before publication.\n3. Version as Major.Minor; record version, date, approver.\n4. Publish to the controlled repository with access control.\n5. Review at least annually and on significant change.\n6. Archive superseded versions.\n\n| Control | Rule |\n|---|---|\n| Naming | [Type] - [Title] - v[version] |\n| Storage | Controlled, access-restricted repository |\n| Change record | Version table in each document |\n| Retention | Per the records procedure |"},"records":{"title":"Records & Retention","clause":"7.5","content":"# Records & Retention\n_ISO 22301:2019 — Clause 7.5 · Meridian Federal Solutions_\n\n| Record | Owner | Storage | Retention |\n|---|---|---|---|\n| Objectives & KPI results | Management rep | Repository | Term + 1 year |\n| Internal audit reports | Internal auditor | Repository | Term + 1 year |\n| Management review minutes | Program Manager | Repository | Term + 1 year |\n| Nonconformity & actions | Management rep | Repository | Term + 1 year |\n| Training records | HR | HR system | Employment + per policy |\n| Operational records | Process owners | ServiceNow | Term + 1 year |\n\nRecords are protected against loss and unauthorised change; disposed of securely at end of retention."},"internalaudit":{"title":"Internal Audit Programme","clause":"9.2","content":"# Internal Audit Programme\n_ISO 22301:2019 — Clause 9.2 · Meridian Federal Solutions_\n\n## Procedure\n1. Plan an annual audit programme covering all clauses/controls.\n2. Assign impartial auditors (not auditing their own work).\n3. Conduct audits against the standard and this system.\n4. Record findings (conformities and nonconformities).\n5. Raise corrective actions and track to closure.\n6. Report results to management review.\n\n| Element | Standard |\n|---|---|\n| Frequency | At least annual; risk-based |\n| Auditor independence | Required |\n| Evidence | Sampled records, interviews |\n| Output | Audit report + actions |"},"mgmtreview":{"title":"Management Review","clause":"9.3","content":"# Management Review\n_ISO 22301:2019 — Clause 9.3 · Meridian Federal Solutions_\n\nTop management reviews the system at least quarterly. Inputs and outputs:\n\n| Inputs | Outputs |\n|---|---|\n| Status of prior actions | Decisions on improvement |\n| Objective & KPI performance | Resource decisions |\n| Audit results & nonconformities | Changes to the system |\n| Customer feedback / satisfaction | Updated objectives |\n| Risks & opportunities | Action assignments |\n\nMinutes are recorded and retained as evidence."},"improvement":{"title":"Nonconformity, Corrective Action & Improvement","clause":"10.1 / 10.2","content":"# Nonconformity, Corrective Action & Improvement\n_ISO 22301:2019 — Clauses 10.1 & 10.2 · Meridian Federal Solutions_\n\n## Procedure\n1. Identify and record the nonconformity.\n2. Contain and correct the immediate issue.\n3. Analyse the root cause.\n4. Implement corrective action to prevent recurrence.\n5. Verify effectiveness and close.\n6. Feed improvement opportunities into the register.\n\n| Field | Example |\n|---|---|\n| Source | Audit, complaint, incident, KPI miss |\n| Correction | Immediate fix |\n| Corrective action | Root-cause removal |\n| Verification | Effectiveness confirmed |\n\nContinual improvement is driven through the register, reviewed at management review."}},"audit":{"4":{"Audit Checklist":"## Internal Audit Checklist — Clause 4 (Context)\nMeridian Federal Solutions · Enterprise IT Service Desk (EITSD) contract · ISO 22301:2019\n\n| # | Requirement | Audit question | Evidence | Conforms? |\n|---|---|---|---|---|\n| 1 | 4.1 | Defined & documented? | Policy/procedure | ( ) |\n| 2 | 4.2 | Implemented? | Records | ( ) |\n| 3 | 4.3 | Monitored & reviewed? | Reports, minutes | ( ) |","Interview Questions":"## Interview Questions — Clause 4 (Context)\n- Who owns this and how is it kept current?\n- Walk me through how you meet clause 4.\n- What records evidence it, and where?\n- How is effectiveness measured and improved?","Objective Evidence":"## Objective Evidence — Clause 4 (Context)\nExpect controlling document(s), dated operational records, monitoring output, and evidence of closed actions — current, attributable, retained."},"5":{"Audit Checklist":"## Internal Audit Checklist — Clause 5 (Leadership)\nMeridian Federal Solutions · Enterprise IT Service Desk (EITSD) contract · ISO 22301:2019\n\n| # | Requirement | Audit question | Evidence | Conforms? |\n|---|---|---|---|---|\n| 1 | 5.1 | Defined & documented? | Policy/procedure | ( ) |\n| 2 | 5.2 | Implemented? | Records | ( ) |\n| 3 | 5.3 | Monitored & reviewed? | Reports, minutes | ( ) |","Interview Questions":"## Interview Questions — Clause 5 (Leadership)\n- Who owns this and how is it kept current?\n- Walk me through how you meet clause 5.\n- What records evidence it, and where?\n- How is effectiveness measured and improved?","Objective Evidence":"## Objective Evidence — Clause 5 (Leadership)\nExpect controlling document(s), dated operational records, monitoring output, and evidence of closed actions — current, attributable, retained."},"6":{"Audit Checklist":"## Internal Audit Checklist — Clause 6 (Planning)\nMeridian Federal Solutions · Enterprise IT Service Desk (EITSD) contract · ISO 22301:2019\n\n| # | Requirement | Audit question | Evidence | Conforms? |\n|---|---|---|---|---|\n| 1 | 6.1 | Defined & documented? | Policy/procedure | ( ) |\n| 2 | 6.2 | Implemented? | Records | ( ) |\n| 3 | 6.3 | Monitored & reviewed? | Reports, minutes | ( ) |","Interview Questions":"## Interview Questions — Clause 6 (Planning)\n- Who owns this and how is it kept current?\n- Walk me through how you meet clause 6.\n- What records evidence it, and where?\n- How is effectiveness measured and improved?","Objective Evidence":"## Objective Evidence — Clause 6 (Planning)\nExpect controlling document(s), dated operational records, monitoring output, and evidence of closed actions — current, attributable, retained."},"7":{"Audit Checklist":"## Internal Audit Checklist — Clause 7 (Support)\nMeridian Federal Solutions · Enterprise IT Service Desk (EITSD) contract · ISO 22301:2019\n\n| # | Requirement | Audit question | Evidence | Conforms? |\n|---|---|---|---|---|\n| 1 | 7.1 | Defined & documented? | Policy/procedure | ( ) |\n| 2 | 7.2 | Implemented? | Records | ( ) |\n| 3 | 7.3 | Monitored & reviewed? | Reports, minutes | ( ) |","Interview Questions":"## Interview Questions — Clause 7 (Support)\n- Who owns this and how is it kept current?\n- Walk me through how you meet clause 7.\n- What records evidence it, and where?\n- How is effectiveness measured and improved?","Objective Evidence":"## Objective Evidence — Clause 7 (Support)\nExpect controlling document(s), dated operational records, monitoring output, and evidence of closed actions — current, attributable, retained."},"8":{"Audit Checklist":"## Internal Audit Checklist — Clause 8 (Operation)\nMeridian Federal Solutions · Enterprise IT Service Desk (EITSD) contract · ISO 22301:2019\n\n| # | Requirement | Audit question | Evidence | Conforms? |\n|---|---|---|---|---|\n| 1 | 8.1 | Defined & documented? | Policy/procedure | ( ) |\n| 2 | 8.2 | Implemented? | Records | ( ) |\n| 3 | 8.3 | Monitored & reviewed? | Reports, minutes | ( ) |","Interview Questions":"## Interview Questions — Clause 8 (Operation)\n- Who owns this and how is it kept current?\n- Walk me through how you meet clause 8.\n- What records evidence it, and where?\n- How is effectiveness measured and improved?","Objective Evidence":"## Objective Evidence — Clause 8 (Operation)\nExpect controlling document(s), dated operational records, monitoring output, and evidence of closed actions — current, attributable, retained."},"9":{"Audit Checklist":"## Internal Audit Checklist — Clause 9 (Performance evaluation)\nMeridian Federal Solutions · Enterprise IT Service Desk (EITSD) contract · ISO 22301:2019\n\n| # | Requirement | Audit question | Evidence | Conforms? |\n|---|---|---|---|---|\n| 1 | 9.1 | Defined & documented? | Policy/procedure | ( ) |\n| 2 | 9.2 | Implemented? | Records | ( ) |\n| 3 | 9.3 | Monitored & reviewed? | Reports, minutes | ( ) |","Interview Questions":"## Interview Questions — Clause 9 (Performance evaluation)\n- Who owns this and how is it kept current?\n- Walk me through how you meet clause 9.\n- What records evidence it, and where?\n- How is effectiveness measured and improved?","Objective Evidence":"## Objective Evidence — Clause 9 (Performance evaluation)\nExpect controlling document(s), dated operational records, monitoring output, and evidence of closed actions — current, attributable, retained."},"10":{"Audit Checklist":"## Internal Audit Checklist — Clause 10 (Improvement)\nMeridian Federal Solutions · Enterprise IT Service Desk (EITSD) contract · ISO 22301:2019\n\n| # | Requirement | Audit question | Evidence | Conforms? |\n|---|---|---|---|---|\n| 1 | 10.1 | Defined & documented? | Policy/procedure | ( ) |\n| 2 | 10.2 | Implemented? | Records | ( ) |\n| 3 | 10.3 | Monitored & reviewed? | Reports, minutes | ( ) |","Interview Questions":"## Interview Questions — Clause 10 (Improvement)\n- Who owns this and how is it kept current?\n- Walk me through how you meet clause 10.\n- What records evidence it, and where?\n- How is effectiveness measured and improved?","Objective Evidence":"## Objective Evidence — Clause 10 (Improvement)\nExpect controlling document(s), dated operational records, monitoring output, and evidence of closed actions — current, attributable, retained."}},"docList":[{"key":"bcpolicy","name":"Business Continuity Policy","clause":"5.2"},{"key":"bcscope","name":"BCMS Scope","clause":"4.3"},{"key":"context","name":"Context & Interested Parties","clause":"4.1 / 4.2"},{"key":"leadership","name":"Leadership & Roles","clause":"5.1 / 5.3"},{"key":"objectives","name":"BC Objectives","clause":"6.2"},{"key":"bia","name":"Business Impact Analysis (BIA)","clause":"8.2.2"},{"key":"riskassessment","name":"BC Risk Assessment","clause":"8.2.3"},{"key":"strategy","name":"BC Strategy & Solutions","clause":"8.3"},{"key":"plans","name":"Business Continuity Plans","clause":"8.4"},{"key":"incident","name":"Incident Response Structure","clause":"8.4.2"},{"key":"exercise","name":"Exercising & Testing Programme","clause":"8.5"},{"key":"performance","name":"Performance Evaluation","clause":"9.1"},{"key":"competency","name":"Competence & Awareness","clause":"7.2 / 7.3"},{"key":"communication","name":"Communication Plan","clause":"7.4"},{"key":"doccontrol","name":"Control of Documented Information","clause":"7.5"},{"key":"records","name":"Records & Retention","clause":"7.5"},{"key":"internalaudit","name":"Internal Audit Programme","clause":"9.2"},{"key":"mgmtreview","name":"Management Review","clause":"9.3"},{"key":"improvement","name":"Nonconformity, Corrective Action & Improvement","clause":"10.1 / 10.2"}]};
const DEMO_42001 = {"generated":{"aipolicy":{"title":"AI Management Policy","clause":"5.2","content":"# AI Management Policy\n_ISO/IEC 42001:2023 — Clause 5.2 · Meridian Federal Solutions_\n\nMeridian Federal Solutions, LLC develops and uses AI systems responsibly in delivering the Enterprise IT Service Desk (EITSD) contract, under an AIMS conforming to ISO/IEC 42001:2023.\n\n- Assess AI risks and impacts on people and society.\n- Ensure human oversight, transparency and data governance.\n- Manage AI across its lifecycle.\n- Meet legal and ethical obligations; continually improve.\n\n| Version | Date | Approved by |\n|---|---|---|\n| 1.0 | (current) | Program Manager |"},"aimsscope":{"title":"AIMS Scope","clause":"4.3","content":"# Scope of the AIMS\n_ISO/IEC 42001:2023 — Clause 4.3 · Meridian Federal Solutions_\n\nCovers AI systems used or provided in delivering the Enterprise IT Service Desk (EITSD) contract to U.S. Department of Commerce (e.g. AI-assisted support and automation on ServiceNow). Governing standard: ISO/IEC 42001:2023, clauses 4–10 and Annex A."},"context":{"title":"Context & Interested Parties","clause":"4.1 / 4.2","content":"# Context & Interested Parties\n_ISO/IEC 42001:2023 — Clauses 4.1 & 4.2 · Meridian Federal Solutions_\n\n| Party | AI-related needs |\n|---|---|\n| U.S. Department of Commerce | Safe, fair, transparent AI use |\n| End users (~9,200) | Reliable AI assistance; recourse |\n| Regulators | Compliance with AI/data law |\n| Employees | Clear roles for AI oversight |\n| Society | Avoidance of harm and bias |\n\nAI-specific issues (bias, explainability, data quality, regulation) are reviewed at management review."},"roles":{"title":"AI Roles & Responsibilities","clause":"5.3","content":"# AI Roles & Responsibilities\n_ISO/IEC 42001:2023 — Clause 5.3 · Meridian Federal Solutions_\n\n| Role | Responsibility |\n|---|---|\n| Program Manager | Accountable for the AIMS |\n| AI Owner | Owns AI systems, risk and impact |\n| Security Lead | AI data protection |\n| Human reviewers | Oversee AI outputs |\n| All users | Use AI per policy; report issues |"},"objectives":{"title":"AI Objectives","clause":"6.2","content":"# AI Management Objectives\n_ISO/IEC 42001:2023 — Clause 6.2 · Meridian Federal Solutions_\n\n| Objective | Measure | Target |\n|---|---|---|\n| Human oversight of material AI actions | % reviewed | 100% |\n| AI accuracy monitored | Accuracy sampling | Per schedule |\n| Impact assessments current | AI systems assessed | 100% |\n\nReviewed at management review."},"riskassessment":{"title":"AI Risk Assessment","clause":"6.1","content":"# AI Risk Assessment\n_ISO/IEC 42001:2023 — Clause 6.1 · Meridian Federal Solutions_\n\n| ID | AI risk | Likelihood | Impact | Treatment | Owner |\n|---|---|---|---|---|---|\n| AI1 | Inaccurate AI output misleads users | Medium | Medium | Human review of AI suggestions | AI Owner |\n| AI2 | Bias in handling | Low | High | Testing; monitoring; oversight | AI Owner |\n| AI3 | Data leakage into AI | Medium | High | No sensitive data to AI; controls | Security Lead |\n| AI4 | Over-reliance on automation | Medium | Medium | Human-in-the-loop; audit | AI Owner |\n\nReviewed at least annually and on AI change."},"impact":{"title":"AI System Impact Assessment","clause":"6.1.4","content":"# AI System Impact Assessment\n_ISO/IEC 42001:2023 — Clause 6.1.4 · Meridian Federal Solutions_\n\nFor each AI system, assess impacts on individuals and society:\n\n| Dimension | Assessment |\n|---|---|\n| Affected individuals | End users receiving AI-assisted support |\n| Potential harms | Incorrect guidance; unfair treatment |\n| Likelihood & severity | Assessed and rated |\n| Mitigations | Human oversight; accuracy monitoring; opt-out |\n| Transparency | Users informed AI is assisting |\n| Recourse | Human escalation always available |\n| Residual impact | Accepted by the AI Owner |\n\nDocumented before deployment and reviewed on change."},"inventory":{"title":"AI System Inventory","clause":"Annex A","content":"# AI System Inventory\n_ISO/IEC 42001:2023 — Annex A · Meridian Federal Solutions_\n\n| AI system | Purpose | Data used | Risk level | Oversight | Owner |\n|---|---|---|---|---|---|\n| AI support assistant | Draft responses / triage | Ticket text (no sensitive data) | Limited | Human review | Service Delivery Manager |\n| Automation rules | Routing & classification | Metadata | Minimal | Audited | Platform Owner |\n\nEach AI system has an impact assessment and defined oversight."},"datagovernance":{"title":"Data Governance for AI","clause":"Annex A","content":"# Data Governance for AI\n_ISO/IEC 42001:2023 — Annex A · Meridian Federal Solutions · U.S. Department of Commerce_\n\n## Policy\nIt is Meridian Federal Solutions's policy to ensure AI is built and run on appropriate, well-governed data, in delivering the Enterprise IT Service Desk (EITSD) contract to U.S. Department of Commerce across ServiceNow (9,200 users, 14 sites). Defined, measured and continually improved.\n\n## Procedure\n1. Document data sources and permitted uses.\n2. Validate data quality for the AI purpose.\n3. Exclude sensitive data unless controlled.\n4. Record data provenance.\n5. Apply retention and disposal rules.\n6. Review data governance on AI change.\n\n## Workflow\nSource → permitted use → quality check → provenance → retention → review.\n\n## Key Controls\n| Control | Standard |\n|---|---|\n| Data sources | Documented; permitted use |\n| Data quality | Validated |\n| Sensitive data | Controlled / excluded |\n| Provenance | Recorded |\n\n## Roles & Responsibilities\n- **Security Lead** — owns this area; accountable for its outcomes.\n- **Team** — perform the work and record it.\n- **Manager** — accountable for performance.\n- **Executive / Program Manager** — owns the U.S. Department of Commerce relationship; approves resources.\n\n## Metrics & Targets\n| Metric | Target |\n|---|---|\n| AI systems with documented data lineage | 100% |\n| Sensitive-data exposure to AI | 0 |\n\n## Required Records\nData source register, quality checks, and provenance records. Retained per the records procedure.\n\n## Review\nReviewed at least annually and on significant change. Revision 1.0."},"soa":{"title":"Statement of Applicability (Annex A)","clause":"6.1.3","content":"# Statement of Applicability\n_ISO/IEC 42001:2023 — Annex A · Meridian Federal Solutions_\n\n| Control area | Applicable | Implementation |\n|---|---|---|\n| AI policy & governance | Yes | AI policy; roles; oversight |\n| AI risk & impact assessment | Yes | Risk + impact assessments |\n| Data for AI | Yes | Data governance |\n| AI lifecycle | Yes | Development/use controls |\n| Transparency & information | Yes | User disclosure |\n| Human oversight | Yes | Human-in-the-loop |\n| Third-party AI | Conditional | Supplier assurance where used |\n\nConfirmed by the risk and impact assessments."},"lifecycle":{"title":"AI System Lifecycle Controls","clause":"Annex A","content":"# AI System Lifecycle Management\n_ISO/IEC 42001:2023 — Annex A · Meridian Federal Solutions · U.S. Department of Commerce_\n\n## Policy\nIt is Meridian Federal Solutions's policy to manage AI systems responsibly across design, deployment, operation and retirement, in delivering the Enterprise IT Service Desk (EITSD) contract to U.S. Department of Commerce across ServiceNow (9,200 users, 14 sites). Defined, measured and continually improved.\n\n## Procedure\n1. Define intended use and requirements.\n2. Assess risk and impact before build/procurement.\n3. Validate performance and fairness before deployment.\n4. Deploy with human oversight and monitoring.\n5. Monitor accuracy and drift in operation.\n6. Retire or retrain when performance degrades.\n\n## Workflow\nDefine → assess → validate → deploy (oversight) → monitor → retrain/retire.\n\n## Key Controls\n| Control | Standard |\n|---|---|\n| Pre-deployment validation | Performance & fairness |\n| Oversight | Human-in-the-loop |\n| Monitoring | Accuracy & drift |\n| Retirement | On degradation |\n\n## Roles & Responsibilities\n- **AI Owner** — owns this area; accountable for its outcomes.\n- **Team** — perform the work and record it.\n- **Manager** — accountable for performance.\n- **Executive / Program Manager** — owns the U.S. Department of Commerce relationship; approves resources.\n\n## Metrics & Targets\n| Metric | Target |\n|---|---|\n| AI systems validated pre-deployment | 100% |\n| Monitored in operation | 100% |\n\n## Required Records\nValidation reports, monitoring logs, and change/retirement records. Retained per the records procedure.\n\n## Review\nReviewed at least annually and on significant change. Revision 1.0."},"oversight":{"title":"Human Oversight & Transparency","clause":"Annex A","content":"# Human Oversight & Transparency\n_ISO/IEC 42001:2023 — Annex A · Meridian Federal Solutions_\n\n- AI suggestions are reviewed by a human before acting where impact is material.\n- Users are informed when AI assists them.\n- A human escalation path is always available.\n- AI performance is monitored; humans can override or disable AI.\n\n| Control | Standard |\n|---|---|\n| Human review | Material actions |\n| Disclosure | Users informed of AI |\n| Override | Always available |\n| Kill switch | AI can be disabled |"},"competency":{"title":"Competence & Awareness","clause":"7.2 / 7.3","content":"# Competence & Awareness\n_ISO/IEC 42001:2023 — Clauses 7.2 & 7.3 · Meridian Federal Solutions_\n\n| Role | Required competence | Evidence |\n|---|---|---|\n| Management representative | ISO/IEC 42001:2023 operation; auditing | Training / certification |\n| Process owners | Their process & controls | Role training records |\n| Delivery staff | ServiceNow; procedures | Onboarding + refresher |\n| Internal auditors | Auditing this standard | Auditor training |\n\nAwareness of the policy, objectives and their contribution is provided to all personnel at onboarding and annually. Records are retained."},"communication":{"title":"Communication Plan","clause":"7.4","content":"# Communication Plan\n_ISO/IEC 42001:2023 — Clause 7.4 · Meridian Federal Solutions_\n\n| Communication | Audience | Frequency | Channel | Owner |\n|---|---|---|---|---|\n| Performance report | U.S. Department of Commerce | Monthly | Report | Management rep |\n| Management review | Top management | Quarterly | Meeting + minutes | Program Manager |\n| Policy & changes | All staff | On change | Portal / briefing | Management rep |\n| Issues & escalations | Affected parties | As needed | ServiceNow / email | Process owners |\n| Objectives & results | All staff | Quarterly | Briefing | Management rep |"},"doccontrol":{"title":"Control of Documented Information","clause":"7.5","content":"# Control of Documented Information\n_ISO/IEC 42001:2023 — Clause 7.5 · Meridian Federal Solutions_\n\n## Procedure\n1. Create using approved templates.\n2. Review and approve before publication.\n3. Version as Major.Minor; record version, date, approver.\n4. Publish to the controlled repository with access control.\n5. Review at least annually and on significant change.\n6. Archive superseded versions.\n\n| Control | Rule |\n|---|---|\n| Naming | [Type] - [Title] - v[version] |\n| Storage | Controlled, access-restricted repository |\n| Change record | Version table in each document |\n| Retention | Per the records procedure |"},"records":{"title":"Records & Retention","clause":"7.5","content":"# Records & Retention\n_ISO/IEC 42001:2023 — Clause 7.5 · Meridian Federal Solutions_\n\n| Record | Owner | Storage | Retention |\n|---|---|---|---|\n| Objectives & KPI results | Management rep | Repository | Term + 1 year |\n| Internal audit reports | Internal auditor | Repository | Term + 1 year |\n| Management review minutes | Program Manager | Repository | Term + 1 year |\n| Nonconformity & actions | Management rep | Repository | Term + 1 year |\n| Training records | HR | HR system | Employment + per policy |\n| Operational records | Process owners | ServiceNow | Term + 1 year |\n\nRecords are protected against loss and unauthorised change; disposed of securely at end of retention."},"internalaudit":{"title":"Internal Audit Programme","clause":"9.2","content":"# Internal Audit Programme\n_ISO/IEC 42001:2023 — Clause 9.2 · Meridian Federal Solutions_\n\n## Procedure\n1. Plan an annual audit programme covering all clauses/controls.\n2. Assign impartial auditors (not auditing their own work).\n3. Conduct audits against the standard and this system.\n4. Record findings (conformities and nonconformities).\n5. Raise corrective actions and track to closure.\n6. Report results to management review.\n\n| Element | Standard |\n|---|---|\n| Frequency | At least annual; risk-based |\n| Auditor independence | Required |\n| Evidence | Sampled records, interviews |\n| Output | Audit report + actions |"},"mgmtreview":{"title":"Management Review","clause":"9.3","content":"# Management Review\n_ISO/IEC 42001:2023 — Clause 9.3 · Meridian Federal Solutions_\n\nTop management reviews the system at least quarterly. Inputs and outputs:\n\n| Inputs | Outputs |\n|---|---|\n| Status of prior actions | Decisions on improvement |\n| Objective & KPI performance | Resource decisions |\n| Audit results & nonconformities | Changes to the system |\n| Customer feedback / satisfaction | Updated objectives |\n| Risks & opportunities | Action assignments |\n\nMinutes are recorded and retained as evidence."},"improvement":{"title":"Nonconformity, Corrective Action & Improvement","clause":"10.1 / 10.2","content":"# Nonconformity, Corrective Action & Improvement\n_ISO/IEC 42001:2023 — Clauses 10.1 & 10.2 · Meridian Federal Solutions_\n\n## Procedure\n1. Identify and record the nonconformity.\n2. Contain and correct the immediate issue.\n3. Analyse the root cause.\n4. Implement corrective action to prevent recurrence.\n5. Verify effectiveness and close.\n6. Feed improvement opportunities into the register.\n\n| Field | Example |\n|---|---|\n| Source | Audit, complaint, incident, KPI miss |\n| Correction | Immediate fix |\n| Corrective action | Root-cause removal |\n| Verification | Effectiveness confirmed |\n\nContinual improvement is driven through the register, reviewed at management review."}},"audit":{"4":{"Audit Checklist":"## Internal Audit Checklist — Clause 4 (Context)\nMeridian Federal Solutions · Enterprise IT Service Desk (EITSD) contract · ISO/IEC 42001:2023\n\n| # | Requirement | Audit question | Evidence | Conforms? |\n|---|---|---|---|---|\n| 1 | 4.1 | Defined & documented? | Policy/procedure | ( ) |\n| 2 | 4.2 | Implemented? | Records | ( ) |\n| 3 | 4.3 | Monitored & reviewed? | Reports, minutes | ( ) |","Interview Questions":"## Interview Questions — Clause 4 (Context)\n- Who owns this and how is it kept current?\n- Walk me through how you meet clause 4.\n- What records evidence it, and where?\n- How is effectiveness measured and improved?","Objective Evidence":"## Objective Evidence — Clause 4 (Context)\nExpect controlling document(s), dated operational records, monitoring output, and evidence of closed actions — current, attributable, retained."},"5":{"Audit Checklist":"## Internal Audit Checklist — Clause 5 (Leadership)\nMeridian Federal Solutions · Enterprise IT Service Desk (EITSD) contract · ISO/IEC 42001:2023\n\n| # | Requirement | Audit question | Evidence | Conforms? |\n|---|---|---|---|---|\n| 1 | 5.1 | Defined & documented? | Policy/procedure | ( ) |\n| 2 | 5.2 | Implemented? | Records | ( ) |\n| 3 | 5.3 | Monitored & reviewed? | Reports, minutes | ( ) |","Interview Questions":"## Interview Questions — Clause 5 (Leadership)\n- Who owns this and how is it kept current?\n- Walk me through how you meet clause 5.\n- What records evidence it, and where?\n- How is effectiveness measured and improved?","Objective Evidence":"## Objective Evidence — Clause 5 (Leadership)\nExpect controlling document(s), dated operational records, monitoring output, and evidence of closed actions — current, attributable, retained."},"6":{"Audit Checklist":"## Internal Audit Checklist — Clause 6 (Planning)\nMeridian Federal Solutions · Enterprise IT Service Desk (EITSD) contract · ISO/IEC 42001:2023\n\n| # | Requirement | Audit question | Evidence | Conforms? |\n|---|---|---|---|---|\n| 1 | 6.1 | Defined & documented? | Policy/procedure | ( ) |\n| 2 | 6.2 | Implemented? | Records | ( ) |\n| 3 | 6.3 | Monitored & reviewed? | Reports, minutes | ( ) |","Interview Questions":"## Interview Questions — Clause 6 (Planning)\n- Who owns this and how is it kept current?\n- Walk me through how you meet clause 6.\n- What records evidence it, and where?\n- How is effectiveness measured and improved?","Objective Evidence":"## Objective Evidence — Clause 6 (Planning)\nExpect controlling document(s), dated operational records, monitoring output, and evidence of closed actions — current, attributable, retained."},"7":{"Audit Checklist":"## Internal Audit Checklist — Clause 7 (Support)\nMeridian Federal Solutions · Enterprise IT Service Desk (EITSD) contract · ISO/IEC 42001:2023\n\n| # | Requirement | Audit question | Evidence | Conforms? |\n|---|---|---|---|---|\n| 1 | 7.1 | Defined & documented? | Policy/procedure | ( ) |\n| 2 | 7.2 | Implemented? | Records | ( ) |\n| 3 | 7.3 | Monitored & reviewed? | Reports, minutes | ( ) |","Interview Questions":"## Interview Questions — Clause 7 (Support)\n- Who owns this and how is it kept current?\n- Walk me through how you meet clause 7.\n- What records evidence it, and where?\n- How is effectiveness measured and improved?","Objective Evidence":"## Objective Evidence — Clause 7 (Support)\nExpect controlling document(s), dated operational records, monitoring output, and evidence of closed actions — current, attributable, retained."},"8":{"Audit Checklist":"## Internal Audit Checklist — Clause 8 (Operation)\nMeridian Federal Solutions · Enterprise IT Service Desk (EITSD) contract · ISO/IEC 42001:2023\n\n| # | Requirement | Audit question | Evidence | Conforms? |\n|---|---|---|---|---|\n| 1 | 8.1 | Defined & documented? | Policy/procedure | ( ) |\n| 2 | 8.2 | Implemented? | Records | ( ) |\n| 3 | 8.3 | Monitored & reviewed? | Reports, minutes | ( ) |","Interview Questions":"## Interview Questions — Clause 8 (Operation)\n- Who owns this and how is it kept current?\n- Walk me through how you meet clause 8.\n- What records evidence it, and where?\n- How is effectiveness measured and improved?","Objective Evidence":"## Objective Evidence — Clause 8 (Operation)\nExpect controlling document(s), dated operational records, monitoring output, and evidence of closed actions — current, attributable, retained."},"9":{"Audit Checklist":"## Internal Audit Checklist — Clause 9 (Performance evaluation)\nMeridian Federal Solutions · Enterprise IT Service Desk (EITSD) contract · ISO/IEC 42001:2023\n\n| # | Requirement | Audit question | Evidence | Conforms? |\n|---|---|---|---|---|\n| 1 | 9.1 | Defined & documented? | Policy/procedure | ( ) |\n| 2 | 9.2 | Implemented? | Records | ( ) |\n| 3 | 9.3 | Monitored & reviewed? | Reports, minutes | ( ) |","Interview Questions":"## Interview Questions — Clause 9 (Performance evaluation)\n- Who owns this and how is it kept current?\n- Walk me through how you meet clause 9.\n- What records evidence it, and where?\n- How is effectiveness measured and improved?","Objective Evidence":"## Objective Evidence — Clause 9 (Performance evaluation)\nExpect controlling document(s), dated operational records, monitoring output, and evidence of closed actions — current, attributable, retained."},"10":{"Audit Checklist":"## Internal Audit Checklist — Clause 10 (Improvement)\nMeridian Federal Solutions · Enterprise IT Service Desk (EITSD) contract · ISO/IEC 42001:2023\n\n| # | Requirement | Audit question | Evidence | Conforms? |\n|---|---|---|---|---|\n| 1 | 10.1 | Defined & documented? | Policy/procedure | ( ) |\n| 2 | 10.2 | Implemented? | Records | ( ) |\n| 3 | 10.3 | Monitored & reviewed? | Reports, minutes | ( ) |","Interview Questions":"## Interview Questions — Clause 10 (Improvement)\n- Who owns this and how is it kept current?\n- Walk me through how you meet clause 10.\n- What records evidence it, and where?\n- How is effectiveness measured and improved?","Objective Evidence":"## Objective Evidence — Clause 10 (Improvement)\nExpect controlling document(s), dated operational records, monitoring output, and evidence of closed actions — current, attributable, retained."}},"docList":[{"key":"aipolicy","name":"AI Management Policy","clause":"5.2"},{"key":"aimsscope","name":"AIMS Scope","clause":"4.3"},{"key":"context","name":"Context & Interested Parties","clause":"4.1 / 4.2"},{"key":"roles","name":"AI Roles & Responsibilities","clause":"5.3"},{"key":"objectives","name":"AI Objectives","clause":"6.2"},{"key":"riskassessment","name":"AI Risk Assessment","clause":"6.1"},{"key":"impact","name":"AI System Impact Assessment","clause":"6.1.4"},{"key":"inventory","name":"AI System Inventory","clause":"Annex A"},{"key":"datagovernance","name":"Data Governance for AI","clause":"Annex A"},{"key":"soa","name":"Statement of Applicability (Annex A)","clause":"6.1.3"},{"key":"lifecycle","name":"AI System Lifecycle Controls","clause":"Annex A"},{"key":"oversight","name":"Human Oversight & Transparency","clause":"Annex A"},{"key":"competency","name":"Competence & Awareness","clause":"7.2 / 7.3"},{"key":"communication","name":"Communication Plan","clause":"7.4"},{"key":"doccontrol","name":"Control of Documented Information","clause":"7.5"},{"key":"records","name":"Records & Retention","clause":"7.5"},{"key":"internalaudit","name":"Internal Audit Programme","clause":"9.2"},{"key":"mgmtreview","name":"Management Review","clause":"9.3"},{"key":"improvement","name":"Nonconformity, Corrective Action & Improvement","clause":"10.1 / 10.2"}]};
const DEMO_SOC2 = {"generated":{"description":{"title":"System Description","clause":"DC","content":"# System Description\n_SOC 2 (AICPA TSC) · Meridian Federal Solutions_\n\n## Services\nMeridian Federal Solutions, LLC provides the Enterprise IT Service Desk (EITSD) contract to U.S. Department of Commerce, on ServiceNow, supporting ~9,200 users across 14 sites.\n\n## System components\n| Component | Examples |\n|---|---|\n| Infrastructure | Cloud hosting, networks |\n| Software | ServiceNow, endpoint tools |\n| People | Service desk, security, management |\n| Procedures | Documented policies & processes |\n| Data | Customer and operational data |\n\n## Boundaries\nPeople, processes and technology used to deliver the service. Subservice organizations (cloud/hosting) are covered via the carve-out method and vendor management.\n\n## Trust Services Categories in scope\nSecurity (Common Criteria), Availability, and Confidentiality."},"controlmatrix":{"title":"Control Matrix (Common Criteria)","clause":"CC1–CC9","content":"# Control Matrix — Common Criteria\n_SOC 2 (AICPA TSC) · Meridian Federal Solutions_\n\n| Ref | Criterion | Control |\n|---|---|---|\n| CC1 | Control environment | Governance, policies, org structure |\n| CC2 | Communication & information | Security policy communicated |\n| CC3 | Risk assessment | Annual risk assessment |\n| CC4 | Monitoring | Control monitoring & internal audit |\n| CC5 | Control activities | Documented procedures |\n| CC6 | Logical & physical access | RBAC, MFA, access reviews, facility controls |\n| CC7 | System operations | Monitoring, incident response |\n| CC8 | Change management | Change control process |\n| CC9 | Risk mitigation | Vendor management, insurance |\n\nEach control has an owner and evidence, tested over the review period."},"policies":{"title":"Information Security Policies","clause":"CC1–CC2","content":"# Information Security Policies\n_SOC 2 (AICPA TSC) · CC1–CC2 · Meridian Federal Solutions_\n\nA documented policy set covers acceptable use, access control, data classification, incident response, change management, vendor management and business continuity — approved, communicated, and reviewed at least annually.\n\n| Policy | Owner | Review |\n|---|---|---|\n| Information security | Security Lead | Annual |\n| Access control | Security Lead | Annual |\n| Incident response | Security Lead | Annual |\n| Change management | Ops Lead | Annual |\n| Vendor management | Security Lead | Annual |"},"riskassessment":{"title":"Risk Assessment","clause":"CC3","content":"# Risk Assessment\n_SOC 2 (AICPA TSC) · CC3 · Meridian Federal Solutions_\n\n| ID | Risk | Likelihood | Impact | Control | Owner |\n|---|---|---|---|---|---|\n| S1 | Unauthorized access | Medium | High | CC6 access controls | Security Lead |\n| S2 | Outage | Low | High | A1 availability controls | Ops Lead |\n| S3 | Data disclosure | Low | High | C1 confidentiality controls | Security Lead |\n| S4 | Vendor weakness | Medium | Medium | CC9 vendor management | Security Lead |\n| S5 | Change failure | Medium | Medium | CC8 change management | Ops Lead |\n\nPerformed at least annually and on significant change."},"monitoring":{"title":"Monitoring of Controls","clause":"CC4","content":"# Monitoring of Controls\n_SOC 2 (AICPA TSC) — CC4 · Meridian Federal Solutions · U.S. Department of Commerce_\n\n## Policy\nIt is Meridian Federal Solutions's policy to monitor that controls are present and operating effectively, in delivering the Enterprise IT Service Desk (EITSD) contract to U.S. Department of Commerce across ServiceNow (9,200 users, 14 sites). Defined, measured and continually improved.\n\n## Procedure\n1. Define control monitoring activities.\n2. Collect evidence of control operation.\n3. Perform internal control reviews / audits.\n4. Track deficiencies to remediation.\n5. Report control status to management.\n6. Improve controls based on findings.\n\n## Workflow\nDefine monitoring → collect evidence → review → remediate → report.\n\n## Key Controls\n| Control | Standard |\n|---|---|\n| Continuous monitoring | Security & availability |\n| Internal review | Periodic |\n| Deficiency tracking | To closure |\n| Reporting | To management |\n\n## Roles & Responsibilities\n- **Security Lead** — owns this area; accountable for its outcomes.\n- **Team** — perform the work and record it.\n- **Manager** — accountable for performance.\n- **Executive / Program Manager** — owns the U.S. Department of Commerce relationship; approves resources.\n\n## Metrics & Targets\n| Metric | Target |\n|---|---|\n| Controls monitored | 100% |\n| Deficiencies remediated on time | ≥ 90% |\n\n## Required Records\nMonitoring results, review reports, and remediation tracking. Retained per the records procedure.\n\n## Review\nReviewed at least annually and on significant change. Revision 1.0."},"access":{"title":"Logical & Physical Access","clause":"CC6","content":"# Logical & Physical Access\n_SOC 2 (AICPA TSC) — CC6 · Meridian Federal Solutions · U.S. Department of Commerce_\n\n## Policy\nIt is Meridian Federal Solutions's policy to restrict logical and physical access to authorized users and protect information assets, in delivering the Enterprise IT Service Desk (EITSD) contract to U.S. Department of Commerce across ServiceNow (9,200 users, 14 sites). Defined, measured and continually improved.\n\n## Procedure\n1. Provision access via RBAC and least privilege (CC6.1).\n2. Require MFA for remote and privileged access.\n3. Review access rights periodically (CC6.2).\n4. Deprovision on termination (CC6.3).\n5. Control physical access to facilities (CC6.4).\n6. Encrypt data in transit and at rest (CC6.7).\n\n## Workflow\nProvision (RBAC+MFA) → review → deprovision → physical controls → encryption.\n\n## Key Controls\n| Control | Standard |\n|---|---|\n| Access provisioning | RBAC; least privilege |\n| Authentication | MFA |\n| Access reviews | Quarterly |\n| Encryption | In transit & at rest |\n\n## Roles & Responsibilities\n- **Security Lead** — owns this area; accountable for its outcomes.\n- **Team** — perform the work and record it.\n- **Manager** — accountable for performance.\n- **Executive / Program Manager** — owns the U.S. Department of Commerce relationship; approves resources.\n\n## Metrics & Targets\n| Metric | Target |\n|---|---|\n| Access reviews completed | 100% quarterly |\n| MFA coverage (remote/privileged) | 100% |\n\n## Required Records\nAccess records, review logs, and encryption configuration. Retained per the records procedure.\n\n## Review\nReviewed at least annually and on significant change. Revision 1.0."},"operations":{"title":"System Operations & Incident Response","clause":"CC7","content":"# System Operations & Incident Response\n_SOC 2 (AICPA TSC) — CC7 · Meridian Federal Solutions · U.S. Department of Commerce_\n\n## Policy\nIt is Meridian Federal Solutions's policy to detect, respond to, and recover from security and availability incidents, in delivering the Enterprise IT Service Desk (EITSD) contract to U.S. Department of Commerce across ServiceNow (9,200 users, 14 sites). Defined, measured and continually improved.\n\n## Procedure\n1. Monitor systems for anomalies and threats (CC7.1–7.2).\n2. Detect and classify incidents.\n3. Contain, eradicate and recover (CC7.3–7.4).\n4. Notify affected parties (CC7.5).\n5. Preserve evidence and review post-incident.\n6. Improve controls from lessons learned.\n\n## Workflow\nMonitor → detect → contain → recover → notify → review.\n\n## Key Controls\n| Control | Standard |\n|---|---|\n| Monitoring | Security & availability |\n| Incident handling | Detect→respond→recover |\n| Communication | Affected parties |\n| Post-incident review | For majors |\n\n## Roles & Responsibilities\n- **Security Lead** — owns this area; accountable for its outcomes.\n- **Team** — perform the work and record it.\n- **Manager** — accountable for performance.\n- **Executive / Program Manager** — owns the U.S. Department of Commerce relationship; approves resources.\n\n## Metrics & Targets\n| Metric | Target |\n|---|---|\n| Incidents reviewed | 100% |\n| Mean time to respond | Within target |\n\n## Required Records\nMonitoring config, incident tickets, and post-incident reviews. Retained per the records procedure.\n\n## Review\nReviewed at least annually and on significant change. Revision 1.0."},"change":{"title":"Change Management","clause":"CC8","content":"# Change Management\n_SOC 2 (AICPA TSC) — CC8 · Meridian Federal Solutions · U.S. Department of Commerce_\n\n## Policy\nIt is Meridian Federal Solutions's policy to authorize, test and control changes to infrastructure and software, in delivering the Enterprise IT Service Desk (EITSD) contract to U.S. Department of Commerce across ServiceNow (9,200 users, 14 sites). Defined, measured and continually improved.\n\n## Procedure\n1. Record and classify each change.\n2. Assess risk and test before production.\n3. Obtain approval.\n4. Separate development and production.\n5. Deploy with back-out readiness.\n6. Review changes for success.\n\n## Workflow\nRequest → test → approve → deploy (dev/prod separation) → verify.\n\n## Key Controls\n| Control | Standard |\n|---|---|\n| Change request | Documented |\n| Testing & approval | Before production |\n| Segregation | Dev/prod separation |\n| Back-out | Defined |\n\n## Roles & Responsibilities\n- **Ops Lead** — owns this area; accountable for its outcomes.\n- **Team** — perform the work and record it.\n- **Manager** — accountable for performance.\n- **Executive / Program Manager** — owns the U.S. Department of Commerce relationship; approves resources.\n\n## Metrics & Targets\n| Metric | Target |\n|---|---|\n| Changes with approval & test | 100% |\n| Change-related incidents | Downward trend |\n\n## Required Records\nChange tickets, approvals, and test records. Retained per the records procedure.\n\n## Review\nReviewed at least annually and on significant change. Revision 1.0."},"vendor":{"title":"Vendor / Risk Mitigation","clause":"CC9","content":"# Vendor Management & Risk Mitigation\n_SOC 2 (AICPA TSC) — CC9 · Meridian Federal Solutions · U.S. Department of Commerce_\n\n## Policy\nIt is Meridian Federal Solutions's policy to manage vendor risk and other risk-mitigation measures, in delivering the Enterprise IT Service Desk (EITSD) contract to U.S. Department of Commerce across ServiceNow (9,200 users, 14 sites). Defined, measured and continually improved.\n\n## Procedure\n1. Assess vendors before engagement.\n2. Review vendor assurance (SOC 2 / ISO reports).\n3. Include security terms in contracts.\n4. Monitor vendor performance and risk.\n5. Maintain risk-transfer measures (e.g. insurance).\n6. Offboard vendors securely.\n\n## Workflow\nAssess → assurance review → contract → monitor → offboard.\n\n## Key Controls\n| Control | Standard |\n|---|---|\n| Vendor assessment | Before engagement |\n| Assurance review | SOC 2 / ISO reports |\n| Contracts | Security terms |\n| Monitoring | Ongoing |\n\n## Roles & Responsibilities\n- **Security Lead** — owns this area; accountable for its outcomes.\n- **Team** — perform the work and record it.\n- **Manager** — accountable for performance.\n- **Executive / Program Manager** — owns the U.S. Department of Commerce relationship; approves resources.\n\n## Metrics & Targets\n| Metric | Target |\n|---|---|\n| Critical vendors assessed | 100% |\n| Assurance reports reviewed | Annual |\n\n## Required Records\nVendor register, assurance reviews, and contracts. Retained per the records procedure.\n\n## Review\nReviewed at least annually and on significant change. Revision 1.0."},"availability":{"title":"Availability","clause":"A1","content":"# Availability\n_SOC 2 (AICPA TSC) · A1 · Meridian Federal Solutions_\n\n| Control | Standard |\n|---|---|\n| Capacity | Monitored (A1.1) |\n| Backup & recovery | Scheduled; tested (A1.2) |\n| BC/DR | Plans tested annually (A1.3) |\n| Monitoring | Availability tracked vs SLA |\n\nEvidence: uptime reports, backup/restore logs, DR test results."},"confidentiality":{"title":"Confidentiality","clause":"C1","content":"# Confidentiality\n_SOC 2 (AICPA TSC) · C1 · Meridian Federal Solutions_\n\n| Control | Standard |\n|---|---|\n| Data classification | Confidential data identified (C1.1) |\n| Handling | Access-controlled; encrypted |\n| Retention & disposal | Per policy (C1.2) |\n| DLP | Egress controls |\n\nEvidence: classification, encryption config, disposal records."}},"audit":{"CC":{"Audit Checklist":"## SOC 2 Test Procedures — Common Criteria (Security)\nMeridian Federal Solutions · Enterprise IT Service Desk (EITSD) contract\n\n| # | Criterion | Test | Evidence | Result |\n|---|---|---|---|---|\n| 1 | Design | Is the control designed to meet the criterion? | Policy/config | ( ) |\n| 2 | Operating | Did it operate over the period? | Samples over period | ( ) |\n| 3 | Exceptions | Any exceptions & remediation? | Exception log | ( ) |","Interview Questions":"## Interview Questions — Common Criteria (Security)\n- Who owns this control and how is it evidenced?\n- Show the control operating over the review period.\n- Where are exceptions logged and remediated?","Objective Evidence":"## Objective Evidence — Common Criteria (Security)\nExpect policy/config, samples demonstrating operation across the period, and an exception log with remediation — sufficient for a Type II opinion."},"A":{"Audit Checklist":"## SOC 2 Test Procedures — Availability\nMeridian Federal Solutions · Enterprise IT Service Desk (EITSD) contract\n\n| # | Criterion | Test | Evidence | Result |\n|---|---|---|---|---|\n| 1 | Design | Is the control designed to meet the criterion? | Policy/config | ( ) |\n| 2 | Operating | Did it operate over the period? | Samples over period | ( ) |\n| 3 | Exceptions | Any exceptions & remediation? | Exception log | ( ) |","Interview Questions":"## Interview Questions — Availability\n- Who owns this control and how is it evidenced?\n- Show the control operating over the review period.\n- Where are exceptions logged and remediated?","Objective Evidence":"## Objective Evidence — Availability\nExpect policy/config, samples demonstrating operation across the period, and an exception log with remediation — sufficient for a Type II opinion."},"C":{"Audit Checklist":"## SOC 2 Test Procedures — Confidentiality\nMeridian Federal Solutions · Enterprise IT Service Desk (EITSD) contract\n\n| # | Criterion | Test | Evidence | Result |\n|---|---|---|---|---|\n| 1 | Design | Is the control designed to meet the criterion? | Policy/config | ( ) |\n| 2 | Operating | Did it operate over the period? | Samples over period | ( ) |\n| 3 | Exceptions | Any exceptions & remediation? | Exception log | ( ) |","Interview Questions":"## Interview Questions — Confidentiality\n- Who owns this control and how is it evidenced?\n- Show the control operating over the review period.\n- Where are exceptions logged and remediated?","Objective Evidence":"## Objective Evidence — Confidentiality\nExpect policy/config, samples demonstrating operation across the period, and an exception log with remediation — sufficient for a Type II opinion."}},"docList":[{"key":"description","name":"System Description","clause":"DC"},{"key":"controlmatrix","name":"Control Matrix (Common Criteria)","clause":"CC1–CC9"},{"key":"policies","name":"Information Security Policies","clause":"CC1–CC2"},{"key":"riskassessment","name":"Risk Assessment","clause":"CC3"},{"key":"monitoring","name":"Monitoring of Controls","clause":"CC4"},{"key":"access","name":"Logical & Physical Access","clause":"CC6"},{"key":"operations","name":"System Operations & Incident Response","clause":"CC7"},{"key":"change","name":"Change Management","clause":"CC8"},{"key":"vendor","name":"Vendor / Risk Mitigation","clause":"CC9"},{"key":"availability","name":"Availability","clause":"A1"},{"key":"confidentiality","name":"Confidentiality","clause":"C1"}]};

const FRAMEWORKS = {
  iso20000: { id:"iso20000", short:"ISO 20000", name:"ISO/IEC 20000-1", tag:"IT Service Management" },
  iso27001: { id:"iso27001", short:"ISO 27001", name:"ISO/IEC 27001:2022", tag:"Information Security (ISMS)" },
  cmmc: { id:"cmmc", short:"CMMC / 800-171", name:"CMMC Level 2 / NIST SP 800-171", tag:"Federal CUI protection" },
  iso9001: { id:"iso9001", short:"ISO 9001", name:"ISO 9001:2015", tag:"Quality Management" },
  iso22301: { id:"iso22301", short:"ISO 22301", name:"ISO 22301:2019", tag:"Business Continuity" },
  iso42001: { id:"iso42001", short:"ISO 42001", name:"ISO/IEC 42001:2023", tag:"AI Management" },
  soc2: { id:"soc2", short:"SOC 2", name:"SOC 2 (Trust Services)", tag:"Security attestation" },
};

/* Live-generation blueprint per framework: which documents to write from an
   uploaded contract. docList mirrors each framework's demo so the workspace
   renders the same set, generated fresh & tailored. */
const FW_SPECS = {
  iso20000: { standard: FRAMEWORKS.iso20000.name, docList: [...CORE_DOCS.map(d => ({ key: d.key, name: d.name, clause: d.clause })), ...PROCESSES.map(pr => ({ key: "proc_" + pr.key, name: pr.name, clause: pr.clause }))] },
  iso27001: { standard: FRAMEWORKS.iso27001.name, docList: DEMO_27K.docList },
  cmmc: { standard: FRAMEWORKS.cmmc.name, docList: DEMO_CMMC.docList },
  iso9001: { standard: FRAMEWORKS.iso9001.name, docList: DEMO_9001.docList },
  iso22301: { standard: FRAMEWORKS.iso22301.name, docList: DEMO_22301.docList },
  iso42001: { standard: FRAMEWORKS.iso42001.name, docList: DEMO_42001.docList },
  soc2: { standard: FRAMEWORKS.soc2.name, docList: DEMO_SOC2.docList },
};

function makeDemo() {
  const now = Date.now();
  const rm = DEFAULT_ROADMAP();
  rm[0].tasks.forEach(t => t.done = true);          // Phase 1 complete
  [0, 2].forEach(i => rm[1].tasks[i].done = true);   // Phase 2 partial
  rm[3].tasks[0].done = true;                        // Phase 4 started
  const demoDone = { incident: 6, request: 4, problem: 2, change: 1, config: 0, asset: 0, knowledge: 1, capacity: 3, availability: 2, continuity: 0, slm: 6, supplier: 0, release: 0, monitoring: 6, improvement: 2 };
  const tasks = {}, gaps = {};
  PROCESSES.forEach(pr => {
    const tpl = TASKS_TEMPLATE[pr.key] || [];
    const n = demoDone[pr.key] || 0;
    tasks[pr.key] = tpl.map((t, i) => ({ t, done: i < n }));
    gaps[pr.key] = "implemented";
  });
  const actions = ACTIONS.map((t, i) => ({ t, done: i < 4 }));
  return {
    created: now,
    meta: { companyName: "Meridian Federal Solutions, LLC", contractName: "Enterprise IT Service Desk (EITSD)",
      customerName: "U.S. Department of Commerce", itsmPlatform: "ServiceNow", numUsers: "9,200",
      numTechs: "48", helpDeskHours: "Tier 1 24x7x365; Tier 2 0600-2000 ET", numSites: "14",
      techStack: "Windows 11, Microsoft 365, ServiceNow, SCCM/Intune", cloudProviders: "M365 GCC High, AWS GovCloud, Azure Government",
      vendors: "OEM hardware suppliers; software resellers; niche subcontractors" },
    docs: [
      { id: "d1", type: "PWS", name: "Sample_PWS_Enterprise_Help_Desk.md", text: DEMO_PWS_TEXT },
      { id: "d2", type: "SOW", name: "Sample_SLA_Matrix.csv", text: DEMO_SLA_CSV },
      { id: "d3", type: "Existing Procedure", name: "Existing_Incident_Response_SOP_DRAFT.md", text: DEMO_SOP_TEXT },
    ],
    analysis: { ...DEMO_ANALYSIS, ts: now },
    gaps,
    tasks,
    actions,
    generated: (() => {
      const g = {};
      Object.entries(DEMO_FULL.generated).forEach(([k, v]) => { g[k] = { ...v, ts: now }; });
      g.smpolicy = { title: "Service Management Policy", clause: "5.2", content: DEMO_SMPOLICY, ts: now };
      g.scope = { title: "Scope Statement", clause: "4.3", content: DEMO_SCOPE, ts: now };
      g.objectives = { title: "Service Management Objectives", clause: "6.2", content: DEMO_OBJECTIVES, ts: now };
      g.riskreg = { title: "Risk Register", clause: "6.1", content: DEMO_RISKREG, ts: now };
      g.proc_incident = { title: "Incident Management — Full Pack", clause: "8.6.1", content: DEMO_INCIDENT, ts: now };
      g.proc_capacity = { title: "Capacity Management — Full Pack", clause: "8.4.3", content: DEMO_CAPACITY, ts: now };
      return g;
    })(),
    audit: JSON.parse(JSON.stringify(DEMO_FULL.audit)),
    framework: "iso20000",
    docList: [...CORE_DOCS.map(d => ({ key: d.key, name: d.name, clause: d.clause })), ...PROCESSES.map(pr => ({ key: "proc_" + pr.key, name: pr.name, clause: pr.clause }))],
    findings: [
      { id: "f1", clause: "7", severity: "Minor", desc: "Competency matrix drafted but not yet approved", status: "open" },
      { id: "f2", clause: "8", severity: "Major", desc: "No known-error database in place for Problem Management", status: "open" },
      { id: "f3", clause: "9", severity: "Minor", desc: "First internal audit scheduled and completed", status: "closed" },
    ],
    roadmap: rm,
    chat: [],
  };
}

function makeDemo27k() {
  const now = Date.now();
  const base = makeDemo();
  const g = {};
  Object.entries(DEMO_27K.generated).forEach(([k, v]) => { g[k] = { ...v, ts: now }; });
  return {
    ...base,
    framework: "iso27001",
    generated: g,
    audit: JSON.parse(JSON.stringify(DEMO_27K.audit)),
    docList: DEMO_27K.docList,
    analysis: { ...base.analysis, ts: now,
      compliance: ["ISO/IEC 27001:2022", "NIST SP 800-53", "FISMA"],
      deliverables: ["Information Security Policy", "Risk assessment & treatment", "Statement of Applicability", "Access control", "Security incident response", "Business continuity"],
      expectations: ["Protect Government data", "Breach notification", "Independent certification"],
      clauseMap: [{ clause: "6.1.2", requirement: "Risk assessment" }, { clause: "6.1.3", requirement: "Risk treatment + SoA" }, { clause: "A.5.15", requirement: "Access control" }, { clause: "A.8.24", requirement: "Cryptography" }] },
  };
}

function makeDemoCmmc() {
  const now = Date.now();
  const base = makeDemo();
  const g = {};
  Object.entries(DEMO_CMMC.generated).forEach(([k, v]) => { g[k] = { ...v, ts: now }; });
  return {
    ...base,
    framework: "cmmc",
    generated: g,
    audit: JSON.parse(JSON.stringify(DEMO_CMMC.audit)),
    docList: DEMO_CMMC.docList,
    analysis: { ...base.analysis, ts: now,
      compliance: ["CMMC Level 2", "NIST SP 800-171", "FISMA", "DFARS 252.204-7012"],
      deliverables: ["System Security Plan (SSP)", "POA&M", "CUI scoping", "Access control", "Incident response", "Configuration baselines"],
      expectations: ["Protect CUI", "Meet 110 practices", "Pass CMMC assessment"],
      clauseMap: [{ clause: "3.1", requirement: "Access control" }, { clause: "3.5.3", requirement: "Multifactor authentication" }, { clause: "3.12.4", requirement: "System Security Plan" }, { clause: "3.13.11", requirement: "FIPS cryptography" }] },
  };
}

function makeDemoFW(fw, data) {
  const now = Date.now();
  const base = makeDemo();
  const g = {};
  Object.entries(data.generated).forEach(([k, v]) => { g[k] = { ...v, ts: now }; });
  const compliance = {
    iso9001: ["ISO 9001:2015"], iso22301: ["ISO 22301:2019"], iso42001: ["ISO/IEC 42001:2023"], soc2: ["SOC 2", "AICPA TSC"],
  }[fw] || [];
  return { ...base, framework: fw, generated: g, audit: JSON.parse(JSON.stringify(data.audit)), docList: data.docList,
    analysis: { ...base.analysis, ts: now, compliance, deliverables: data.docList.slice(0, 6).map(d => d.name), clauseMap: [] } };
}

/* ============================================================================
   AI ENGINE — real, connectable. Works in the Claude.ai preview (keyless),
   with your own Anthropic/OpenAI key (deploy anywhere), or via your own backend.
   ========================================================================== */
let aiSettings = {
  provider: "backend",       // backend (Netlify function) | anthropic | openai | auto
  anthropicKey: "", openaiKey: "",
  backendUrl: "/.netlify/functions/ai",
  model: "", maxTokens: 4000,
};
const AI_KEY = "iso20k:ai:v1";
function getAiSettings() { return { ...aiSettings }; }
async function loadAiSettings() { try { const r = await window.storage.get(AI_KEY); if (r) aiSettings = { ...aiSettings, ...JSON.parse(r.value) }; } catch (e) {} return getAiSettings(); }
async function saveAiSettings(s) { aiSettings = { ...aiSettings, ...s }; try { await window.storage.set(AI_KEY, JSON.stringify(aiSettings)); } catch (e) {} return getAiSettings(); }
function aiProviderLabel() {
  return { auto: "Preview (built-in)", anthropic: "Anthropic key", openai: "OpenAI key", backend: "Your backend" }[aiSettings.provider] || aiSettings.provider;
}
function aiIsConfigured() {
  const p = aiSettings.provider;
  if (p === "anthropic") return !!aiSettings.anthropicKey;
  if (p === "openai") return !!aiSettings.openaiKey;
  if (p === "backend") return !!aiSettings.backendUrl;
  return true; // auto/preview
}

async function errText(res) {
  try { const j = await res.json(); return `${res.status} — ${j.error?.message || j.error?.type || JSON.stringify(j).slice(0, 180)}`; }
  catch { return `request failed (HTTP ${res.status})`; }
}
const asText = (data) => {
  if (data.content) return (data.content || []).filter(b => b.type === "text").map(b => b.text).join("\n").trim(); // anthropic
  if (data.choices) return (data.choices[0]?.message?.content || "").trim(); // openai
  if (typeof data.text === "string") return data.text.trim(); // backend
  return "";
};

async function callAI(userPrompt, system, opts = {}) {
  const msgs = Array.isArray(userPrompt) ? userPrompt : [{ role: "user", content: userPrompt }];
  const p = aiSettings.provider;
  const maxTokens = p === "auto" ? 1000 : (Number(aiSettings.maxTokens) || 4000); // preview bridge caps output
  let text = "";

  if (p === "openai") {
    if (!aiSettings.openaiKey) throw new Error("No OpenAI API key set — open “AI connection” in the sidebar to connect one.");
    const oa = msgs.map(m => ({ role: m.role, content: typeof m.content === "string" ? m.content : m.content.filter(c => c.type === "text").map(c => c.text).join("\n") }));
    if (system) oa.unshift({ role: "system", content: system });
    const res = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST", headers: { "Content-Type": "application/json", Authorization: "Bearer " + aiSettings.openaiKey },
      body: JSON.stringify({ model: aiSettings.model || "gpt-4o", messages: oa, max_tokens: maxTokens }) });
    if (!res.ok) throw new Error(await errText(res));
    text = asText(await res.json());

  } else if (p === "backend") {
    if (!aiSettings.backendUrl) throw new Error("No backend URL set — open “AI connection” in the sidebar.");
    const res = await fetch(aiSettings.backendUrl, { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ messages: msgs, system, max_tokens: maxTokens }) });
    if (!res.ok) throw new Error(await errText(res));
    text = asText(await res.json());

  } else { // anthropic (user key) OR auto (preview keyless bridge)
    const headers = { "Content-Type": "application/json" };
    const useKey = p === "anthropic";
    if (useKey) {
      if (!aiSettings.anthropicKey) throw new Error("No Anthropic API key set — open “AI connection” in the sidebar to connect one.");
      headers["x-api-key"] = aiSettings.anthropicKey;
      headers["anthropic-version"] = "2023-06-01";
      headers["anthropic-dangerous-direct-browser-access"] = "true";
    }
    const body = { model: aiSettings.model || (useKey ? "claude-3-5-sonnet-latest" : "claude-sonnet-4-6"), max_tokens: maxTokens, messages: msgs };
    if (system) body.system = system;
    const res = await fetch("https://api.anthropic.com/v1/messages", { method: "POST", headers, body: JSON.stringify(body) });
    if (!res.ok) throw new Error(await errText(res));
    text = asText(await res.json());
  }

  if (!text) throw new Error("The model returned an empty response — try again or check your connection settings.");
  if (opts.json) {
    const clean = text.replace(/```json/gi, "").replace(/```/g, "").trim();
    const s = clean.indexOf("{"), e = clean.lastIndexOf("}");
    if (s < 0 || e < 0) throw new Error("Expected JSON but the model returned prose. Try again.");
    return JSON.parse(clean.slice(s, e + 1));
  }
  return text;
}

async function testAI() {
  const t = await callAI("Reply with exactly the word: OK", null, {});
  return /ok/i.test(t);
}
function projectBrief(p) {
  const m = p.meta;
  const docList = p.docs.map(d => `- [${d.type}] ${d.name}`).join("\n") || "  (none uploaded)";
  const docText = p.docs.filter(d => d.text).map(d => `\n### ${d.type}: ${d.name}\n${(d.text || "").slice(0, 6000)}`).join("\n");
  return `ORGANIZATION PROFILE
Company: ${m.companyName || "—"}
Contract: ${m.contractName || "—"}  |  Customer: ${m.customerName || "—"}
ITSM platform: ${m.itsmPlatform || "—"}  |  Users: ${m.numUsers || "—"}  |  Technicians: ${m.numTechs || "—"}
Help desk hours: ${m.helpDeskHours || "—"}  |  Sites: ${m.numSites || "—"}
Tech stack: ${m.techStack || "—"}
Cloud: ${m.cloudProviders || "—"}  |  Vendors: ${m.vendors || "—"}

UPLOADED DOCUMENTS:
${docList}${docText ? "\n\nDOCUMENT CONTENT (truncated):\n" + docText : ""}`;
}

/* ============================================================================
   UI atoms (light + friendly)
   ========================================================================== */
const cx = (...a) => a.filter(Boolean).join(" ");
function Btn({ children, onClick, variant = "primary", size = "md", disabled, className, type }) {
  const base = "inline-flex items-center justify-center gap-2 font-semibold rounded-xl transition focus:outline-none focus-visible:ring-2 focus-visible:ring-indigo-400 focus-visible:ring-offset-2 disabled:opacity-40 disabled:cursor-not-allowed";
  const sizes = { sm: "text-sm px-3 py-1.5", md: "text-sm px-4 py-2.5", lg: "text-base px-6 py-3" };
  const variants = {
    primary: "bg-indigo-600 hover:bg-indigo-500 text-white shadow-sm",
    subtle: "bg-indigo-50 hover:bg-indigo-100 text-indigo-700",
    outline: "border border-slate-300 bg-white text-slate-700 hover:bg-slate-50",
    ghost: "text-slate-600 hover:bg-slate-100",
    danger: "bg-rose-600 hover:bg-rose-500 text-white",
  };
  return <button type={type || "button"} onClick={onClick} disabled={disabled}
    className={cx(base, sizes[size], variants[variant], className)}>{children}</button>;
}
function Field({ label, children, hint }) {
  return <label className="block">
    <span className="text-sm font-medium text-slate-700">{label}</span>
    <div className="mt-1.5">{children}</div>
    {hint && <span className="mt-1 block text-xs text-slate-400">{hint}</span>}
  </label>;
}
const inputCls = "w-full rounded-xl border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-800 placeholder-slate-400 focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-100";
function Card({ children, className }) {
  return <div className={cx("rounded-2xl border border-slate-200 bg-white shadow-sm", className)}>{children}</div>;
}
function StatusPill({ s }) {
  const st = STATUS[s] || STATUS.missing;
  return <span className={cx("inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-semibold", st.chip)}>
    <span className="h-1.5 w-1.5 rounded-full" style={{ background: st.color || "#94a3b8" }} />{st.label}</span>;
}
function Toast({ msg }) {
  if (!msg) return null;
  return <div className="fixed bottom-6 left-1/2 z-50 -translate-x-1/2 rounded-xl bg-slate-900 px-4 py-2.5 text-sm font-medium text-white shadow-xl">{msg}</div>;
}
function SectionTitle({ icon: Icon, title, sub }) {
  return <div className="mb-4">
    <div className="flex items-center gap-2">
      {Icon && <Icon className="h-5 w-5 text-indigo-600" />}
      <h2 className="text-lg font-semibold text-slate-900">{title}</h2>
    </div>
    {sub && <p className="mt-1 text-sm text-slate-500">{sub}</p>}
  </div>;
}
function InfoNote({ children }) {
  return <div className="mb-5 flex gap-2.5 rounded-xl border border-indigo-100 bg-indigo-50/70 px-4 py-3 text-sm text-indigo-900">
    <HelpCircle className="mt-0.5 h-4 w-4 flex-shrink-0 text-indigo-500" /><div>{children}</div></div>;
}

/* markdown -> html */
function mdToHtml(md) {
  if (!md) return "";
  const esc = (s) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  const inline = (s) => esc(s).replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>").replace(/\*(.+?)\*/g, "<em>$1</em>").replace(/`(.+?)`/g, "<code>$1</code>");
  const lines = md.split("\n"); let html = "", inTable = false, tbl = [];
  const flush = () => { if (!tbl.length) return;
    const rows = tbl.filter(r => !/^\s*\|?[\s:|-]+\|?\s*$/.test(r));
    html += '<table class="md-table">';
    rows.forEach((r, i) => { const c = r.replace(/^\||\|$/g, "").split("|").map(x => x.trim());
      html += "<tr>" + c.map(x => i === 0 ? `<th>${inline(x)}</th>` : `<td>${inline(x)}</td>`).join("") + "</tr>"; });
    html += "</table>"; tbl = []; inTable = false; };
  for (const raw of lines) { const line = raw.replace(/\s+$/, "");
    if (line.includes("|") && line.split("|").length > 2) { inTable = true; tbl.push(line); continue; }
    if (inTable) flush();
    if (/^###\s/.test(line)) html += `<h3>${inline(line.slice(4))}</h3>`;
    else if (/^##\s/.test(line)) html += `<h2>${inline(line.slice(3))}</h2>`;
    else if (/^#\s/.test(line)) html += `<h1>${inline(line.slice(2))}</h1>`;
    else if (/^[-*]\s/.test(line)) html += `<li>${inline(line.slice(2))}</li>`;
    else if (/^\d+\.\s/.test(line)) html += `<li>${inline(line.replace(/^\d+\.\s/, ""))}</li>`;
    else if (line.trim() === "") html += "";
    else html += `<p>${inline(line)}</p>`; }
  if (inTable) flush();
  return html.replace(/(<li>.*?<\/li>)(?!\s*<li>)/gs, "<ul>$1</ul>").replace(/<\/ul>\s*<ul>/g, "");
}

/* exports */
function downloadBlob(content, filename, mime) {
  const url = URL.createObjectURL(new Blob([content], { type: mime }));
  const a = document.createElement("a"); a.href = url; a.download = filename; a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1500);
}
const safeName = (s) => s.replace(/[^\w\-]+/g, "_").slice(0, 60);
function exportWord(title, md) {
  const html = `<!DOCTYPE html><html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'><head><meta charset='utf-8'><title>${title}</title>
  <style>body{font-family:Calibri,Arial,sans-serif;font-size:11pt;color:#111;line-height:1.5}h1{font-size:20pt;color:#1e293b;border-bottom:2px solid #6366f1;padding-bottom:6px}h2{font-size:15pt;color:#3730a3;margin-top:18px}h3{font-size:12pt;color:#4338ca}table{border-collapse:collapse;width:100%;margin:10px 0}th,td{border:1px solid #cbd5e1;padding:6px 8px;font-size:10pt;text-align:left}th{background:#eef2ff}code{background:#f1f5f9;padding:1px 4px}ul{margin:6px 0 6px 18px}</style></head>
  <body><h1>${title}</h1>${mdToHtml(md)}<p style="margin-top:30px;color:#94a3b8;font-size:8pt">Generated by ISO 20000-1 Copilot • ${new Date().toLocaleString()}</p></body></html>`;
  downloadBlob(html, safeName(title) + ".doc", "application/msword");
}
function exportPdf(title, md) {
  const html = `<html><head><meta charset='utf-8'><title>${title}</title><style>@page{margin:22mm}body{font-family:-apple-system,Segoe UI,Arial,sans-serif;color:#0f172a;line-height:1.55;font-size:12px}h1{font-size:22px;border-bottom:3px solid #6366f1;padding-bottom:6px}h2{font-size:16px;color:#3730a3;margin-top:18px}h3{font-size:13px;color:#4338ca}table{border-collapse:collapse;width:100%;margin:10px 0}th,td{border:1px solid #cbd5e1;padding:5px 7px;font-size:11px}th{background:#eef2ff}code{background:#f1f5f9;padding:1px 4px;border-radius:3px}ul{margin:6px 0 6px 18px}</style></head><body><h1>${title}</h1>${mdToHtml(md)}<p style="margin-top:26px;color:#94a3b8;font-size:9px">ISO 20000-1 Copilot • ${new Date().toLocaleString()}</p></body></html>`;
  const f = document.createElement("iframe");
  f.style.cssText = "position:fixed;right:0;bottom:0;width:0;height:0;border:0";
  document.body.appendChild(f); const d = f.contentWindow.document; d.open(); d.write(html); d.close();
  setTimeout(() => { f.contentWindow.focus(); f.contentWindow.print(); setTimeout(() => document.body.removeChild(f), 1000); }, 350);
}

/* ============================================================================
   Implementation Coach — concrete, ordered next-actions per required process
   ========================================================================== */
const TASKS_TEMPLATE = {
  incident: ["Review the generated Incident Management policy & procedure", "Assign an Incident Manager", "Configure the P1–P4 priority matrix in ServiceNow", "Set up the major-incident (P1) bridge & communications process", "Handle and record your first incidents to the SLA", "Mark Incident Management implemented"],
  request: ["Review the generated Service Request policy & procedure", "Assign a Request Fulfilment owner", "Publish the service catalogue in ServiceNow", "Define approval workflows for request types", "Fulfil and record your first requests within SLA", "Mark Service Request Management implemented"],
  problem: ["Review the generated Problem Management policy & procedure", "Assign a Problem Manager", "Stand up the known-error database", "Set the trigger for raising problems from incident trends", "Complete your first root-cause analysis", "Mark Problem Management implemented"],
  change: ["Review the generated Change Enablement policy & procedure", "Assign a Change Manager", "Establish the Change Advisory Board (CAB)", "Configure change types & approvals in ServiceNow", "Run your first changes with back-out plans", "Mark Change Enablement implemented"],
  config: ["Review the generated Configuration Management policy & procedure", "Assign a Configuration Manager", "Define the CI model and populate the CMDB", "Enable discovery and set the reconciliation cadence", "Complete your first CMDB audit", "Mark Configuration Management implemented"],
  asset: ["Review the generated Asset Management policy & procedure", "Assign an Asset Manager", "Set up the asset register and license tracking", "Schedule inventory reconciliation", "Complete your first inventory reconciliation", "Mark Asset Management implemented"],
  knowledge: ["Review the generated Knowledge Management policy & procedure", "Assign a Knowledge Manager", "Set up the knowledge base and article templates (KCS)", "Publish self-service content to the portal", "Review and measure your first knowledge articles", "Mark Knowledge Management implemented"],
  capacity: ["Review the generated Capacity Management policy & procedure", "Assign a Capacity Manager", "Configure monitoring thresholds (staffing, telephony, platform)", "Schedule monthly capacity reviews", "Produce and upload the first capacity report", "Mark Capacity Management implemented"],
  availability: ["Review the generated Availability Management policy & procedure", "Assign an Availability Manager", "Set availability targets and monitoring/alerts", "Remove single points of failure in the design", "Report your first availability results against targets", "Mark Availability Management implemented"],
  continuity: ["Review the generated Service Continuity policy & plan", "Assign a Continuity Manager", "Agree RTO/RPO with the customer", "Document and provision recovery capability", "Run your first continuity test", "Mark Service Continuity Management implemented"],
  slm: ["Review the generated Service Level Management policy & procedure", "Assign a Service Level Manager", "Confirm SLAs/OLAs and targets with the customer", "Stand up SLA dashboards & reporting", "Hold your first monthly service review", "Mark Service Level Management implemented"],
  supplier: ["Review the generated Supplier Management policy & procedure", "Assign a Supplier Manager", "Build the supplier register with underpinning contracts/OLAs", "Set the supplier review cadence", "Hold your first supplier review", "Mark Supplier Management implemented"],
  release: ["Review the generated Release & Deployment policy & procedure", "Assign a Release Manager", "Define release types, acceptance criteria & test gates", "Set the deployment & back-out approach", "Deploy your first release with early-life support", "Mark Release & Deployment Management implemented"],
  monitoring: ["Review the generated Monitoring & Reporting policy & procedure", "Assign a Reporting owner", "Build dashboards covering all SLAs in ServiceNow", "Define the monthly report pack", "Deliver your first monthly report on time", "Mark Monitoring & Reporting implemented"],
  improvement: ["Review the generated Continual Improvement policy & procedure", "Assign an Improvement owner", "Stand up the improvement register", "Set the review cadence (link to management review)", "Deliver your first measured improvement", "Mark Continual Improvement implemented"],
};
function taskItems(p, key) { if (p.tasks && p.tasks[key]) return p.tasks[key]; return (TASKS_TEMPLATE[key] || []).map(t => ({ t, done: false })); }
function procPct(p, key) { const it = taskItems(p, key); return it.length ? it.filter(x => x.done).length / it.length : 0; }
function procStatusKey(p, key) { if (p.gaps[key] === "na") return "na"; const pct = procPct(p, key); return pct >= 1 ? "implemented" : pct > 0 ? "partial" : "missing"; }
function requiredProcs(p) { return PROCESSES.filter(pr => p.gaps[pr.key] !== "na"); }
function nextTask(p) {
  for (const pr of requiredProcs(p)) { const it = taskItems(p, pr.key); const i = it.findIndex(x => !x.done); if (i >= 0) return { proc: pr, index: i, task: it[i].t, total: it.length, done: it.filter(x => x.done).length }; }
  return null;
}

/* ============================================================================
   The real-world actions only her team can do (software can't). Short, honest.
   ========================================================================== */
const ACTIONS = [
  "Assign an owner to each ITSM process (Incident, Change, Problem, Capacity, etc.)",
  "Configure your ITSM tool (e.g. ServiceNow) to match the generated procedures",
  "Set up the incident priority matrix and service-request workflows",
  "Stand up your CMDB and known-error database",
  "Establish your Change Advisory Board (CAB)",
  "Build SLA dashboards and your monthly report pack",
  "Publish your service catalogue and knowledge base",
  "Schedule the recurring reviews (service, capacity, management)",
  "Run a service continuity test",
  "Collect real objective evidence (records) for each process",
  "Conduct your internal audit and close any findings",
  "Book your Stage 1 and Stage 2 certification audits",
];
function actionItems(p) { return (p.actions && p.actions.length) ? p.actions : ACTIONS.map(t => ({ t, done: false })); }
function packPrompt(project, pr) {
  return `${projectBrief(project)}

Write the full "${pr.name}" ITSM process pack (ISO/IEC 20000-1 clause ${pr.clause}) tailored to this contract and tools. Markdown, with these ## sections in order: Policy, Procedure, Workflow (step-by-step), RACI Matrix (table), Roles & Responsibilities, Inputs & Outputs, KPIs & Targets (table), Risks & Controls (table), Required Records & Forms, Templates & Work Instructions. Be specific and audit-ready.`;
}

/* ============================================================================
   Scoring — the tool auto-builds the paperwork; the org does the real work.
   ========================================================================== */
function builtScore(p) {
  const totalDocs = CORE_DOCS.length + PROCESSES.length;
  const docScore = Math.min(1, Object.keys(p.generated).length / totalDocs);
  const auditScore = Math.min(1, Object.keys(p.audit).length / 7);
  return docScore * 0.8 + auditScore * 0.2;
}
function computeReadiness(p) {
  const acts = actionItems(p);
  const actionScore = acts.length ? acts.filter(a => a.done).length / acts.length : 0;
  const built = builtScore(p);
  return {
    score: Math.round((built * 0.45 + actionScore * 0.55) * 100),
    built, actionScore,
    genCount: Object.keys(p.generated).length, totalDocs: CORE_DOCS.length + PROCESSES.length,
    actionsDone: acts.filter(a => a.done).length, actionsTotal: acts.length,
  };
}
const scoreColor = (s) => s >= 75 ? "#059669" : s >= 45 ? "#f59e0b" : "#e11d48";
function clauseCoverage(p) {
  return CLAUSES.map(c => {
    const procs = PROCESSES.filter(pr => pr.clause.startsWith(c.id));
    const procScore = procs.length ? procs.reduce((s, pr) => s + (STATUS[p.gaps[pr.key]]?.w || 0), 0) / procs.length : null;
    const docs = CORE_DOCS.filter(d => d.clause.split("/").some(cl => cl.trim().startsWith(c.id)));
    const docGen = docs.length ? docs.filter(d => p.generated[d.key]).length / docs.length : null;
    const parts = [procScore, docGen].filter(v => v !== null);
    return { clause: "Clause " + c.id, id: c.id, pct: parts.length ? Math.round(parts.reduce((a, b) => a + b, 0) / parts.length * 100) : 0 };
  });
}
function liveState(p) {
  const gaps = PROCESSES.map(pr => `${pr.name} (${pr.clause}): ${STATUS[p.gaps[pr.key]].label}`).join("; ");
  const gen = Object.values(p.generated).map(g => g.title).join(", ") || "none";
  const audits = Object.keys(p.audit).map(c => "Cl " + c).join(", ") || "none";
  return `Process status: ${gaps}\nGenerated documents: ${gen}\nAudit kits: ${audits}\nOpen items: ${p.findings.filter(f => f.status !== "closed").length}\nAnalyzed: ${p.analysis ? "yes" : "no"}`;
}
const delay = (ms) => new Promise(r => setTimeout(r, ms));
const hasData = (d) => !!(d.meta.companyName || d.analysis || (d.docs && d.docs.length));

async function readFileSmart(file) {
  const ext = file.name.split(".").pop().toLowerCase();
  if (["txt", "md", "csv", "json"].includes(ext)) return { text: await file.text() };
  if (ext === "pdf") { const b = await new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result.split(",")[1]); r.onerror = rej; r.readAsDataURL(file); }); return { pdf: b }; }
  if (ext === "docx") { try { const m = await import("mammoth"); return { text: (await m.extractRawText({ arrayBuffer: await file.arrayBuffer() })).value }; } catch { return { text: "" }; } }
  return { text: await file.text().catch(() => "") };
}

/* ============================================================================
   Brand — one place to rename the product
   ========================================================================== */
const BRAND = { name: "Conforma", tagline: "Turn your contract into an audit-ready compliance system — for any standard." };

/* Pricing — startup plans. Wire the checkout links to your Stripe Payment Links. */
const PRICING = [
  { id: "starter", name: "Starter", price: "$2,500", unit: "one-time", tagline: "For a company doing one ISO 20000 implementation.",
    features: ["Full AI contract analysis", "Every document generated for you", "Internal audit kit (clauses 4–10)", "Implementation roadmap", "Word / PDF / Excel export", "90 days of access"], cta: "Get started" },
  { id: "pro", name: "Pro", price: "$500", unit: "per month", popular: true, tagline: "For consultants & MSPs running ISO for clients.",
    features: ["Everything in Starter", "Unlimited implementations", "AI assistant on every project", "Ongoing standard updates", "Priority support"], cta: "Start Pro" },
  { id: "firm", name: "Firm", price: "$2,000", unit: "per month", tagline: "For teams selling ISO as a service.",
    features: ["Everything in Pro", "White-label with your brand", "Multiple concurrent projects", "Guided onboarding"], cta: "Talk to us" },
];
// Paste your Stripe Payment Link URLs here; empty falls back to the contact link.
const CHECKOUT = { starter: "", pro: "", firm: "", contact: "mailto:hello@conforma.app?subject=Conforma%20plan" };
function goCheckout(id) { const url = CHECKOUT[id] || CHECKOUT.contact; try { window.open(url, "_blank"); } catch (e) {} }

function Logo({ size = 40 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 40 40" fill="none" aria-hidden="true">
      <defs><linearGradient id="cfg" x1="0" y1="0" x2="40" y2="40">
        <stop stopColor="#F0CE7A" /><stop offset="1" stopColor="#E9B949" /></linearGradient></defs>
      <rect width="40" height="40" rx="11" fill="url(#cfg)" />
      <path d="M11.5 21l5 5L28.5 14" stroke="#0E1526" strokeWidth="3.2" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M11 14.5h6.5" stroke="#0E1526" strokeOpacity=".4" strokeWidth="2.4" strokeLinecap="round" />
    </svg>
  );
}

/* ============================================================================
   App — three stages: drop -> building -> workspace
   ========================================================================== */
export default function App() {
  const [project, setProject] = useState(null);
  const [loaded, setLoaded] = useState(false);
  const [stage, setStage] = useState("drop");
  const [build, setBuild] = useState(null);
  const [toast, setToast] = useState("");
  const [aiOk, setAiOk] = useState(null);
  const [modal, setModal] = useState(null);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [pricingOpen, setPricingOpen] = useState(false);
  const [securityOpen, setSecurityOpen] = useState(false);
  const [framework, setFramework] = useState("iso20000");
  const saveTimer = useRef(null);

  useEffect(() => { Promise.all([store.load(), loadAiSettings()]).then(([d]) => {
    if (d) { setProject(d); setStage(hasData(d) ? "workspace" : "drop"); } else setProject(emptyProject());
    setLoaded(true); }); }, []);
  useEffect(() => { if (!loaded || !project) return; clearTimeout(saveTimer.current); saveTimer.current = setTimeout(() => store.save(project), 600); }, [project, loaded]);

  const flash = useCallback((m) => { setToast(m); setTimeout(() => setToast(""), 2200); }, []);
  const patch = useCallback((fn) => setProject(p => { const n = structuredClone(p); fn(n); return n; }), []);
  const readiness = useMemo(() => project ? computeReadiness(project) : null, [project]);

  const runBuild = useCallback(async (base, { demo } = {}) => {
    setStage("building");
    const steps = [
      { label: "Reading your contract", state: "run" },
      { label: "Understanding your organization & obligations", state: "todo" },
      { label: "Writing every document for you", state: "todo" },
      { label: "Finishing your system", state: "todo" },
    ];
    setBuild({ steps, note: demo ? "Loading a live sample project" : (base.docs[0]?.name || "your contract"), error: null });
    const upd = (i, state, extra) => setBuild(b => ({ ...b, steps: b.steps.map((x, j) => j === i ? { ...x, state, extra: extra ?? x.extra } : x) }));
    let proj = structuredClone(base);
    try {
      if (demo) {
        const extras = ["", proj.meta.companyName, `${Object.keys(proj.generated).length} documents built`, "ready"];
        for (let i = 0; i < steps.length; i++) { upd(i, "run"); await delay(500); upd(i, "done", extras[i]); }
      } else {
        upd(0, "done", proj.docs[0]?.name);
        upd(1, "run");
        const spec = FW_SPECS[framework] || FW_SPECS.iso20000;
        proj.framework = framework;
        proj.docList = spec.docList;
        const prompt = `${projectBrief(proj)}

You are a ${spec.standard} implementation consultant. Read the contract above and return ONLY JSON:
{"company":"","customer":"","itsmPlatform":"","users":"","deliverables":["key documents or obligations this contract implies for ${spec.standard}"],"expectations":["what the customer expects"],"compliance":["relevant frameworks/standards mentioned or implied"]}
Infer company/customer/platform/users from the text if present. Be specific. JSON only.`;
        const content = [{ type: "text", text: prompt }, ...proj.docs.filter(d => d.pdf).slice(0, 3).map(d => ({ type: "document", source: { type: "base64", media_type: "application/pdf", data: d.pdf } }))];
        const a = await callAI([{ role: "user", content }], null, { json: true });
        proj.analysis = { ...a, ts: Date.now() };
        if (a.company && !proj.meta.companyName) proj.meta.companyName = a.company;
        if (a.customer) proj.meta.customerName = a.customer;
        if (a.itsmPlatform) proj.meta.itsmPlatform = a.itsmPlatform;
        if (a.users) proj.meta.numUsers = a.users;
        upd(1, "done", `${(a.deliverables || []).length} obligations · tailored to ${proj.meta.companyName || "your organization"}`);
        const total = spec.docList.length;
        let n = 0; upd(2, "run", "0 / " + total);
        for (const d of spec.docList) {
          const ref = d.clause && d.clause !== "—" ? ` (${spec.standard}, clause/ref ${d.clause})` : ` (${spec.standard})`;
          const c = await callAI(`${projectBrief(proj)}\n\nYou are a ${spec.standard} implementation consultant. Write the "${d.name}"${ref}, tailored specifically to this organization's contract, customer, platform and scale. Markdown, concrete, audit-ready, with tables where useful. No placeholder text or meta-commentary — write the actual document content.`);
          proj.generated[d.key] = { title: d.name, clause: d.clause, content: c, ts: Date.now() };
          n++; upd(2, "run", n + " / " + total); setProject(structuredClone(proj));
        }
        upd(2, "done", total + " documents written");
        upd(3, "run"); proj.actions = ACTIONS.map(t => ({ t, done: false })); await delay(300); upd(3, "done", "your system is ready");
        setAiOk(true);
      }
      setProject(proj); await delay(450); setStage("workspace");
    } catch (e) { setAiOk(false); setBuild(b => ({ ...b, error: e.message })); }
  }, [framework]);

  const startFile = useCallback(async (file) => {
    if (!file) return;
    const base = emptyProject();
    const parsed = await readFileSmart(file);
    base.docs.push({ id: "f" + Date.now(), type: "PWS", name: file.name, text: parsed.text || "", pdf: parsed.pdf || null });
    runBuild(base, { demo: false });
  }, [runBuild]);
  const startDemo = useCallback(() => {
    const b = { iso27001: makeDemo27k, cmmc: makeDemoCmmc,
      iso9001: () => makeDemoFW("iso9001", DEMO_9001), iso22301: () => makeDemoFW("iso22301", DEMO_22301),
      iso42001: () => makeDemoFW("iso42001", DEMO_42001), soc2: () => makeDemoFW("soc2", DEMO_SOC2) }[framework];
    return runBuild(b ? b() : makeDemo(), { demo: true });
  }, [runBuild, framework]);
  const resetAll = useCallback(() => { setProject(emptyProject()); setStage("drop"); }, []);

  if (!loaded || !project) return <div className="flex h-screen items-center justify-center bg-white text-slate-300"><Loader2 className="h-6 w-6 animate-spin" /></div>;

  const shared = { project, patch, flash, readiness, setModal, setSettingsOpen, setPricingOpen, aiOk, setAiOk, startDemo, resetAll };

  return (
    <div className="iso-app h-screen w-full overflow-hidden bg-slate-50 font-sans text-slate-800">
      <style>{globalCss}</style>
      {stage === "drop" && <Landing onFile={startFile} onDemo={startDemo} onSettings={() => setSettingsOpen(true)} onSecurity={() => setSecurityOpen(true)} aiOk={aiOk} framework={framework} setFramework={setFramework} />}
      {stage === "building" && <Building build={build} onSettings={() => setSettingsOpen(true)} onDemo={startDemo} onRetry={() => setStage("drop")} />}
      {stage === "workspace" && <Workspace {...shared} />}
      {modal && <DocModal doc={modal} onClose={() => setModal(null)} patch={patch} flash={flash} />}
      {settingsOpen && <SettingsModal onClose={() => setSettingsOpen(false)} flash={flash} aiOk={aiOk} setAiOk={setAiOk} />}
      {pricingOpen && <PricingModal onClose={() => setPricingOpen(false)} />}
      {securityOpen && <SecurityModal onClose={() => setSecurityOpen(false)} />}
      <Toast msg={toast} />
    </div>
  );
}

function seedGaps(proj, analysis) {
  const req = (analysis.processes || []).join(" ").toLowerCase();
  if (!req) return;
  const STOP = new Set(["service", "management", "and", "the", "of", "for"]);
  PROCESSES.forEach(pr => {
    const kw = pr.name.toLowerCase().split(/[ &/]+/).filter(w => w.length > 3 && !STOP.has(w));
    const needed = kw.some(w => req.includes(w)) || req.includes(pr.key);
    proj.gaps[pr.key] = needed ? "missing" : "na";
  });
}

/* ============================================================================
   STAGE 1 — Splash: one drop, one choice
   ========================================================================== */
/* ============================================================================
   LANDING — "Certified." Premium ink canvas + a gold seal-of-conformance as
   the signature. The product gets you certified, so the identity is the seal.
   ========================================================================== */
const VOID = "#0A0D12", PANEL = "#131A26", GOLD = "#E9B949", GOLDS = "#F0CE7A", MIST = "#8A93A6", PAPER = "#F7F8FA", INK = "#0E1526", EMER = "#34D399", LINE = "#E5E8EC", GOLDLINE = "rgba(233,185,73,.22)";

function SealMark({ size = 128, className = "", label = "ISO/IEC 20000-1" }) {
  const ring = `${label} · CONFORMANT · AUDIT-READY · `;
  return (
    <svg width={size} height={size} viewBox="0 0 128 128" className={className} fill="none" aria-hidden="true">
      <defs><path id="sealring" d="M64,64 m-47,0 a47,47 0 1,1 94,0 a47,47 0 1,1 -94,0" /></defs>
      <circle cx="64" cy="64" r="60" fill="none" stroke={GOLD} strokeWidth="1" opacity=".9" />
      <circle cx="64" cy="64" r="49" fill="none" stroke={GOLD} strokeWidth="1" opacity=".45" />
      <text fill={GOLD} className="cf-mono" style={{ fontSize: "7.2px", letterSpacing: "2px" }}>
        <textPath href="#sealring" startOffset="0%">{ring}</textPath>
      </text>
      <path d="M46 65 l11 11 l24 -26" fill="none" stroke={GOLD} strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function AssemblyPanel({ fw }) {
  const label = (fw && fw.name) || "ISO/IEC 20000-1";
  const short = (fw && fw.short) || "ISO 20000";
  const rows = [`Your complete ${short} documentation`, "Audit evidence, prepared", "Roadmap to certification", "The few gaps only you can close"];
  return (
    <div className="cf-up relative">
      <div className="cf-glow pointer-events-none absolute -inset-10 -z-10 rounded-full" style={{ background: "radial-gradient(50% 50% at 70% 30%, rgba(233,185,73,.20), transparent)" }} />
      <div className="overflow-hidden rounded-2xl border" style={{ background: PANEL, borderColor: GOLDLINE, boxShadow: "0 40px 90px -40px rgba(0,0,0,.8)" }}>
        <div className="flex items-center gap-2 border-b px-4 py-3" style={{ borderColor: "rgba(255,255,255,.07)" }}>
          <Logo size={20} /><span className="brand-font text-sm font-semibold text-white">Conforma</span>
          <span className="cf-mono ml-auto truncate text-[10px]" style={{ color: GOLD }}>● building {short}</span>
        </div>
        <div className="h-1 w-full" style={{ background: "rgba(255,255,255,.06)" }}><div className="cf-fill h-full" style={{ background: GOLD }} /></div>
        <div className="relative px-4 py-5">
          <div className="cf-scan pointer-events-none absolute left-0 right-0 h-10" style={{ background: "linear-gradient(180deg, rgba(233,185,73,.18), transparent)" }} />
          <div className="space-y-2.5">
            {rows.map((r, i) => (
              <div key={i} className="cf-anim-row flex items-center gap-3 rounded-lg border px-3 py-2.5" style={{ background: "rgba(255,255,255,.02)", borderColor: "rgba(255,255,255,.07)", animationDelay: (i * 0.6) + "s" }}>
                <CircleCheck className="h-4 w-4 flex-shrink-0" style={{ color: EMER }} />
                <span className="flex-1 truncate text-[12.5px] font-medium" style={{ color: "#E7EAF0" }}>{r}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="cf-mono truncate border-t px-4 py-2.5 text-[11px]" style={{ borderColor: "rgba(255,255,255,.07)", color: MIST }}>{label} · audit-ready · tailored to your contract</div>
      </div>
      <div className="cf-stamp pointer-events-none absolute -bottom-8 -right-6"><SealMark size={116} label={label} /></div>
    </div>
  );
}

function Landing({ onFile, onDemo, onSettings, onSecurity, aiOk, framework = "iso20000", setFramework }) {
  const fw = FRAMEWORKS[framework] || FRAMEWORKS.iso20000;
  const fileRef = useRef(null);
  const howRef = useRef(null), featRef = useRef(null), priceRef = useRef(null);
  const scrollTo = (r) => r.current?.scrollIntoView({ behavior: "smooth", block: "start" });
  const pick = () => fileRef.current?.click();

  const features = [
    { icon: FileText, t: "Your complete document set", d: "Every policy and procedure your certification needs — written and tailored to you." },
    { icon: ShieldCheck, t: "Audit evidence, prepared", d: "Walk into your assessment with exactly what the auditor expects to see." },
    { icon: GitBranch, t: "A clear path to certification", d: "Know precisely what to do next, in order, until you pass." },
    { icon: Sparkles, t: "Done in days, not months", d: "What used to take a consultant a quarter takes you an afternoon." },
    { icon: ListChecks, t: "No guesswork", d: "The handful of real-world steps only your team can do, spelled out." },
    { icon: MessageSquare, t: "Answers when you're stuck", d: "Ask anything about your certification and get a straight answer." },
  ];
  const ink = { color: INK }, muted = { color: "#5B6577" };

  return (
    <div className="iso-app h-full overflow-y-auto overflow-x-hidden" style={{ background: PAPER, color: INK }}>
      <input ref={fileRef} type="file" className="hidden" accept=".pdf,.docx,.txt,.md,.csv" onChange={e => onFile(e.target.files[0])} />

      {/* ===== DARK HERO ===== */}
      <div style={{ background: VOID }}>
        <header className="sticky top-0 z-30 border-b backdrop-blur" style={{ borderColor: "rgba(255,255,255,.07)", background: "rgba(10,13,18,.7)" }}>
          <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-3.5 sm:px-8">
            <div className="flex items-center gap-2.5"><Logo size={30} /><span className="brand-font text-xl font-semibold text-white">Conforma</span></div>
            <nav className="hidden items-center gap-7 md:flex">
              {[["How it works", howRef], ["Features", featRef], ["Pricing", priceRef]].map(([l, r]) => (
                <button key={l} onClick={() => scrollTo(r)} className="text-sm font-medium hover:text-white" style={{ color: MIST }}>{l}</button>
              ))}
            </nav>
            <div className="flex items-center gap-2">
              <button onClick={onDemo} className="hidden rounded-lg px-3 py-2 text-sm font-medium hover:text-white sm:block" style={{ color: MIST }}>Live demo</button>
              <button onClick={pick} className="rounded-lg px-4 py-2 text-sm font-semibold" style={{ background: GOLD, color: INK }}>Try it free</button>
            </div>
          </div>
        </header>

        <section className="relative overflow-hidden">
          <div className="cf-grid pointer-events-none absolute inset-0 opacity-60" style={{ maskImage: "radial-gradient(80% 60% at 50% 0%, #000, transparent)", WebkitMaskImage: "radial-gradient(80% 60% at 50% 0%, #000, transparent)" }} />
          <div className="cf-glow pointer-events-none absolute -top-40 left-1/2 h-96 w-[42rem] -translate-x-1/2 rounded-full" style={{ background: "radial-gradient(50% 50% at 50% 50%, rgba(233,185,73,.12), transparent)" }} />
          <div className="relative mx-auto grid grid-cols-1 max-w-6xl items-center gap-10 px-5 py-12 sm:px-8 lg:grid-cols-[1.05fr,0.95fr] lg:py-20">
            <div className="cf-up min-w-0">
              <div className="cf-mono mb-4 inline-flex items-center gap-2 rounded-full border px-3 py-1 text-[11px] font-medium" style={{ borderColor: GOLDLINE, color: GOLDS }}>
                <span className="h-1.5 w-1.5 rounded-full" style={{ background: GOLD }} />SEVEN STANDARDS · ONE ENGINE</div>
              <h1 className="brand-font text-[2.4rem] font-semibold leading-[1.03] tracking-tight text-white sm:text-[3.5rem]">
                Get <span className="italic" style={{ color: GOLD }}>certified,</span><br />without the consultants.</h1>
              <p className="mt-5 max-w-lg text-base leading-relaxed sm:text-lg" style={{ color: "#AEB6C4" }}>
                You won the contract — now you need to pass an audit. Conforma reads it and builds your <span style={{ color: "#E7EAF0" }}>{fw.short}</span> system in days, without the six-figure consultant.</p>
              {/* framework picker */}
              <div className="mt-6">
                <div className="cf-mono mb-2 text-[11px] uppercase tracking-wide" style={{ color: MIST }}>Choose your standard</div>
                <div className="grid max-w-md grid-cols-2 gap-2">
                  {Object.values(FRAMEWORKS).map(f => {
                    const on = f.id === framework;
                    return (
                      <button key={f.id} onClick={() => setFramework?.(f.id)}
                        className="min-w-0 rounded-xl border px-3 py-2 text-left transition"
                        style={{ borderColor: on ? GOLD : "rgba(255,255,255,.16)", background: on ? "rgba(233,185,73,.10)" : "transparent" }}>
                        <div className="truncate text-sm font-semibold" style={{ color: on ? GOLDS : "#E7EAF0" }}>{f.short}</div>
                        <div className="truncate text-[11px]" style={{ color: MIST }}>{f.tag}</div>
                      </button>
                    );
                  })}
                </div>
              </div>
              <div className="mt-6 flex flex-col gap-3 sm:flex-row">
                <button onClick={pick} className="inline-flex items-center justify-center gap-2 rounded-xl px-6 py-3.5 text-base font-semibold" style={{ background: GOLD, color: INK }}>
                  <CloudUpload className="h-5 w-5" />Upload your contract</button>
                <button onClick={onDemo} className="inline-flex items-center justify-center gap-2 rounded-xl border px-6 py-3.5 text-base font-semibold text-white hover:bg-white/5" style={{ borderColor: "rgba(255,255,255,.18)" }}>
                  <Sparkles className="h-5 w-5" style={{ color: GOLD }} />See it build one live</button>
              </div>
              <button onClick={onSecurity} className="mt-5 inline-flex items-start gap-1.5 text-left text-xs font-medium hover:text-white" style={{ color: MIST }}>
                <ShieldCheck className="mt-0.5 h-3.5 w-3.5 flex-shrink-0" style={{ color: EMER }} /><span>We don't store your documents. No CUI in this preview — <span className="underline">Security &amp; data</span></span></button>
            </div>
            <AssemblyPanel fw={fw} />
          </div>

          {/* trust strip — the dark→light seam */}
          <div className="border-t" style={{ borderColor: "rgba(255,255,255,.07)" }}>
            <div className="cf-mono mx-auto flex max-w-6xl flex-wrap items-center justify-center gap-x-6 gap-y-2 px-5 py-4 text-[11px] uppercase tracking-wide sm:px-8" style={{ color: MIST }}>
              <span>Federal contractors</span><span style={{ color: GOLD }}>/</span><span>Managed service providers</span><span style={{ color: GOLD }}>/</span><span>Corporate IT</span><span style={{ color: GOLD }}>/</span><span>ISO consultants</span>
            </div>
          </div>
        </section>
      </div>

      {/* ===== LIGHT BODY ===== */}
      {/* PROBLEM / SOLUTION */}
      <section className="mx-auto max-w-5xl px-5 py-20 sm:px-8">
        <h2 className="brand-font text-center text-3xl font-semibold sm:text-4xl" style={ink}>Certification, without the grind</h2>
        <div className="mx-auto mt-10 grid max-w-3xl gap-4 sm:grid-cols-2">
          <div className="rounded-2xl border bg-white p-6" style={{ borderColor: LINE }}>
            <div className="cf-mono text-xs uppercase tracking-wide" style={muted}>The old way</div>
            <ul className="mt-4 space-y-2.5 text-sm" style={{ color: "#3A4353" }}>
              {["Hire a consultant for tens of thousands", "Weeks-to-months writing documents", "Start every policy from a blank page", "Guess what the auditor will want"].map((x, i) => <li key={i} className="flex gap-2.5"><X className="mt-0.5 h-4 w-4 flex-shrink-0" style={{ color: "#E5484D" }} />{x}</li>)}
            </ul>
          </div>
          <div className="relative rounded-2xl border-2 bg-white p-6" style={{ borderColor: GOLD }}>
            <div className="cf-mono text-xs uppercase tracking-wide" style={{ color: "#9A7B1E" }}>With Conforma</div>
            <ul className="mt-4 space-y-2.5 text-sm" style={ink}>
              {["Audit-ready in days, not months", "No six-figure consultant", "Everything tailored to your contract", "You walk in ready to pass"].map((x, i) => <li key={i} className="flex gap-2.5"><Check className="mt-0.5 h-4 w-4 flex-shrink-0" style={{ color: EMER }} />{x}</li>)}
            </ul>
          </div>
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section ref={howRef} className="border-y bg-white py-20" style={{ borderColor: LINE }}>
        <div className="mx-auto max-w-6xl px-5 sm:px-8">
          <h2 className="brand-font text-center text-3xl font-semibold sm:text-4xl" style={ink}>Three steps to audit-ready</h2>
          <div className="mt-12 grid gap-6 sm:grid-cols-3">
            {[["01", "Drop your contract", "SOW or PWS — PDF, Word or text. No forms to fill in."],
              ["02", "We do the heavy lifting", "Your complete system — documents, evidence, plan — built for you."],
              ["03", "Finish the last mile", "A short, clear list of the real-world steps only your team can do."]].map(([n, t, d]) => (
              <div key={n} className="relative">
                <div className="cf-mono text-sm font-semibold" style={{ color: "#9A7B1E" }}>{n}</div>
                <div className="mt-3 h-px w-full" style={{ background: LINE }} />
                <div className="mt-4 brand-font text-xl font-semibold" style={ink}>{t}</div>
                <div className="mt-1.5 text-sm leading-relaxed" style={muted}>{d}</div>
              </div>
            ))}
          </div>
          <div className="mt-12 text-center"><button onClick={onDemo} className="inline-flex items-center gap-2 rounded-xl px-6 py-3 text-sm font-semibold" style={{ background: INK, color: "#fff" }}><Sparkles className="h-4 w-4" style={{ color: GOLD }} />Watch it build a real system</button></div>
        </div>
      </section>

      {/* FEATURES */}
      <section ref={featRef} className="mx-auto max-w-6xl px-5 py-20 sm:px-8">
        <h2 className="brand-font text-center text-3xl font-semibold sm:text-4xl" style={ink}>Everything you need to pass</h2>
        <p className="mx-auto mt-3 max-w-xl text-center" style={muted}>The documents, the evidence, and the plan — done for you.</p>
        <div className="mt-12 grid gap-px overflow-hidden rounded-2xl border sm:grid-cols-2 lg:grid-cols-3" style={{ borderColor: LINE, background: LINE }}>
          {features.map(f => { const Icon = f.icon; return (
            <div key={f.t} className="bg-white p-6">
              <div className="mb-4 flex h-10 w-10 items-center justify-center rounded-xl" style={{ background: "rgba(233,185,73,.14)", color: "#9A7B1E" }}><Icon className="h-5 w-5" /></div>
              <div className="brand-font text-lg font-semibold" style={ink}>{f.t}</div>
              <div className="mt-1.5 text-sm leading-relaxed" style={muted}>{f.d}</div>
            </div>
          ); })}
        </div>
      </section>

      {/* PRICING */}
      <section ref={priceRef} className="border-y bg-white py-20" style={{ borderColor: LINE }}>
        <div className="mx-auto max-w-5xl px-5 sm:px-8">
          <h2 className="brand-font text-center text-3xl font-semibold sm:text-4xl" style={ink}>Simple pricing</h2>
          <p className="mx-auto mt-3 max-w-xl text-center" style={muted}>A full implementation is normally weeks of consulting. This is a fraction of that.</p>
          <div className="mx-auto mt-12 grid max-w-4xl gap-5 sm:grid-cols-3">
            {PRICING.map(t => (
              <div key={t.id} className="relative flex flex-col rounded-2xl border p-6" style={{ borderColor: t.popular ? GOLD : LINE, boxShadow: t.popular ? "0 24px 50px -28px rgba(233,185,73,.5)" : "none" }}>
                {t.popular && <span className="cf-mono absolute -top-2.5 left-6 rounded-full px-2.5 py-0.5 text-[10px] font-semibold uppercase tracking-wide" style={{ background: GOLD, color: INK }}>Most popular</span>}
                <div className="text-sm font-semibold" style={ink}>{t.name}</div>
                <div className="mt-2 flex items-baseline gap-1.5"><span className="brand-font text-4xl font-semibold" style={ink}>{t.price}</span><span className="cf-mono text-xs" style={muted}>{t.unit}</span></div>
                <p className="mt-2 text-xs" style={muted}>{t.tagline}</p>
                <ul className="mt-5 flex-1 space-y-2">{t.features.map((f, i) => <li key={i} className="flex gap-2 text-xs" style={{ color: "#3A4353" }}><Check className="mt-0.5 h-3.5 w-3.5 flex-shrink-0" style={{ color: EMER }} />{f}</li>)}</ul>
                <button onClick={() => goCheckout(t.id)} className="mt-6 w-full rounded-xl px-4 py-2.5 text-sm font-semibold" style={t.popular ? { background: INK, color: "#fff" } : { border: "1px solid " + LINE, color: INK }}>{t.cta}</button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="mx-auto max-w-2xl px-5 py-20 sm:px-8">
        <h2 className="brand-font text-center text-3xl font-semibold sm:text-4xl" style={ink}>Questions</h2>
        <div className="mt-10 divide-y" style={{ borderColor: LINE }}>
          {[["Does it work with my specific contract?", "Yes. It reads your actual SOW/PWS and tailors every document to your organization, tools and SLAs."],
            ["Is the output really audit-ready?", "It generates complete, professional drafts an ISO practitioner would refine and approve. Certification also needs real operational evidence — which it lays out for you."],
            ["Do I need to set anything up?", "The live demo needs nothing — just click. To run it on your own contract, you connect a key once in settings. That\u2019s it."],
            ["Is my data safe?", "Your project stays in your browser and your key never leaves it. For federal data, Conforma can run inside your own FedRAMP GovCloud boundary."]].map(([q, a]) => (
            <details key={q} className="group py-4" style={{ borderColor: LINE }}>
              <summary className="flex cursor-pointer list-none items-center justify-between gap-4 text-sm font-semibold" style={ink}>{q}<ChevronDown className="h-4 w-4 flex-shrink-0 transition-transform group-open:rotate-180" style={muted} /></summary>
              <p className="mt-2.5 text-sm leading-relaxed" style={muted}>{a}</p>
            </details>
          ))}
        </div>
      </section>

      {/* FINAL CTA — dark bookend with the seal */}
      <section className="px-5 pb-20 sm:px-8">
        <div className="relative mx-auto max-w-5xl overflow-hidden rounded-3xl px-6 py-16 text-center" style={{ background: VOID }}>
          <div className="cf-grid pointer-events-none absolute inset-0 opacity-50" />
          <div className="relative mx-auto mb-6 w-fit"><SealMark size={92} /></div>
          <h2 className="brand-font relative text-3xl font-semibold text-white sm:text-4xl">Turn your contract into an<br />audit-ready system today.</h2>
          <div className="relative mt-8 flex flex-col justify-center gap-3 sm:flex-row">
            <button onClick={pick} className="inline-flex items-center justify-center gap-2 rounded-xl px-6 py-3.5 text-base font-semibold" style={{ background: GOLD, color: INK }}><CloudUpload className="h-5 w-5" />Upload your contract</button>
            <button onClick={onDemo} className="inline-flex items-center justify-center gap-2 rounded-xl border px-6 py-3.5 text-base font-semibold text-white hover:bg-white/5" style={{ borderColor: "rgba(255,255,255,.2)" }}><Sparkles className="h-5 w-5" style={{ color: GOLD }} />See the live demo</button>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer style={{ background: VOID }}>
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-3 px-5 py-8 sm:flex-row sm:px-8">
          <div className="flex items-center gap-2.5"><Logo size={26} /><div><div className="brand-font text-sm font-semibold text-white">Conforma</div><div className="cf-mono text-[11px]" style={{ color: MIST }}>Any standard, automated</div></div></div>
          <div className="cf-mono flex items-center gap-5 text-[11px]" style={{ color: MIST }}>
            <button onClick={onSettings} className="hover:text-white">AI connection</button>
            <button onClick={onSecurity} className="hover:text-white">Security</button>
            <button onClick={() => goCheckout("contact")} className="hover:text-white">Contact</button>
            <span>© {new Date().getFullYear()}</span>
          </div>
        </div>
      </footer>
    </div>
  );
}

function Splash({ onFile, onDemo, onSettings, onPricing, aiOk }) {
  const fileRef = useRef(null);
  const [drag, setDrag] = useState(false);
  const steps = [
    { n: "01", t: "Drop your contract", d: "SOW or PWS — PDF, Word or text." },
    { n: "02", t: "Conforma reads & builds", d: "Every policy, procedure, RACI & audit kit, written for you." },
    { n: "03", t: "You reach audit-ready", d: "A clear plan of the few real-world steps left." },
  ];
  return (
    <div className="relative h-full overflow-y-auto">
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="blob blob-a" /><div className="blob blob-b" />
      </div>

      {/* top bar */}
      <header className="relative z-10 flex items-center justify-between px-5 py-4 sm:px-8">
        <div className="flex items-center gap-2.5">
          <Logo size={34} />
          <span className="brand-font text-lg font-bold text-slate-900">{BRAND.name}</span>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={onPricing} className="rounded-full px-3 py-1.5 text-xs font-semibold text-slate-600 hover:bg-white/80 hover:text-slate-900">Pricing</button>
          <button onClick={onSettings} className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 bg-white/80 px-3 py-1.5 text-xs font-medium text-slate-500 backdrop-blur hover:text-slate-700">
            <span className={cx("h-1.5 w-1.5 rounded-full", aiOk === true ? "bg-emerald-500" : aiOk === false ? "bg-rose-500" : "bg-slate-300")} />AI connection</button>
        </div>
      </header>

      {/* hero */}
      <div className="relative z-10 mx-auto max-w-2xl px-5 pb-16 pt-6 text-center sm:pt-12">
        <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-indigo-100 bg-white/80 px-3 py-1 text-xs font-semibold text-indigo-600 backdrop-blur">
          <Sparkles className="h-3.5 w-3.5" />Compliance implementation, automated</div>
        <h1 className="brand-font text-4xl font-bold leading-[1.05] tracking-tight text-slate-900 sm:text-5xl">
          Your compliance system,<br />built from your contract.</h1>
        <p className="mx-auto mt-4 max-w-lg text-base text-slate-500 sm:text-lg">
          Drop your SOW or PWS. Conforma reads it, maps every ISO requirement, and writes your entire documented system — automatically.</p>

        <div
          onDragOver={e => { e.preventDefault(); setDrag(true); }}
          onDragLeave={() => setDrag(false)}
          onDrop={e => { e.preventDefault(); setDrag(false); onFile(e.dataTransfer.files[0]); }}
          onClick={() => fileRef.current?.click()}
          className={cx("group mx-auto mt-9 max-w-lg cursor-pointer rounded-3xl border-2 border-dashed bg-white/90 px-6 py-11 shadow-sm backdrop-blur transition",
            drag ? "scale-[1.02] border-indigo-500 bg-indigo-50" : "border-slate-300 hover:border-indigo-400 hover:shadow-md")}>
          <input ref={fileRef} type="file" className="hidden" accept=".pdf,.docx,.txt,.md,.csv" onChange={e => onFile(e.target.files[0])} />
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-indigo-600 to-violet-500 text-white shadow-lg shadow-indigo-200 transition group-hover:scale-105">
            <CloudUpload className="h-8 w-8" /></div>
          <div className="text-lg font-semibold text-slate-800">Drop your contract to begin</div>
          <div className="mt-1 text-sm text-slate-400">PDF, Word, or text — or click to choose</div>
        </div>

        <button onClick={onDemo} className="mt-6 inline-flex items-center gap-1.5 text-sm font-semibold text-indigo-600 hover:text-indigo-700">
          <Sparkles className="h-4 w-4" />See a live sample first<ArrowRight className="h-4 w-4" /></button>

        {/* how it works */}
        <div className="mx-auto mt-14 grid max-w-2xl grid-cols-1 gap-3 text-left sm:grid-cols-3">
          {steps.map(s => (
            <div key={s.n} className="rounded-2xl border border-slate-200 bg-white/80 p-4 backdrop-blur">
              <div className="brand-font text-xs font-bold text-indigo-400">{s.n}</div>
              <div className="mt-1 text-sm font-semibold text-slate-800">{s.t}</div>
              <div className="mt-0.5 text-xs text-slate-500">{s.d}</div>
            </div>
          ))}
        </div>
        <p className="mt-10 text-xs text-slate-400">Built for federal contractors, MSPs, and corporate IT teams pursuing ISO, CMMC, SOC 2 and more.</p>
      </div>
    </div>
  );
}

/* ============================================================================
   STAGE 2 — Building: the delightful assemble sequence
   ========================================================================== */
function Building({ build, onSettings, onDemo, onRetry }) {
  const steps = build?.steps || [];
  const done = steps.filter(s => s.state === "done").length;
  const pct = steps.length ? Math.round(done / steps.length * 100) : 0;
  return (
    <div className="iso-app relative flex h-full items-center justify-center px-5" style={{ background: "#F5F6F8" }}>
      <div className="cf-grid pointer-events-none absolute inset-0" style={{ maskImage: "radial-gradient(70% 60% at 50% 40%, #000, transparent)", WebkitMaskImage: "radial-gradient(70% 60% at 50% 40%, #000, transparent)" }} />
      <div className="relative w-full max-w-lg">
        <div className="mb-6 text-center">
          <div className="mb-4 flex justify-center"><Logo size={40} /></div>
          <h2 className="brand-font text-3xl font-semibold" style={{ color: "#0E1526" }}>{build?.error ? "Almost there" : "Assembling your system"}</h2>
          <p className="cf-mono mt-1.5 text-xs" style={{ color: "#5B6577" }}>{build?.error ? "one thing needs your attention" : "reading " + (build?.note || "your contract") + "…"}</p>
        </div>

        <div className="mb-6 h-1.5 w-full overflow-hidden rounded-full bg-slate-200">
          <div className="h-full rounded-full transition-all duration-500" style={{ width: pct + "%", background: "#0E1526" }} /></div>

        <div className="space-y-2.5">
          {steps.map((s, i) => (
            <div key={i} className={cx("flex items-center gap-3 rounded-xl border px-4 py-3 transition",
              s.state === "done" ? "border-emerald-100 bg-emerald-50/50" : s.state === "run" ? "bg-white" : "border-slate-100 bg-white/60")}
              style={s.state === "run" ? { borderColor: "#0E1526" } : undefined}>
              <span className="flex h-6 w-6 flex-shrink-0 items-center justify-center">
                {s.state === "done" ? <CheckCircle2 className="h-5 w-5 text-emerald-500" />
                  : s.state === "run" ? <Loader2 className="h-5 w-5 animate-spin" style={{ color: "#0E1526" }} />
                  : <Circle className="h-5 w-5 text-slate-200" />}</span>
              <span className="min-w-0 flex-1">
                <span className={cx("block text-sm font-medium", s.state === "todo" ? "text-slate-400" : "text-slate-700")}>{s.label}</span>
                {s.extra && s.state === "done" && <span className="cf-mono block text-xs text-slate-400">{s.extra}</span>}</span>
            </div>
          ))}
        </div>

        {build?.error && (
          <div className="mt-6 rounded-2xl border border-amber-200 bg-amber-50 p-4">
            <div className="flex items-start gap-2 text-sm text-amber-800">
              <AlertTriangle className="mt-0.5 h-4 w-4 flex-shrink-0" />
              <div>To read a real contract I need an AI connection. Connect one, or explore with the sample instead.</div>
            </div>
            <div className="mt-3 flex flex-wrap gap-2">
              <Btn size="sm" onClick={onSettings}><Plug className="h-4 w-4" />Connect AI</Btn>
              <Btn size="sm" variant="subtle" onClick={onDemo}><Sparkles className="h-4 w-4" />Use the sample</Btn>
              <Btn size="sm" variant="ghost" onClick={onRetry}>Back</Btn>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

/* ============================================================================
   STAGE 3 — Workspace: one living page + an ask bar
   ========================================================================== */
function Workspace(props) {
  const { project, patch, flash, readiness, setModal, setSettingsOpen, setPricingOpen, aiOk, setAiOk, startDemo, resetAll } = props;
  const [busy, setBusy] = useState("");
  const [menuOpen, setMenuOpen] = useState(false);
  const [open, setOpen] = useState({ docs: true, actions: false, found: false, audit: false, plan: false });
  const docsRef = useRef(null);
  const browseDocs = () => { setOpen(o => ({ ...o, docs: true })); requestAnimationFrame(() => docsRef.current?.scrollIntoView({ behavior: "smooth", block: "start" })); };
  const toggle = (k) => setOpen(o => ({ ...o, [k]: !o[k] }));
  const toggleAction = (i) => patch(p => { if (!p.actions || !p.actions.length) p.actions = ACTIONS.map(t => ({ t, done: false })); p.actions[i].done = !p.actions[i].done; });
  const suggestion = useMemo(() => ({
    text: readiness.actionsDone < readiness.actionsTotal ? "See your team's to-do list" : "Review audit readiness",
    run: () => setOpen(o => ({ ...o, actions: readiness.actionsDone < readiness.actionsTotal, audit: readiness.actionsDone >= readiness.actionsTotal })),
  }), [readiness]);
  async function genRest() {
    setBusy("finishing");
    try {
      for (const d of CORE_DOCS) { if (project.generated[d.key]) continue; setBusy("Writing " + d.name); const c = await callAI(`${projectBrief(project)}\n\nWrite the "${d.name}" (ISO clause ${d.clause}) tailored to this organization. Markdown, audit-ready.`); patch(p => { p.generated[d.key] = { title: d.name, clause: d.clause, content: c, ts: Date.now() }; }); }
      for (const pr of PROCESSES) { if (project.generated["proc_" + pr.key]) continue; setBusy("Writing " + pr.name); const c = await callAI(packPrompt(project, pr)); patch(p => { p.generated["proc_" + pr.key] = { title: pr.name + " — Full Pack", clause: pr.clause, content: c, ts: Date.now() }; }); }
      setAiOk?.(true); flash("Your system is complete");
    } catch (e) { setAiOk?.(false); flash("Stopped — open AI connection in the ⋯ menu"); }
    setBusy("");
  }

  async function genCore(doc) {
    setBusy(doc.name);
    try { const c = await callAI(`${projectBrief(project)}\n\nWrite the "${doc.name}" (ISO clause ${doc.clause}) tailored to this organization. Markdown, concrete, audit-ready, tables where useful.`);
      patch(p => { p.generated[doc.key] = { title: doc.name, clause: doc.clause, content: c, ts: Date.now() }; }); setAiOk?.(true); flash(doc.name + " ready"); }
    catch (e) { setAiOk?.(false); flash("Couldn't generate — connect AI in the ⋯ menu"); }
    setBusy("");
  }
  async function genAllCore() {
    setBusy("core");
    try { for (const d of CORE_DOCS) { if (project.generated[d.key]) continue; setBusy(d.name);
      const c = await callAI(`${projectBrief(project)}\n\nWrite the "${d.name}" (ISO clause ${d.clause}) tailored to this organization. Markdown, audit-ready.`);
      patch(p => { p.generated[d.key] = { title: d.name, clause: d.clause, content: c, ts: Date.now() }; }); } setAiOk?.(true); flash("Core documents ready"); }
    catch (e) { setAiOk?.(false); flash("Stopped — connect AI in the ⋯ menu"); }
    setBusy("");
  }
  async function genProcess(pr) {
    setBusy(pr.name); const key = "proc_" + pr.key; let asm = `# ${pr.name}\n_ISO/IEC 20000-1:2018 — Clause ${pr.clause}_\n`;
    try { for (let i = 0; i < PROCESS_SECTIONS.length; i++) { const sec = PROCESS_SECTIONS[i]; setBusy(`${pr.name} · ${sec} (${i + 1}/${PROCESS_SECTIONS.length})`);
      asm += "\n\n" + await callAI(`${projectBrief(project)}\n\nDocument the "${pr.name}" process (clause ${pr.clause}). Write ONLY the "${sec}" section, starting with "## ${sec}". Specific to this contract & tools. Tables for RACI/KPIs/risks.`);
      patch(p => { p.generated[key] = { title: pr.name + " — Full Pack", clause: pr.clause, content: asm, ts: Date.now() }; }); }
      patch(p => { if (p.gaps[pr.key] === "missing") p.gaps[pr.key] = "partial"; }); setAiOk?.(true); flash(pr.name + " pack ready"); }
    catch (e) { setAiOk?.(false); flash("Stopped — connect AI in the ⋯ menu"); }
    setBusy("");
  }
  async function genAuditKit(clause) {
    setBusy("audit"); const c = CLAUSES.find(x => x.id === clause); const subs = c.sub.map(s => s[0] + " " + s[1]).join("; ");
    try { for (const art of ["Audit Checklist", "Interview Questions", "Objective Evidence Requirements"]) { setBusy(`Audit · ${art}`);
      const out = await callAI(`${projectBrief(project)}\n\nAs an ISO/IEC 20000-1 internal auditor, produce the "${art}" for Clause ${clause} — ${c.name} (${subs}). Tailored, markdown, tables where useful.`);
      patch(p => { if (!p.audit[clause]) p.audit[clause] = {}; p.audit[clause][art] = out; }); } setAiOk?.(true); flash("Audit kit ready"); }
    catch (e) { setAiOk?.(false); flash("Stopped — connect AI in the ⋯ menu"); }
    setBusy("");
  }
  function exportEverything() {
    const fwName = (FRAMEWORKS[project.framework] || FRAMEWORKS.iso20000).name;
    let md = `# ${fwName} System — ${project.meta.companyName || "Your organization"}\n\n`;
    if (project.analysis) { const a = project.analysis; md += `## Contract summary\n**Customer:** ${project.meta.customerName || "—"}\n\n**Deliverables:** ${(a.deliverables || []).join("; ")}\n\n**Compliance:** ${(a.compliance || []).join(", ")}\n\n`; }
    Object.values(project.generated).forEach(g => { md += `\n\n---\n\n# ${g.title}\n_Clause ${g.clause}_\n\n${g.content}\n`; });
    Object.entries(project.audit).forEach(([cl, arts]) => Object.entries(arts).forEach(([art, c]) => { md += `\n\n---\n\n# ${art} — Clause ${cl}\n\n${c}\n`; }));
    exportWord("ISO 20000 System — " + (project.meta.companyName || "Export"), md); flash("Exported everything to Word");
  }

  return (
    <div className="flex h-full flex-col">
      {/* slim top bar */}
      <header className="z-20 flex items-center justify-between gap-3 border-b border-slate-200 bg-white/90 px-4 py-2.5 backdrop-blur sm:px-6">
        <div className="flex min-w-0 items-center gap-2.5">
          <Logo size={30} />
          <span className="brand-font hidden text-sm font-bold text-slate-900 sm:block">{BRAND.name}</span>
          <span className="hidden h-4 w-px bg-slate-200 sm:block" />
          <input value={project.meta.companyName} onChange={e => patch(p => { p.meta.companyName = e.target.value; })}
            placeholder="Name your project" className="min-w-0 flex-1 truncate border-0 bg-transparent text-sm font-semibold text-slate-900 placeholder-slate-300 focus:outline-none" />
        </div>
        <div className="flex items-center gap-2">
          <div className="hidden items-center gap-1.5 rounded-full bg-emerald-50 px-2.5 py-1 sm:flex">
            <CheckCircle2 className="h-3.5 w-3.5 text-emerald-500" />
            <span className="text-xs font-semibold text-emerald-700">Ready</span></div>
          <div className="relative">
            <button onClick={() => setMenuOpen(v => !v)} className="rounded-lg p-2 text-slate-500 hover:bg-slate-100"><MoreHorizontal className="h-5 w-5" /></button>
            {menuOpen && (<>
              <div className="fixed inset-0 z-10" onClick={() => setMenuOpen(false)} />
              <div className="absolute right-0 z-20 mt-1 w-56 rounded-xl border border-slate-200 bg-white py-1 shadow-lg">
                {[["Export everything to Word", () => { exportEverything(); setMenuOpen(false); }, Download],
                  ["AI connection", () => { setSettingsOpen(true); setMenuOpen(false); }, Plug],
                  ["Plans & pricing", () => { setPricingOpen(true); setMenuOpen(false); }, CreditCard],
                  ["Load the sample project", () => { startDemo(); setMenuOpen(false); }, Sparkles],
                  ["Start over", () => { if (confirm("Clear everything and start over?")) { resetAll(); } setMenuOpen(false); }, RefreshCw]].map(([label, fn, Icon]) => (
                  <button key={label} onClick={fn} className="flex w-full items-center gap-2.5 px-3 py-2 text-left text-sm text-slate-600 hover:bg-slate-50"><Icon className="h-4 w-4 text-slate-400" />{label}</button>
                ))}
              </div></>)}
          </div>
        </div>
      </header>

      <div className="flex-1 overflow-y-auto" style={{ background: PAPER }}>
        <div className="mx-auto max-w-3xl px-4 pb-40 pt-5 sm:px-6">
          {/* ready hero — leads with what she wants */}
          <div className="mb-5 rounded-2xl border border-slate-200 bg-white p-6">
            <div className="flex items-start gap-3">
              <div className="flex h-11 w-11 flex-shrink-0 items-center justify-center rounded-xl bg-emerald-50"><CheckCircle2 className="h-6 w-6 text-emerald-500" /></div>
              <div className="min-w-0 flex-1">
                <h2 className="brand-font text-xl font-bold text-slate-900">Your {(FRAMEWORKS[project.framework] || FRAMEWORKS.iso20000).short} system is ready</h2>
                <p className="mt-1 text-sm text-slate-500"><b className="text-slate-700">{readiness.genCount} documents</b> generated from your contract{project.meta.companyName ? ", tailored to " + project.meta.companyName : ""}. Open any below, or download the whole set.</p>
              </div>
            </div>
            <div className="mt-4 flex flex-wrap gap-2">
              <Btn onClick={exportEverything}><Download className="h-4 w-4" />Download everything</Btn>
              <Btn variant="outline" onClick={browseDocs}><FileText className="h-4 w-4" />Browse documents</Btn>
            </div>
          </div>

          {busy && <div className="mb-4 flex items-center gap-2 rounded-xl border border-indigo-100 bg-indigo-50 px-4 py-2.5 text-sm text-indigo-700"><Loader2 className="h-4 w-4 animate-spin" />{busy}</div>}

          <div ref={docsRef}>
            <Section title="Your documents" icon={FileText} open={open.docs} onToggle={() => toggle("docs")} badge={`${readiness.genCount} ready`}
              action={<button onClick={e => { e.stopPropagation(); exportEverything(); }} className="rounded-lg px-2.5 py-1 text-xs font-semibold text-white transition hover:opacity-90" style={{ background: INK }}>Download all</button>}>
              <DocsList project={project} busy={busy} onOpen={(k) => setModal({ key: k, ...project.generated[k] })} onGenRest={genRest} />
            </Section>
          </div>

          <Section title="A few things only your team can do" icon={ListChecks} open={open.actions} onToggle={() => toggle("actions")} badge={`${readiness.actionsDone}/${readiness.actionsTotal}`}>
            <ActionsBlock project={project} onToggle={toggleAction} />
          </Section>

          <Section title="What your contract requires" icon={FileSearch} open={open.found} onToggle={() => toggle("found")}
            badge={project.analysis ? `${(project.analysis.deliverables || []).length} deliverables` : "—"}>
            {project.analysis ? <FoundBlock a={project.analysis} /> : <Empty text="Drop a contract or load the sample to see this." />}
          </Section>

          <Section title="Audit kit" icon={ShieldCheck} open={open.audit} onToggle={() => toggle("audit")} badge={`${Object.keys(project.audit).length}/7 clauses`}>
            <AuditBlock project={project} busy={busy} onBuild={genAuditKit} onOpen={(title, content, clause) => setModal({ title: title + " — Clause " + clause, clause, content })} />
          </Section>

          <Section title="Your roadmap" icon={GitBranch} open={open.plan} onToggle={() => toggle("plan")}
            badge={`${project.roadmap.reduce((s, ph) => s + ph.tasks.filter(t => t.done).length, 0)}/${project.roadmap.reduce((s, ph) => s + ph.tasks.length, 0)}`}>
            <PlanBlock project={project} patch={patch} />
          </Section>
        </div>
      </div>

      <AskBar project={project} patch={patch} setModal={setModal} setAiOk={setAiOk} flash={flash} />
    </div>
  );
}

function Section({ title, icon: Icon, open, onToggle, badge, action, children }) {
  return (
    <div className="mb-3 overflow-hidden rounded-2xl border border-slate-200 bg-white">
      <button onClick={onToggle} className="flex w-full items-center gap-3 px-5 py-4 text-left hover:bg-slate-50">
        <Icon className="h-5 w-5 flex-shrink-0 text-indigo-600" />
        <span className="flex-1 text-sm font-semibold text-slate-900">{title}</span>
        {badge && <span className="rounded-full bg-slate-100 px-2 py-0.5 text-xs font-medium text-slate-500">{badge}</span>}
        {action}
        <ChevronDown className={cx("h-5 w-5 flex-shrink-0 text-slate-400 transition-transform", open && "rotate-180")} />
      </button>
      {open && <div className="border-t border-slate-100 px-5 py-4">{children}</div>}
    </div>
  );
}
const Empty = ({ text }) => <p className="py-2 text-sm text-slate-400">{text}</p>;

function FoundBlock({ a }) {
  const Chip = ({ children }) => <span className="rounded-full bg-indigo-50 px-2.5 py-1 text-xs font-medium text-indigo-700">{children}</span>;
  return (
    <div className="space-y-4">
      {a.compliance?.length > 0 && <div className="flex flex-wrap gap-1.5">{a.compliance.map((c, i) => <Chip key={i}>{c}</Chip>)}</div>}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <MiniList title="Must deliver" items={a.deliverables} />
        <MiniList title="Customer expects" items={a.expectations} />
      </div>
      {a.slas?.length > 0 && <MiniTable title="Service levels" head={["Metric", "Target", "Clause"]} rows={a.slas.map(s => [s.metric, s.target, s.clause])} />}
      {a.clauseMap?.length > 0 && <MiniTable title="Mapped to ISO 20000" head={["Clause", "What it covers"]} rows={a.clauseMap.map(s => [s.clause, s.requirement])} mono0 />}
    </div>
  );
}
function MiniList({ title, items }) {
  if (!items?.length) return null;
  return <div><div className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-slate-400">{title}</div>
    <ul className="space-y-1">{items.slice(0, 6).map((it, i) => <li key={i} className="flex gap-2 text-sm text-slate-600"><Check className="mt-0.5 h-3.5 w-3.5 flex-shrink-0 text-emerald-500" />{it}</li>)}</ul></div>;
}
function MiniTable({ title, head, rows, mono0 }) {
  if (!rows?.length) return null;
  return <div><div className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-slate-400">{title}</div>
    <div className="overflow-x-auto"><table className="w-full text-sm"><thead><tr className="text-left text-xs text-slate-400">{head.map(h => <th key={h} className="pb-1.5 pr-3 font-medium">{h}</th>)}</tr></thead>
    <tbody>{rows.slice(0, 12).map((r, i) => <tr key={i} className="border-t border-slate-100">{r.map((c, j) => <td key={j} className={cx("py-1.5 pr-3 align-top text-slate-600", j === 0 && mono0 && "font-mono text-xs text-indigo-600")}>{c}</td>)}</tr>)}</tbody></table></div></div>;
}

function StandBlock({ project, patch }) {
  const cov = clauseCoverage(project);
  return (
    <div className="space-y-4">
      <p className="text-xs text-slate-400">Tap a status to update it. “Not needed” drops it from your score.</p>
      <div className="grid grid-cols-1 gap-1.5 sm:grid-cols-2">
        {PROCESSES.map(pr => { const st = STATUS[project.gaps[pr.key]];
          return (
            <button key={pr.key} onClick={() => patch(p => { const i = STATUS_ORDER.indexOf(p.gaps[pr.key]); p.gaps[pr.key] = STATUS_ORDER[(i + 1) % STATUS_ORDER.length]; })}
              className="flex items-center justify-between gap-2 rounded-xl border border-slate-200 px-3 py-2 text-left hover:border-indigo-300">
              <span className="min-w-0"><span className="block truncate text-sm font-medium text-slate-700">{pr.name}</span><span className="text-xs text-slate-400">{pr.plain}</span></span>
              <span className="inline-flex flex-shrink-0 items-center gap-1 rounded-full border px-2 py-0.5 text-xs font-semibold" style={{ borderColor: (st.color || "#cbd5e1") + "40", color: st.color || "#64748b", background: (st.color || "#94a3b8") + "12" }}>{st.label}</span>
            </button>
          ); })}
      </div>
      <div className="space-y-1.5 pt-1">
        {cov.map(c => <div key={c.id} className="flex items-center gap-2"><span className="w-16 text-xs text-slate-400">Clause {c.id}</span>
          <div className="h-2 flex-1 overflow-hidden rounded-full bg-slate-100"><div className="h-full rounded-full" style={{ width: c.pct + "%", background: scoreColor(c.pct) }} /></div>
          <span className="w-9 text-right text-xs font-semibold" style={{ color: scoreColor(c.pct) }}>{c.pct}%</span></div>)}
      </div>
    </div>
  );
}

function DocsBlock({ project, busy, onOpen, onGenCore, onGenProc }) {
  const Row = ({ name, clause, gen, onGen, onOpenRow }) => (
    <div className="flex items-center justify-between gap-2 rounded-xl border border-slate-200 px-3 py-2">
      <button onClick={gen ? onOpenRow : undefined} className="min-w-0 flex-1 text-left"><span className="block truncate text-sm font-medium text-slate-700">{name}</span><span className="font-mono text-xs text-slate-400">{clause}</span></button>
      {gen ? <div className="flex items-center gap-1">
        <button onClick={onOpenRow} className="rounded-lg px-2 py-1 text-xs font-semibold text-indigo-600 hover:bg-indigo-50">Open</button>
        <button onClick={() => exportWord(name, project.generated[gen].content)} className="rounded-lg p-1.5 text-slate-400 hover:text-indigo-600" title="Word"><FileDown className="h-4 w-4" /></button>
      </div> : <button onClick={onGen} disabled={!!busy} className="flex-shrink-0 rounded-lg bg-indigo-600 px-2.5 py-1 text-xs font-semibold text-white hover:bg-indigo-500 disabled:opacity-50">Create</button>}
    </div>
  );
  return (
    <div className="space-y-4">
      <div>
        <div className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-slate-400">Foundation</div>
        <div className="grid grid-cols-1 gap-1.5 sm:grid-cols-2">
          {CORE_DOCS.map(d => <Row key={d.key} name={d.name} clause={d.clause} gen={project.generated[d.key] ? d.key : null} onGen={() => onGenCore(d)} onOpenRow={() => onOpen(d.key)} />)}
        </div>
      </div>
      <div>
        <div className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-slate-400">Process packs</div>
        <div className="grid grid-cols-1 gap-1.5 sm:grid-cols-2">
          {PROCESSES.map(pr => { const k = "proc_" + pr.key; return <Row key={pr.key} name={pr.name} clause={pr.clause} gen={project.generated[k] ? k : null} onGen={() => onGenProc(pr)} onOpenRow={() => onOpen(k)} />; })}
        </div>
      </div>
    </div>
  );
}

function AuditBlock({ project, busy, onBuild, onOpen }) {
  const [clause, setClause] = useState("8");
  const kit = project.audit[clause] || {};
  return (
    <div className="space-y-3">
      <div className="flex flex-wrap gap-1.5">
        {CLAUSES.map(c => <button key={c.id} onClick={() => setClause(c.id)}
          className={cx("rounded-full border px-3 py-1 text-xs font-medium", clause === c.id ? "border-indigo-500 bg-indigo-50 text-indigo-700" : "border-slate-200 text-slate-500 hover:border-indigo-300")}>
          Clause {c.id}{Object.keys(project.audit[c.id] || {}).length ? " ✓" : ""}</button>)}
      </div>
      <p className="text-sm text-slate-500">{CLAUSES.find(c => c.id === clause)?.plain}</p>
      {Object.keys(kit).length === 0
        ? <Btn size="sm" onClick={() => onBuild(clause)} disabled={!!busy}>{busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Wand2 className="h-4 w-4" />}Build audit kit for Clause {clause}</Btn>
        : <div className="space-y-1.5">{Object.entries(kit).map(([art, content]) => (
            <button key={art} onClick={() => onOpen(art, content, clause)} className="flex w-full items-center justify-between rounded-xl border border-slate-200 px-3 py-2 text-left hover:border-indigo-300">
              <span className="text-sm font-medium text-slate-700">{art}</span><span className="text-xs font-medium text-indigo-600">Open</span></button>))}
          <button onClick={() => onBuild(clause)} disabled={!!busy} className="text-xs font-medium text-indigo-600 hover:underline">+ regenerate</button></div>}
    </div>
  );
}

function PlanBlock({ project, patch }) {
  return (
    <div className="space-y-3">
      {project.roadmap.map((ph, pi) => { const pd = ph.tasks.filter(t => t.done).length, done = pd === ph.tasks.length;
        return (
          <div key={ph.id}>
            <div className="mb-1 flex items-center gap-2">
              <span className={cx("flex h-6 w-6 items-center justify-center rounded-full text-xs font-bold", done ? "bg-emerald-500 text-white" : pd ? "bg-amber-400 text-white" : "bg-slate-200 text-slate-500")}>{done ? <Check className="h-3.5 w-3.5" /> : ph.id}</span>
              <span className="text-sm font-semibold text-slate-800">{ph.phase}</span>
              <span className="text-xs text-slate-400">{ph.weeks}</span>
            </div>
            <div className="ml-8 space-y-1">
              {ph.tasks.map((t, ti) => <button key={ti} onClick={() => patch(p => { p.roadmap[pi].tasks[ti].done = !p.roadmap[pi].tasks[ti].done; })}
                className="flex w-full items-center gap-2 rounded-lg px-2 py-1 text-left text-sm hover:bg-slate-50">
                {t.done ? <CircleCheck className="h-4 w-4 flex-shrink-0 text-emerald-500" /> : <Circle className="h-4 w-4 flex-shrink-0 text-slate-300" />}
                <span className={t.done ? "text-slate-400 line-through" : "text-slate-600"}>{t.t}</span></button>)}
            </div>
          </div>
        ); })}
    </div>
  );
}

/* ---- Implementation Coach: the single next action ---- */
function NextTaskCard({ project, onDone, onOpenDoc, onGoto }) {
  const nt = nextTask(project);
  if (!nt) return (
    <div className="mb-5 rounded-2xl border border-emerald-200 bg-emerald-50 p-5 text-center">
      <CircleCheck className="mx-auto mb-2 h-8 w-8 text-emerald-500" />
      <div className="text-base font-semibold text-slate-900">Every required process is implemented.</div>
      <div className="mt-1 text-sm text-slate-500">Review your audit readiness and you're set for certification.</div>
    </div>
  );
  const gen = project.generated["proc_" + nt.proc.key];
  return (
    <div className="mb-5 rounded-2xl border-2 border-indigo-200 bg-white p-5 shadow-sm">
      <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-indigo-500">
        <Sparkles className="h-4 w-4" />Your next task · {nt.proc.name} · step {nt.done + 1} of {nt.total}</div>
      <div className="mt-2 text-lg font-semibold leading-snug text-slate-900">{nt.task}</div>
      <div className="mt-4 flex flex-wrap gap-2">
        <Btn onClick={() => onDone(nt.proc.key, nt.index)}><Check className="h-4 w-4" />Mark done</Btn>
        {gen && <Btn variant="outline" onClick={() => onOpenDoc("proc_" + nt.proc.key)}><FileText className="h-4 w-4" />Open the document</Btn>}
        <Btn variant="ghost" onClick={onGoto}>See all steps</Btn>
      </div>
    </div>
  );
}

/* ---- Per-process implementation checklist ---- */
function ProcessList({ project, busy, onToggleTask, onOpenDoc, onGenProc }) {
  const [expanded, setExpanded] = useState(null);
  return (
    <div className="space-y-2">
      {requiredProcs(project).map(pr => {
        const items = taskItems(project, pr.key);
        const done = items.filter(x => x.done).length;
        const st = STATUS[procStatusKey(project, pr.key)];
        const gen = project.generated["proc_" + pr.key];
        const isOpen = expanded === pr.key;
        return (
          <div key={pr.key} className="rounded-xl border border-slate-200">
            <button onClick={() => setExpanded(isOpen ? null : pr.key)} className="flex w-full items-center gap-3 px-3 py-2.5 text-left hover:bg-slate-50">
              <span className="h-2.5 w-2.5 flex-shrink-0 rounded-full" style={{ background: st.color || "#cbd5e1" }} />
              <span className="min-w-0 flex-1"><span className="block truncate text-sm font-medium text-slate-800">{pr.name}</span><span className="block truncate text-xs text-slate-400">{pr.plain}</span></span>
              <span className="flex-shrink-0 text-xs font-semibold text-slate-500">{done}/{items.length}</span>
              <ChevronDown className={cx("h-4 w-4 flex-shrink-0 text-slate-400 transition-transform", isOpen && "rotate-180")} />
            </button>
            {isOpen && (
              <div className="border-t border-slate-100 px-3 py-3">
                <div className="mb-2.5">
                  {gen ? <button onClick={() => onOpenDoc("proc_" + pr.key)} className="inline-flex items-center gap-1.5 rounded-lg bg-indigo-50 px-2.5 py-1 text-xs font-semibold text-indigo-700 hover:bg-indigo-100"><FileText className="h-3.5 w-3.5" />Open policy & procedure</button>
                       : <button onClick={() => onGenProc(pr)} disabled={!!busy} className="inline-flex items-center gap-1.5 rounded-lg bg-indigo-600 px-2.5 py-1 text-xs font-semibold text-white hover:bg-indigo-500 disabled:opacity-50"><Wand2 className="h-3.5 w-3.5" />Generate its documents</button>}
                </div>
                <div className="space-y-0.5">
                  {items.map((it, i) => (
                    <button key={i} onClick={() => onToggleTask(pr.key, i)} className="flex w-full items-center gap-2.5 rounded-lg px-2 py-1.5 text-left text-sm hover:bg-slate-50">
                      {it.done ? <CircleCheck className="h-4 w-4 flex-shrink-0 text-emerald-500" /> : <Circle className="h-4 w-4 flex-shrink-0 text-slate-300" />}
                      <span className={it.done ? "text-slate-400 line-through" : "text-slate-700"}>{it.t}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

/* ---- Plain-language "here's what you have" summary ---- */
function SummaryCard({ project, readiness }) {
  const co = project.meta.companyName || "your organization";
  return (
    <div className="mb-5 rounded-2xl border border-slate-200 bg-white p-5">
      <div className="flex items-center gap-2 text-base font-semibold text-slate-900"><CheckCircle2 className="h-5 w-5 text-emerald-500" />Your ISO/IEC 20000-1 system is built</div>
      <p className="mt-2 text-sm text-slate-600">From your contract we mapped the requirements across clauses 4–10 and generated <b>{readiness.genCount} documents</b> — policies, procedures, RACI matrices, KPIs, risk registers and audit checklists — tailored to {co}. You can open or export any of them below.</p>
      <p className="mt-2 text-sm text-slate-600">Everything that can be automated is done. The short list below is the real-world work only your team can do to reach certification — the tool can't assign your people or configure your systems for you.</p>
    </div>
  );
}

/* ---- The short, honest real-world action list ---- */
function ActionsBlock({ project, onToggle }) {
  const items = actionItems(project);
  return (
    <div className="space-y-0.5">
      {items.map((it, i) => (
        <button key={i} onClick={() => onToggle(i)} className="flex w-full items-start gap-2.5 rounded-lg px-2 py-2 text-left text-sm hover:bg-slate-50">
          {it.done ? <CircleCheck className="mt-0.5 h-4 w-4 flex-shrink-0 text-emerald-500" /> : <Circle className="mt-0.5 h-4 w-4 flex-shrink-0 text-slate-300" />}
          <span className={it.done ? "text-slate-400 line-through" : "text-slate-700"}>{it.t}</span>
        </button>
      ))}
    </div>
  );
}

/* ---- Document library: open / export everything ---- */
function DocsList({ project, busy, onOpen, onGenRest }) {
  const rows = project.docList || [...CORE_DOCS.map(d => ({ key: d.key, name: d.name, clause: d.clause })), ...PROCESSES.map(pr => ({ key: "proc_" + pr.key, name: pr.name, clause: pr.clause }))];
  const total = rows.length;
  const have = rows.filter(r => project.generated[r.key]).length;
  return (
    <div className="space-y-2">
      {have < total && (
        <button onClick={onGenRest} disabled={!!busy} className="inline-flex items-center gap-1.5 rounded-lg bg-indigo-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-indigo-500 disabled:opacity-50">
          {busy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Wand2 className="h-3.5 w-3.5" />}Finish generating ({have}/{total})</button>
      )}
      <div className="grid grid-cols-1 gap-1.5 sm:grid-cols-2">
        {rows.map(r => { const gen = project.generated[r.key];
          return (
            <div key={r.key} className="flex items-center justify-between gap-2 rounded-xl border border-slate-200 px-3 py-2">
              <div className="min-w-0"><div className="truncate text-sm font-medium text-slate-700">{r.name}</div><div className="font-mono text-xs text-slate-400">{r.clause}</div></div>
              {gen ? <div className="flex flex-shrink-0 items-center gap-1">
                  <button onClick={() => onOpen(r.key)} className="rounded-lg px-2 py-1 text-xs font-semibold text-indigo-600 hover:bg-indigo-50">Open</button>
                  <button onClick={() => exportWord(r.name, project.generated[r.key].content)} className="rounded-lg p-1.5 text-slate-400 hover:text-indigo-600" title="Word"><FileDown className="h-4 w-4" /></button>
                </div> : <span className="flex-shrink-0 text-xs text-slate-300">pending</span>}
            </div>
          ); })}
      </div>
    </div>
  );
}

/* ---- Ask bar: type what you want, it builds it ---- */
function AskBar({ project, patch, setModal, setAiOk, flash }) {
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [openChat, setOpenChat] = useState(false);
  const scroller = useRef(null);
  useEffect(() => { scroller.current?.scrollTo(0, scroller.current.scrollHeight); }, [project.chat, busy]);

  async function send(q) {
    const question = (q ?? input).trim(); if (!question || busy) return;
    setInput(""); setOpenChat(true); setBusy(true);
    patch(p => p.chat.push({ role: "user", text: question }));
    const wantsDoc = /\b(build|draft|generate|write|create|make)\b/i.test(question) && /\b(policy|procedure|plan|matrix|register|process|sop|checklist|document|report)\b/i.test(question);
    try {
      const sys = `You are the ISO/IEC 20000-1:2018 Implementation Copilot for this specific organization. Ground answers in the project below; reference clause numbers; be concise and plain-spoken. When asked to build a document, output it fully in markdown starting with a "# Title" line.

${projectBrief(project)}

CURRENT STATE:
${liveState(project)}`;
      const hist = project.chat.slice(-6).map(m => ({ role: m.role === "user" ? "user" : "assistant", content: m.text }));
      const ans = await callAI([...hist, { role: "user", content: question }], sys);
      setAiOk?.(true);
      const saveable = wantsDoc && ans.length > 300;
      patch(p => p.chat.push({ role: "assistant", text: ans, saveable }));
    } catch (e) { setAiOk?.(false); patch(p => p.chat.push({ role: "assistant", text: "I couldn't reach the AI (" + e.message + "). Open the ⋯ menu → AI connection to set it up." })); }
    setBusy(false);
  }
  function saveDoc(text) {
    const title = (text.match(/^#\s+(.+)$/m)?.[1] || "Custom document").trim();
    const key = "ask_" + Date.now();
    patch(p => { p.generated[key] = { title, clause: "—", content: text, ts: Date.now() }; });
    flash("Saved to your documents"); setModal({ key, title, clause: "—", content: text });
  }
  const SUGG = {
    iso20000: ["What am I still missing?", "What will an auditor ask for Clause 9?", "Build my Capacity Management procedure"],
    iso27001: ["What am I still missing?", "What will an auditor ask for Annex A access control?", "Draft my Risk Treatment Plan"],
    cmmc: ["What am I still missing?", "What will an assessor check for 3.1 Access Control?", "Draft my POA&M for open items"],
  };
  const suggestions = SUGG[project.framework] || SUGG.iso20000;

  return (
    <div className="border-t border-slate-200 bg-white">
      {openChat && (
        <div className="mx-auto max-w-3xl px-4 sm:px-6">
          <div className="flex items-center justify-between py-2"><span className="text-xs font-semibold uppercase tracking-wide text-slate-400">Copilot</span>
            <button onClick={() => setOpenChat(false)} className="text-slate-400 hover:text-slate-600"><ChevronDown className="h-4 w-4" /></button></div>
          <div ref={scroller} className="max-h-72 space-y-3 overflow-y-auto pb-3">
            {project.chat.slice(-8).map((m, i) => (
              <div key={i} className={cx("flex", m.role === "user" ? "justify-end" : "justify-start")}>
                <div className={cx("max-w-[88%] rounded-2xl px-3.5 py-2.5 text-sm", m.role === "user" ? "bg-indigo-600 text-white" : "border border-slate-200 bg-slate-50 text-slate-700")}>
                  {m.role === "user" ? m.text : <><div className="doc-prose doc-prose-sm" dangerouslySetInnerHTML={{ __html: mdToHtml(m.text) }} />
                    {m.saveable && <button onClick={() => saveDoc(m.text)} className="mt-2 inline-flex items-center gap-1.5 rounded-lg bg-indigo-600 px-2.5 py-1 text-xs font-semibold text-white hover:bg-indigo-500"><Save className="h-3.5 w-3.5" />Save to documents</button>}</>}
                </div>
              </div>))}
            {busy && <div className="flex justify-start"><div className="rounded-2xl border border-slate-200 bg-slate-50 px-3.5 py-2.5"><Loader2 className="h-4 w-4 animate-spin text-indigo-500" /></div></div>}
          </div>
        </div>
      )}
      <div className="mx-auto max-w-3xl px-4 py-3 sm:px-6">
        {!openChat && project.chat.length === 0 && (
          <div className="mb-2 flex flex-wrap gap-1.5">{suggestions.map(s => <button key={s} onClick={() => send(s)} className="rounded-full border border-slate-200 px-3 py-1 text-xs text-slate-500 hover:border-indigo-300 hover:text-indigo-600">{s}</button>)}</div>
        )}
        <div className="flex items-end gap-2 rounded-2xl border border-slate-300 bg-white px-3 py-2 focus-within:border-indigo-400 focus-within:ring-2 focus-within:ring-indigo-100">
          <MessageSquare className="mb-1.5 h-5 w-5 flex-shrink-0 text-slate-300" />
          <textarea rows={1} value={input} onChange={e => setInput(e.target.value)} onFocus={() => project.chat.length && setOpenChat(true)}
            onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }}
            placeholder="Ask anything, or tell me what to build…" className="max-h-28 flex-1 resize-none border-0 bg-transparent py-1.5 text-sm text-slate-800 placeholder-slate-400 focus:outline-none" />
          <button onClick={() => send()} disabled={busy || !input.trim()} className="mb-0.5 flex h-8 w-8 items-center justify-center rounded-xl text-white disabled:opacity-40" style={{ background: INK }}><Send className="h-4 w-4" style={{ color: GOLD }} /></button>
        </div>
      </div>
    </div>
  );
}

/* ---- Document viewer (slide-over) ---- */
function DocModal({ doc, onClose, patch, flash }) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(doc.content);
  return (
    <div className="fixed inset-0 z-40 flex justify-end">
      <div className="absolute inset-0 bg-slate-900/30" onClick={onClose} />
      <div className="relative flex h-full w-full max-w-2xl flex-col bg-white shadow-2xl">
        <div className="flex items-center justify-between gap-3 border-b border-slate-200 px-5 py-3">
          <div className="min-w-0"><h3 className="truncate text-base font-bold text-slate-900">{doc.title}</h3>
            {doc.clause && doc.clause !== "—" && <span className="text-xs font-medium text-indigo-600">ISO 20000-1 · Clause {doc.clause}</span>}</div>
          <div className="flex flex-shrink-0 items-center gap-1">
            {doc.key && !editing && <Btn size="sm" variant="ghost" onClick={() => { setDraft(doc.content); setEditing(true); }}><Edit3 className="h-4 w-4" /></Btn>}
            {doc.key && editing && <Btn size="sm" onClick={() => { patch(p => { p.generated[doc.key].content = draft; }); doc.content = draft; setEditing(false); flash("Saved"); }}><Save className="h-4 w-4" /></Btn>}
            <Btn size="sm" variant="outline" onClick={() => { navigator.clipboard?.writeText(doc.content); flash("Copied"); }}><Copy className="h-4 w-4" /></Btn>
            <Btn size="sm" variant="outline" onClick={() => exportWord(doc.title, editing ? draft : doc.content)}><FileDown className="h-4 w-4" />Word</Btn>
            <Btn size="sm" variant="outline" onClick={() => exportPdf(doc.title, editing ? draft : doc.content)}>PDF</Btn>
            <button onClick={onClose} className="rounded-lg p-2 text-slate-400 hover:bg-slate-100"><X className="h-5 w-5" /></button>
          </div>
        </div>
        <div className="flex-1 overflow-y-auto p-6">
          {editing ? <textarea className={cx(inputCls, "h-full min-h-full font-mono text-xs")} value={draft} onChange={e => setDraft(e.target.value)} />
            : <div className="doc-prose" dangerouslySetInnerHTML={{ __html: mdToHtml(doc.content) }} />}
        </div>
      </div>
    </div>
  );
}

/* ---- Security & data (modal) — the trust story ---- */
function SecurityModal({ onClose }) {
  const points = [
    ["Your documents aren't stored", "Your contract is processed in your browser and sent to the AI to generate your system. Conforma doesn't save your documents on a server."],
    ["Your API key stays with you", "When you connect a provider, the key is kept only in your browser — it's never sent to us."],
    ["You choose where the AI runs", "Text goes to the provider you connect — Anthropic, OpenAI, or your own backend. You control that."],
    ["Preview limitation", "Don't upload classified, CUI, ITAR, or otherwise restricted material in this preview version."],
    ["Built for federal-grade deployments", "For CUI or federal data, Conforma can run inside your own FedRAMP GovCloud boundary (AWS Bedrock / Azure Government) so your data never leaves an authorized environment."],
  ];
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-900/40" onClick={onClose} />
      <div className="relative max-h-[92vh] w-full max-w-lg overflow-y-auto rounded-2xl bg-white p-6 shadow-2xl">
        <div className="mb-4 flex items-center justify-between">
          <div className="flex items-center gap-2"><ShieldCheck className="h-5 w-5 text-indigo-600" /><h3 className="text-lg font-bold text-slate-900">Security & your data</h3></div>
          <button onClick={onClose} className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100"><X className="h-5 w-5" /></button>
        </div>
        <div className="space-y-3">
          {points.map(([t, d]) => (
            <div key={t} className="flex gap-3 rounded-xl border border-slate-200 p-3.5">
              <Check className="mt-0.5 h-4 w-4 flex-shrink-0 text-emerald-500" />
              <div><div className="text-sm font-semibold text-slate-900">{t}</div><div className="mt-0.5 text-xs text-slate-500">{d}</div></div>
            </div>
          ))}
        </div>
        <p className="mt-4 text-xs text-slate-400">This isn't legal advice. Confirm your own contract's data-handling requirements (e.g. DFARS 252.204-7012, NIST 800-171, CUI rules) before uploading sensitive material.</p>
        <button onClick={() => goCheckout("contact")} className="mt-4 w-full rounded-xl bg-indigo-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-indigo-500">Ask about a FedRAMP / GovCloud deployment</button>
      </div>
    </div>
  );
}

/* ---- Pricing (modal) — the startup's plans ---- */
function PricingModal({ onClose }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-900/40" onClick={onClose} />
      <div className="relative max-h-[92vh] w-full max-w-3xl overflow-y-auto rounded-2xl bg-white p-6 shadow-2xl sm:p-8">
        <div className="mb-1 flex items-center justify-between">
          <div className="flex items-center gap-2.5"><Logo size={30} /><span className="brand-font text-lg font-bold text-slate-900">{BRAND.name}</span></div>
          <button onClick={onClose} className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100"><X className="h-5 w-5" /></button>
        </div>
        <h3 className="brand-font mt-3 text-2xl font-bold text-slate-900">Simple pricing for real implementations</h3>
        <p className="mt-1 text-sm text-slate-500">A full compliance implementation is normally weeks of consulting. Conforma does the paperwork in an hour.</p>

        <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-3">
          {PRICING.map(t => (
            <div key={t.id} className={cx("relative flex flex-col rounded-2xl border p-5", t.popular ? "border-indigo-300 bg-indigo-50/40 ring-1 ring-indigo-200" : "border-slate-200")}>
              {t.popular && <span className="absolute -top-2.5 left-5 rounded-full bg-indigo-600 px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wide text-white">Most popular</span>}
              <div className="text-sm font-semibold text-slate-900">{t.name}</div>
              <div className="mt-2 flex items-baseline gap-1"><span className="brand-font text-3xl font-bold text-slate-900">{t.price}</span><span className="text-xs text-slate-400">{t.unit}</span></div>
              <p className="mt-1 text-xs text-slate-500">{t.tagline}</p>
              <ul className="mt-4 flex-1 space-y-1.5">
                {t.features.map((f, i) => <li key={i} className="flex gap-2 text-xs text-slate-600"><Check className="mt-0.5 h-3.5 w-3.5 flex-shrink-0 text-emerald-500" />{f}</li>)}
              </ul>
              <button onClick={() => goCheckout(t.id)} className={cx("mt-5 w-full rounded-xl px-4 py-2.5 text-sm font-semibold transition", t.popular ? "bg-indigo-600 text-white hover:bg-indigo-500" : "border border-slate-300 text-slate-700 hover:bg-slate-50")}>{t.cta}</button>
            </div>
          ))}
        </div>

        <div className="mt-5 flex items-start gap-2.5 rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-800">
          <Tag className="mt-0.5 h-4 w-4 flex-shrink-0" />
          <div><b>Founding customer?</b> First customers get a locked founder rate in exchange for feedback and a testimonial. <button onClick={() => goCheckout("contact")} className="font-semibold underline">Get in touch</button>.</div>
        </div>
      </div>
    </div>
  );
}

/* ---- Settings (modal) ---- */
function SettingsModal({ onClose, flash, aiOk, setAiOk }) {
  const [cfg, setCfg] = useState(getAiSettings());
  const [testing, setTesting] = useState(false);
  const [result, setResult] = useState(null);
  const set = (k, v) => setCfg(c => ({ ...c, [k]: v }));
  async function test() { setTesting(true); setResult(null); await saveAiSettings(cfg);
    try { const good = await testAI(); setResult({ ok: good, msg: good ? "Connected — every button now produces live output." : "Reached the service but got an odd reply; check the model name." }); setAiOk(good); }
    catch (e) { setResult({ ok: false, msg: e.message }); setAiOk(false); } setTesting(false); }
  const opts = [
    { id: "auto", t: "This preview (no key)", d: "Works inside the Claude.ai preview. Stops when deployed elsewhere." },
    { id: "anthropic", t: "Anthropic API key", d: "Works anywhere. Full-length output. Stored only in this browser." },
    { id: "openai", t: "OpenAI API key", d: "GPT-4o and similar. PDF reading needs Anthropic." },
    { id: "backend", t: "Your own backend", d: "Hides the key on a server — for production. Use the included Netlify function." },
  ];
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-900/40" onClick={onClose} />
      <div className="relative max-h-[90vh] w-full max-w-lg overflow-y-auto rounded-2xl bg-white p-6 shadow-2xl">
        <div className="mb-4 flex items-center justify-between"><h3 className="text-lg font-bold text-slate-900">AI connection</h3><button onClick={onClose} className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100"><X className="h-5 w-5" /></button></div>
        <p className="mb-4 rounded-xl bg-indigo-50 p-3 text-sm text-indigo-800">Connect a provider so the app generates real, contract-specific content. Without it, the sample still fills every screen.</p>
        <div className="space-y-2">
          {opts.map(o => <button key={o.id} onClick={() => set("provider", o.id)}
            className={cx("flex w-full items-start gap-3 rounded-xl border p-3 text-left", cfg.provider === o.id ? "border-indigo-500 bg-indigo-50/50" : "border-slate-200 hover:border-indigo-300")}>
            <span className={cx("mt-0.5 flex h-4 w-4 flex-shrink-0 items-center justify-center rounded-full border-2", cfg.provider === o.id ? "border-indigo-600 bg-indigo-600" : "border-slate-300")}>{cfg.provider === o.id && <span className="h-1.5 w-1.5 rounded-full bg-white" />}</span>
            <span><span className="block text-sm font-semibold text-slate-900">{o.t}</span><span className="block text-xs text-slate-500">{o.d}</span></span></button>)}
        </div>
        <div className="mt-4 space-y-3">
          {cfg.provider === "anthropic" && <Field label="Anthropic API key"><input type="password" className={inputCls} value={cfg.anthropicKey} onChange={e => set("anthropicKey", e.target.value)} placeholder="sk-ant-..." /></Field>}
          {cfg.provider === "openai" && <Field label="OpenAI API key"><input type="password" className={inputCls} value={cfg.openaiKey} onChange={e => set("openaiKey", e.target.value)} placeholder="sk-..." /></Field>}
          {cfg.provider === "backend" && <Field label="Backend URL"><input className={inputCls} value={cfg.backendUrl} onChange={e => set("backendUrl", e.target.value)} placeholder="/.netlify/functions/ai" /></Field>}
          {cfg.provider !== "auto" && cfg.provider !== "backend" && <Field label="Model (optional)"><input className={inputCls} value={cfg.model} onChange={e => set("model", e.target.value)} placeholder={cfg.provider === "openai" ? "gpt-4o" : "claude-3-5-sonnet-latest"} /></Field>}
        </div>
        <div className="mt-5 flex items-center gap-3">
          <Btn onClick={test} disabled={testing}>{testing ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plug className="h-4 w-4" />}Test & save</Btn>
          {result && <span className={cx("inline-flex items-center gap-1.5 text-sm font-medium", result.ok ? "text-emerald-600" : "text-rose-600")}>{result.ok ? <CheckCircle2 className="h-4 w-4" /> : <XCircle className="h-4 w-4" />}{result.msg}</span>}
        </div>
      </div>
    </div>
  );
}

/* ============================================================================
   Global styles
   ========================================================================== */
const globalCss = `
  @import url('https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700&family=IBM+Plex+Sans:wght@400;500;600;700&family=IBM+Plex+Mono:wght@400;500;600&display=swap');
  .iso-app, .iso-app input, .iso-app textarea, .iso-app button, .iso-app select { font-family: 'IBM Plex Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; }
  .brand-font { font-family: 'Fraunces', Georgia, serif; letter-spacing: -0.01em; font-optical-sizing: auto; }
  .cf-mono { font-family: 'IBM Plex Mono', ui-monospace, monospace; }
  .cf-grid { background-image: linear-gradient(rgba(43,75,242,.05) 1px, transparent 1px), linear-gradient(90deg, rgba(43,75,242,.05) 1px, transparent 1px); background-size: 34px 34px; }
  @keyframes cfRow { 0%{opacity:0;transform:translateY(9px)} 8%{opacity:1;transform:none} 88%{opacity:1} 100%{opacity:0} }
  @keyframes cfScan { 0%{top:12%;opacity:0} 6%{opacity:.85} 60%{top:80%;opacity:.85} 66%{opacity:0} 100%{opacity:0} }
  @keyframes cfFill { 0%{width:6%} 80%{width:100%} 100%{width:100%} }
  @keyframes cfUp { 0%{opacity:0;transform:translateY(14px)} 100%{opacity:1;transform:none} }
  @keyframes cfStamp { 0%,70%{opacity:0;transform:scale(1.5) rotate(-11deg)} 79%{opacity:1;transform:scale(1) rotate(0)} 95%{opacity:1;transform:scale(1) rotate(0)} 100%{opacity:0;transform:scale(1) rotate(0)} }
  @keyframes cfGlow { 0%,100%{opacity:.5} 50%{opacity:.9} }
  .cf-anim-row { animation: cfRow 7s infinite; }
  .cf-scan { animation: cfScan 7s infinite; }
  .cf-fill { animation: cfFill 7s infinite; }
  .cf-up { animation: cfUp .7s cubic-bezier(.2,.7,.2,1) both; }
  .cf-stamp { animation: cfStamp 7s infinite; }
  .cf-glow { animation: cfGlow 4s ease-in-out infinite; }
  @media (prefers-reduced-motion: reduce) { .cf-anim-row,.cf-scan,.cf-fill,.cf-up,.cf-stamp,.cf-glow { animation: none !important; opacity: 1 !important; transform: none !important; } }
  .h-4\\.5 { height:1.125rem; } .w-4\\.5 { width:1.125rem; }
  .doc-prose { color:#475569; font-size:14.5px; line-height:1.7; }
  .doc-prose h1 { font-size:22px; font-weight:700; color:#0f172a; margin:0 0 14px; padding-bottom:8px; border-bottom:1px solid #e2e8f0; }
  .doc-prose h2 { font-size:16px; font-weight:600; color:#4338ca; margin:22px 0 8px; }
  .doc-prose h3 { font-size:13.5px; font-weight:600; color:#4f46e5; margin:16px 0 6px; }
  .doc-prose p { margin:8px 0; } .doc-prose ul { margin:8px 0; padding-left:20px; list-style:disc; } .doc-prose li { margin:4px 0; }
  .doc-prose code { background:#eef2ff; color:#4338ca; padding:1px 5px; border-radius:4px; font-size:12.5px; }
  .doc-prose strong { color:#1e293b; font-weight:600; }
  .doc-prose .md-table { width:100%; border-collapse:collapse; margin:12px 0; font-size:13px; display:block; overflow-x:auto; }
  .doc-prose .md-table th { background:#eef2ff; color:#3730a3; text-align:left; padding:8px 10px; border:1px solid #e0e7ff; font-weight:600; }
  .doc-prose .md-table td { padding:8px 10px; border:1px solid #eef2f7; color:#475569; vertical-align:top; }
  .doc-prose-sm { font-size:13.5px; } .doc-prose-sm h1 { font-size:16px; } .doc-prose-sm h2 { font-size:14px; margin-top:14px; }
  ::-webkit-scrollbar { width:9px; height:9px; } ::-webkit-scrollbar-thumb { background:#cbd5e1; border-radius:5px; } ::-webkit-scrollbar-track { background:transparent; }
  .blob { position:absolute; border-radius:9999px; filter:blur(70px); opacity:.5; }
  .blob-a { width:360px; height:360px; background:#c7d2fe; top:-80px; left:-60px; animation:drift1 18s ease-in-out infinite; }
  .blob-b { width:320px; height:320px; background:#ddd6fe; bottom:-90px; right:-40px; animation:drift2 22s ease-in-out infinite; }
  @keyframes drift1 { 0%,100%{transform:translate(0,0)} 50%{transform:translate(40px,30px)} }
  @keyframes drift2 { 0%,100%{transform:translate(0,0)} 50%{transform:translate(-30px,-40px)} }
  .float-chip { position:absolute; font-size:11px; font-weight:600; color:#a5b4fc; background:#ffffffcc; border:1px solid #e0e7ff; border-radius:9999px; padding:3px 10px; opacity:.7; animation:floaty 12s ease-in-out infinite; }
  .float-0{ top:16%; left:12%; } .float-1{ top:24%; right:14%; animation-delay:1s; } .float-2{ top:60%; left:8%; animation-delay:2s; }
  .float-3{ bottom:18%; right:16%; animation-delay:3s; } .float-4{ top:44%; right:9%; animation-delay:1.5s; } .float-5{ bottom:28%; left:18%; animation-delay:2.5s; } .float-6{ top:12%; right:34%; animation-delay:.5s; }
  @keyframes floaty { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-14px)} }
  @media (prefers-reduced-motion: reduce) { *{animation:none !important; transition:none !important} }
`;
